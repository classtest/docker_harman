#!/usr/local/bin/perl -w



my @CRs = qw(VOSDF00034592);


use Win32::OLE;
# FetchStatus Constants identify the status of moving the cursor in a request set.
$CQPerlExt::CQ_SUCCESS = 1;  #The next record in the request set was successfully obtained.

my $sqlQuery = "";
my $resultSet = "";
my $CmdStr ="";
my $CmdRtn = "";
my $RtnVal = "";
my $result = "";

my $CQSession = "";
my $CQUID = "clearquest-svc";
my $PWD = "U#4=1**]163Yq";
my $cqdb = "VOSDF";
my $CQConnection = "AonCQEnterprise";

$CQSession = SetCQSession($CQUID,$PWD,$cqdb,$CQConnection,\$CQSession);
# my $fullname = $CQSession->GetUserFullName();
#

my @depCRArr = ();
# my @unique = ();
my $depcrid = "";
my %hash = ();
my @ArrdepCRDet = ();
foreach my $cr (@CRs) {
	%hash = ();
	print $cr . "\n";
	@depCRArr = GetDepCRs($cr);
	if (scalar (@depCRArr) > 0) {
		my( $index )= grep { $CRs[$_] eq $cr } 0..$#CRs;
		delete $CRs[$index];
		print "\t";
		foreach $deCrs (@depCRArr) {
			($depcrid) = $deCrs =~ m/(VOSDF\d*)\~/;
			push(@CRs,$depcrid);
			@ArrdepCRDet = split("~",$deCrs);
			my $depcrrow = "";
			foreach my $ddet (@ArrdepCRDet) {
				$depcrrow .= $ddet . "\t";
			}
			print $depcrrow . "\n";
		}
		%hash   = map { $_ => 1 } @CRs;
		@CRs = keys %hash;
			
	}

}




#**********************************************************************************************************************************
#  Function :  GetSprints
#  Purpose  :  Find the CR details
#           :  
#  Paramters:  CR, clearcase stream info
#**********************************************************************************************************************************
sub GetSprints {
	my $mstrcr = shift;
	my @arrDepCRs = ();	
	my $sqlQuery  = "select distinct T1.dbid,T2.id,T3.name,T2.Severity,T2.resolve_date,T2.Headline from Defect T1,Defect T2,parent_child_links T2mm,statedef T3 where T1.dbid = T2mm.parent_dbid  (+)  and 16781916 = T2mm.parent_fielddef_id  (+)  and T2mm.child_dbid = T2.dbid  (+)  and T2.State = T3.id (+)  and (T1.dbid <> 0 and ((T2.id is not NULL and T1.id = '$mstrcr')))";

	my $resultSet = $CQSession->BuildSQLQuery($sqlQuery);
	$resultSet->Execute();
	while($resultSet->MoveNext() == $CQPerlExt::CQ_SUCCESS)
	{
		# print "Dependant CRs : ". $resultSet->GetColumnValue(2)."\n";	

		# @arrSprints
		push(@arrDepCRs,$resultSet->GetColumnValue(2). "~" . $resultSet->GetColumnValue(3) . "~" . $resultSet->GetColumnValue(4) . "~" . $resultSet->GetColumnValue(5) . "~" . $resultSet->GetColumnValue(6));

	}
	return @arrDepCRs;
}










# ***************************** Enable ClearQuest Session *****************************
sub SetCQSession
{
	my ($CQUser,$CQPwd,$CQDB,$CQConn,$CQSessionRef) = @_;
	$$CQSessionRef = Win32::OLE->new("CLEARQUEST.SESSION") or die "Can't create ClearQuest session object via call to Win32::OLE->new(): $!";
	eval
	{
		$$CQSessionRef->UserLogon("$CQUser", "$CQPwd","$CQDB", 2,$CQConn);
	};
	
	my $ufullname = $$CQSessionRef->GetUserFullName();
	if ($ufullname)
        {
		print "ClearQuest Session has established\n"; 
	}
	else {	
		print "Can not establish ClearQuest Session!!!\n"; 	
	}
	return $$CQSessionRef;
}



