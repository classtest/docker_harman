#!/usr/local/bin/perl -w
use File::Find;
use File::Basename;
use File::Basename;
# use strict;
# use strict;
use warnings;


use Win32::ODBC;
use CGI::Cookie;


$tetst = "test,test,test,test,";
($test) = $tetst =~ m/(.*),$/;
# print $test;
#
#

my $TmpFile = "D:\\temp\\file.txt";
open (TMPFILE, ">$TmpFile") || print "Can't open $TmpFile: $!<BR>";
my $vos_bld_dir = '\\\\atli-fs01\eSolutions_Builds\iVos\iVOS-44321.02.01';
find( sub { /^iVOS44321.02.01_2_05-08-2014_12.53$/i && print TMPFILE "$File::Find::name" }, $vos_bld_dir);
close(TMPFILE);
open(TMPFILE, $TmpFile) || print("Could not open file!<BR>");
my @relFileLoc=<TMPFILE>;
close(TMPFILE);
$relFileLoc[0] =~ tr/\//\\/;
print $relFileLoc[0];
exit;



$CmdStr = "svn ls http://svn.int.aonesolutions.us/ivos/java/branches";
$CmdRtn = `$CmdStr  2>&1`;
@svnbranches = split("/",$CmdRtn);



foreach (@svnbranches) {
	$_ = trim($_);
	if (($_) && (length($_) >= 4)) {
		if ($_ !~ m/^ConfigTool_4324_Tmp|Config_Tool_4323_Temp|IP-2011-ClientConf|IP_Bld_Tst_01|IP_Gradle|In-progress-defects-deprecated|In-progress-impl-deprecated|In-progress-product-deprecated|Logica-in-progress|NOT_USED_43x_MC_Phase2_temp|NOT_USED_in-progress-mc-test|Old_41DBStore|archive|configuration-tool|guvnor-demo-in-progress|iVos_Portal|in-progress-4502-temp|in-progress-mc-temp|in-progress-mc_final|in-progress-old|in-progress-staging|in-progress-staging-deprecated|in-progress-wsi_temp|in-progress_bld_tmp|in-progress_jdk1.7|in-progress_mc_merge_temp|in-progress_rp_042011|in-progress_v126631|ip_drools_upg_5.0|ivos-report-int-test|test|utilities/) {
			push(@branches, $_);
		}
	}
}


#Get Date Time
my ($sec, $min, $hr, $day, $mon, $yr) = (localtime)[0,1,2,3,4,5];

my $fromsvndate = sprintf("%04d-%02d-%02d", $yr+1900,$mon+1, $day-1);
my $tosvndate = sprintf("%04d-%02d-%02d", $yr+1900,$mon+1, $day);


foreach my $brnchs (@branches) {
	if ($brnchs) {
		$brnchs=trim($brnchs);
		$svn_branches = "http://svn.int.aonesolutions.us/ivos/java/branches/$brnchs/src/db";
		$CmdStr = "svn log -v $svn_branches -r {$fromsvndate}:{$tosvndate}";

		$CmdRtn = `$CmdStr 2>&1`;
		if ($?)
			{
		        $RtnVal = $CmdStr.' failed : '.$CmdRtn;
        		undef($RtnVal);
		}

		if ($CmdRtn !~ m/^[(-)*]|[SCM\s+Create.*]$/) {
			print "$CmdRtn";
		}
	}	
}



sub trim
{
        my $string = shift;
        $string =~ s/^\s+//;
        $string =~ s/\s+$//;
        return $string;
}





exit;


my $TmpFile = '44105-to-44120.txt';
open (TMPFILE, "$TmpFile") || die "Can't open $TmpFile: $!\n";
my @relFileLoc=<TMPFILE>;
close(TMPFILE);
my @ids = ();
my $id = "";
foreach my $fl (@relFileLoc) {
	($id) = $fl =~ m/^(V\d{6}).*/; 



	push (@ids,$id);
}



my %hashWIResHFs   = map { $_ => 1 } @ids;
my @uniqueWIResDt = keys %hashWIResHFs;
@uniqueWIResDt = sort(@uniqueWIResDt);


foreach my $i (@uniqueWIResDt) {
	print $i . "\n";
}


exit;


$bld = 'iVOS4.4.2.13_1000_01-29-2013_01.35';
$bld =~ m/iVOS(.*)\_(.*)\_.*/;
my @bldt =  split ("_",$1);
print $bldt[0] . "\n" . $bldt[1];


exit;


$New_SVN_Stream = "dani'";
if ($New_SVN_Stream =~ /^[a-zA-Z0-9\_]+$/) {
	print "contains only alphanumeric and underscore";
}
else{
	print "SVN Stream cannot contains any other characters other than alphanumeric or underscore!";
}
exit;


my $scmDb = new Win32::ODBC('driver={SQL Server};Server=atld-ivoscm01\SQLEXPRESS;database=scm;UID=sa;PWD=s@mivosr3l;') or print Win32::ODBC::Error();

my @arrEnvDet = retClientRecDetails($scmDb);


#**********************************************************************************************************************************
#  Function :  retRelRecDetails
#  Purpose  :  Return release details
#  Return   :  
#  Paramters:  $dbObj
#**********************************************************************************************************************************
sub retClientRecDetails{
	my ($dbObj) = shift;

	my @RelDetArr = ();
	my %BldDet = ();
	my $ret = "";
	my $dbstr = "";


	# my $sqlQuery = "select [Customer-id] as cust_id,[Customer-name] as cust_name,custom_jsp as cust_jsp from [iVOS-Customer]  where Active = 1 order by [Customer-name]";

	my $sqlQuery = "select [Customer-id] as cust_id,[Customer-name] as cust_name,custom_jsp,custom_report,custom_lib,
	custom_icon,custom_help,custom_image from [iVOS-Customer] where Active = 1  order by [Customer-name]";


	# print $sqlQuery . "\n";
	

	$dbObj->Sql($sqlQuery);
	$ret = $dbObj->error() if !$ret;

	
	while($dbObj->FetchRow() && !$ret)
	{
		%BldDet = $dbObj->DataHash() if !$ret;
		$ret = $dbObj->error() if !$ret;
		#	print $ret;

		if ((!$BldDet{"custom_jsp"}) && (!$BldDet{"custom_report"}) && (!$BldDet{"custom_lib"}) && (!$BldDet{"custom_icon"}) && (!$BldDet{"custom_help"}) && (!$BldDet{"custom_image"})) {
				#print "no<BR>";
			}
			else
			{
				if (!$BldDet{"custom_jsp"}) { $BldDet{"custom_jsp"} = "-";}
				if (!$BldDet{"custom_report"}) { $BldDet{"custom_report"} = "-";}
				if (!$BldDet{"custom_lib"}) { $BldDet{"custom_lib"} = "-";}
				if (!$BldDet{"custom_icon"}) { $BldDet{"custom_icon"} = "-";}
				if (!$BldDet{"custom_help"}) { $BldDet{"custom_help"} = "-";}
				if (!$BldDet{"custom_image"}) { $BldDet{"custom_image"} = "-";}

				$dbstr = "";	
				$dbstr = $BldDet{"cust_id"} . "~" . $BldDet{"cust_name"} . "~" . $BldDet{"custom_jsp"}. "~" . $BldDet{"custom_report"}. "~" . $BldDet{"custom_lib"}. "~" . $BldDet{"custom_icon"}. "~" . $BldDet{"custom_help"}. "~" . $BldDet{"custom_image"}; 
				# push(@RelDetArr,$dbstr);
				print $dbstr . "\n";
	
			}
	
	}
	exit;


	return @RelDetArr;
}


exit;

my $TmpFile = 'D:\SVN_WorkingDir\SCM\in-progress\Scripts\new_customer_list.txt';
open (TMPFILE, "$TmpFile") || die "Can't open $TmpFile: $!\n";
my @relFileLoc=<TMPFILE>;
close(TMPFILE);
foreach my $fl (@relFileLoc) {

        $fl =~ s/^\s+//;
        $fl =~ s/\s+$//;


	
	$fl ="INSERT INTO [iVOS-Customer]([Customer-name],Active,custom_jsp,custom_report,custom_lib,custom_icon,custom_help,custom_image) VALUES ('$fl',1,'','','','','','')";
	print $fl. "\n";	
	$fl = "";
}

exit;


$relSVNStream = "44113";

# iVOS4.4.1.13

my @arrRelnum = $relSVNStream =~ m/^(\d)(\d)(\d)(\d+)$/;
my $relName = "$arrRelnum[0].$arrRelnum[1].$arrRelnum[2].$arrRelnum[3]";
print $relName. "\n";



exit;

$CmdStr = "net use R: \\\\atli-fs01\\eSolution_Releases\\iVos";
print "Running $CmdStr\n";
$CmdRtn = `$CmdStr  2>&1`;
if ($?)
{   
	$RtnVal = $CmdStr.' failed : '.$CmdRtn;
	print $RtnVal;
	undef($RtnVal);	
}


(my $reldig) = $relSVNStream =~ /(\d\d).*/;
if ($reldig eq "43") {
	if (-d "R:\\43x\\GA\\iVOS$relSVNStream") {
		print "Release already exists in the general releas location\n";
	}
	else {
		$CmdStr = "xcopy D:\\ClientDeployment\\$relSVNStream\\Release\\* R:\\43x\\GA\\iVOS$relSVNStream\\* /Q /Y /I /E";
		print "Running $CmdStr\n";
		$CmdRtn = `$CmdStr  2>&1`;
		if ($?)
		{   
			$RtnVal = $CmdStr.' failed : '.$CmdRtn;
			undef($RtnVal);	
		}
	}
}
elsif ($reldig eq "44") {

	if (-d "R:\\44x\\GA\\iVOS$relSVNStream") {
		print "Release already exists in the general releas location\n";
	}
	else {
		$CmdStr = "xcopy D:\\ClientDeployment\\$relSVNStream\\Release\\* R:\\43x\\GA\\iVOS$relSVNStream\\* /Q /Y /I /E";
		print "Running $CmdStr\n";
		# 	$CmdRtn = `$CmdStr  2>&1`;
		if ($?)
		{   
			$RtnVal = $CmdStr.' failed : '.$CmdRtn;
			undef($RtnVal);	
		}
	}
}
elsif ($reldig eq "42") {
	print "location is 42";
}
else {
	print "invalid location";
}

$CmdStr = "net use R: /delete";
print "Running $CmdStr\n";
$CmdRtn = `$CmdStr  2>&1`;
if ($?)
{   
	$RtnVal = $CmdStr.' failed : '.$CmdRtn;
	print $RtnVal;
	undef($RtnVal);	
}

# if ()



exit;

$relSVNStream = "43223";
if (length($relSVNStream) eq "6") {
	print "length 6";
}
else {
	print "legnth 5";
}

exit;


reset_release('D:\ClientDeployment\test\432233');
# Reset release
sub reset_release {
		my $delfldr = shift;
		my ($basecddir) = $delfldr =~ m/(.*)\\.*$/;
		# closedir($delfldr);
		chdir ($basecddir);
		$CmdStr = "attrib -R $delfldr\\* /S /D";
		# print "Running $CmdStr\n";
		$CmdRtn = `$CmdStr  2>&1`;
		$CmdStr = "rmdir $delfldr /S /Q";
		# print "Running $CmdStr\n";
		$CmdRtn = `$CmdStr  2>&1`;
		if ($?)
		{   
			$RtnVal = $CmdStr.' failed : '.$CmdRtn;
			undef($RtnVal);	
		}
		rmdir($delfldr);
}

exit;



my $s=qq(<custom><jar><custom-abag.xml>
			<aag.jar>
		</jar>
		<jsp>
			<abag.jsp>
			<aag_custom.jsp>
		</jsp>
		<report>
			<abag.xml>
			<abag_custom.xml>
		</report>
	</result>);

(my $customxml) = $s =~ /<custom><jar>(.*)jar>/; #split on </inventory> since each record ends with it
print $customxml;
# print Dumper(@s);
# go thru the array and replace all <>
#foreach my $i ( @s) { 
#	$i =~ s/<.*?>//g;
#	print "$i\n";
	# now you left with "total" "in" and "out" with some garbage left.
	# i leave it to you to remove them.
#}














exit;





$branch = "44105";
($branch) = $branch =~ m/^(\d\d\d)/;
print $1;

exit;

$cmd = "Custom/cl_2/cd/";

($objsignore) = $cmd =~ m/^Custom\/(.*)/;
if ($objsignore !~ /\//) {
	print "client core dir";
}

# print $objsignore[0] . "\n" . $objsignore[1];

exit;



$url = '\\atli-fs01\eSolutions_Builds\iVos\iVOS-44015\09-02-2012\iVOS4.4.0.15_9_09-02-2012_11.32';
($blddir) = $url =~ m/.*\\(.*)$/;
print $blddir;

exit;


# Step 2 - Copy Release build
$releasenumber = "9";
$date = "09-02-2012";
# $msg = "Searching the build directory for approved release build...";
my $pwdir = `D:\\ClientDeployment\\test\\44100\\tmp`;
chdir($pwdir);
$TmpFile = "$pwdir\\TmpFile.txt";
my $dbTmpFl = "$pwdir\\DBTmpFile.txt";
my $dbTmpDmlFl = "$pwdir\\DBTmpDmlFile.txt";
open (TMPFILE, ">$TmpFile") || die "Can't open $TmpFile: $!\n";
my $vos_bld_dir = "\\\\atli-fs01\\eSolutions_Builds\\iVos\\iVOS-44015";
find( sub { /^iVOS\d\.\d+\.\d+\.\d+\_$releasenumber\_$date\_\d+\.\d+$/ && print TMPFILE "$File::Find::name" }, $vos_bld_dir);
close(TMPFILE);
open(TMPFILE, $TmpFile) || die("Could not open file!");
@relFileLoc=<TMPFILE>;
close(TMPFILE);
$relFileLoc[0] =~ tr/\//\\/;
print $relFileLoc[0];
exit;

