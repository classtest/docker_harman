#!/usr/local/bin/perl -w
#
use Getopt::Std;
use warnings;
use strict;
use File::Basename;
use File::Find;
use Win32::OLE;
use Time::Local;

sub trim($);

my $CmdStr ="";
my $CmdRtn = "";
my $RtnVal = "";
my $result = "";

my %opts = ();
getopts("f:c:vxh",\%opts);

if ($opts{h}) {
  	PrintHelp();
  	exit 0;
}

if (!$opts{c} || !$opts{f})
{
   	print "ERROR:  Invalid Options\n";
   	PrintHelp();
   	exit 0;
}

my $gcFl = $opts{f};
my $cc_wi_file = $opts{c};

open (FILE, $gcFl) || die "Can't open $gcFl: $!\n";
my @gcfile=<FILE>;
close(FILE);

open (CRWIFL, $cc_wi_file) || die "Can't open $cc_wi_file: $!\n";
my @crfileInfo=<CRWIFL>;
close(CRWIFL);

my @crcchist = ();
foreach my $crwi (@crfileInfo) {
	$crwi = trim($crwi);
	# print $crwi . "\n" ;
	foreach my $gcfl (@gcfile) {
		if ($gcfl =~ "$crwi") {
			$gcfl = trim($gcfl);
			push(@crcchist,$gcfl);
		}
	}
}

open (CFILE, ">41xSpecialHotfixFile.txt");

my %hashHFs = ();
my @uniqueHFs = ();
my @crcchistlist = ();
%hashHFs   = map { $_ => 1 } @crcchist;
@uniqueHFs = keys %hashHFs;
@crcchistlist = sort(@uniqueHFs);

foreach my $cw (@crcchistlist) {
	print CFILE $cw . "\n";
	# print $cw . "\n";
}






#**********************************************************************************************************************************
#  Function :  trim
#  Purpose  :  This function trims the string passed and returned.
#           :  
#  Paramters:  string
#**********************************************************************************************************************************
sub trim($)
{
	my $string = shift;
        if ($string) {
           $string =~ s/^\s+//;
           $string =~ s/\s+$//;
        }
	return $string;
}












# ***************************** User defined functions *****************************
# ***************************** Print Help *****************************
sub PrintHelp
{
   print <<EOF;
   
   usage: $0 -c <CR/WI file name) -f 41x CC version history file

   -f : gc list file name (4160x)

   -v : Verbose mode
   -x : Debug Mode
   -h : Help
EOF
}
