#!/usr/local/bin/perl -w
#
use Getopt::Std;
use warnings;
# use strict;
use File::Basename;
use File::Find;

my $CmdStr ="";
my $CmdRtn = "";
my $RtnVal = "";
my $result = "";

my %opts = ();
getopts("p:f:b:vxh",\%opts);

if ($opts{h}) {
  	PrintHelp();
  	exit 0;
}

# if (!$opts{f} || !$opts{b})
if (!$opts{f})
{
   	print "ERROR:  Invalid Options\n";
   	PrintHelp();
   	exit 0;
}

my $gcFl = $opts{f};

my $TmpFile = '41xDDLs.txt';
open (TMPFILE, ">$TmpFile") || die "Can't open $TmpFile: $!\n";


open(UPGFILE, $gcFl) || die("Could not open file!");
my @DBupgfileInfo=<UPGFILE>;
close(UPGFILE);

my $fullFile = "";
my @newArr = ();
my $cnt = 1;
my $upgFileLst = "";
my $sqlQry = "";
my $tmpVar = "";
my  @dbUpgWIs = ();
my @dbUpgDMLs = ();
my $scmdview = "";


my %BranchHash = ();
%BranchHash = (
        41 => 'M:\\scm_release_41\\ivos\\src\\db',
        416 => 'M:\\scm_ivos4_1_6_0x\\ivos\\src\\db',
        417 => 'M:\\scm_4170x\\ivos\\src\\db'
    );


foreach my $ln (@DBupgfileInfo)
{

	if ($ln =~ m/\s*VOSDF000(.*)\s*/) {
		$fullFile = "";
		($fullFile) = $ln =~ m/\s*VOSDF000(.*)\s*/;
		print $fullFile ."\n";
		# exit;
		push(@dbUpgWIs,$fullFile);
	}
	else {
		$fullFile = "";		
		$ln =~ m/.*\.(.*[.])(sql|trg)$/;
		if (($1) && ($2)) {
			$fullFile = $1 . $2;
			# exit;
			push(@dbUpgDMLs,$fullFile);
		}
	}

}
# $vos_dbbld_view - can create this temp if the following directory is not shared

# my $vos_dbbld_view = "\\\\cbuild1\\scm_view_dbstore\\dbstore";
my $vos_dbbld_view = "D:\\vwstore\\scm_view_dbstore\\dbstore";


open (TMPFILE, ">$TmpFile") || die "Can't open $TmpFile: $!\n";
$DBWIID = "";
foreach $DBWIID (@dbUpgWIs) {
	print "looking for file : $DBWIID \n";
	find( sub { /$DBWIID/ && print TMPFILE "$File::Find::name\n" }, $vos_dbbld_view);
}
close(TMPFILE);
@DBupgfileInfo = ();
open(TMPFILE, $TmpFile) || die("Could not open file!");
@DBupgfileInfo=<TMPFILE>;
close(TMPFILE);
my @prgDBUpgIDs = ();
my $dbUpgFldr = $opts{b} . "_DBUpg";

my $pwdir = `cd`;
chomp($pwdir);

# DDLssss
foreach $DBWIID (@DBupgfileInfo) {
	if  (!$DBWIID) {
		print "Schema DB upgrade script could not found for WI - $DBWIID.\nPossible program DB upgrade script";
		$DBWIID = $DBWIID . "@\\ucm_pvob";
		push(@prgDBUpgIDs,$DBWIID);
	}
	else {
		chomp($DBWIID);
		$DBWIID =~ tr/\//\\/;
		# if ($opts{v}) { print "Found DB directory : $DBWIID\n"; }
		# Copy the ivos.war file from this location and explode
		if ($DBWIID =~ m/_sql/) {
			$CmdStr = "xcopy $DBWIID $pwdir\\$dbUpgFldr\\SQL\\Schema\\* /Q /Y /I";
		}
		elsif ($DBWIID =~ m/_ora/) {
			$CmdStr = "xcopy $DBWIID $pwdir\\$dbUpgFldr\\ORA\\Schema\\* /Q /Y /I";
		}
		if ($opts{v}) { print "Running $CmdStr \n"; }
		$CmdRtn = `$CmdStr 2>&1`;
		if ($?)
		{   
			$RtnVal = $CmdStr.' failed : '.$CmdRtn;
			undef($RtnVal);	
		}
	}	
}






# Triggers, SPs etc - DMLS
my $TmpDMLFile = '41xDMLs.txt';
open (DMLFILE, ">$TmpDMLFile") || die "Can't open $TmpDMLFile: $!\n";
foreach my $DML (@dbUpgDMLs) {
	# print $DMLs ."\n";
	print "looking for file in view - " . $BranchHash{$opts{b}} . " => : $DML \n";
	find( sub { /$DML/ && print DMLFILE "$File::Find::name\n" }, $BranchHash{$opts{b}});
}
close(DMLFILE);
@DBupgfileInfo = ();
open(DMLFILE, $TmpDMLFile) || die("Could not open file!");
@DBupgfileInfo=<DMLFILE>;
close(DMLFILE);
my $dbUpgradeFileList = "";
foreach $dbPrg (@DBupgfileInfo) {
	chomp($dbPrg);
	$dbPrg =~ tr/\//\\/;
	$dbUpgradeFileList .= $dbPrg . "\n";
	if ($dbPrg =~ m/mssql/) {
		$CmdStr = "xcopy $dbPrg $pwdir\\" . $opts{b} . "_DBUpg\\SQL\\Prgm\\* /Q /Y /I";
	}
	elsif ($dbPrg =~ m/oracle/) {
       		$CmdStr = "xcopy $dbPrg $pwdir\\" . $opts{b} . "_DBUpg\\ORA\\Prgm\\* /Q /Y /I";
	}
	if ($opts{v}) { print "Running $CmdStr \n"; }
	$CmdRtn = `$CmdStr 2>&1`;
	if ($?)
	{   
		$RtnVal = $CmdStr.' failed : '.$CmdRtn;
		undef($RtnVal);	
	}
}





# ***************************** User defined functions *****************************
# ***************************** Print Help *****************************
sub PrintHelp
{
   print <<EOF;
   
   usage: $0 -f <GC list file name) -b <41x branch>

   -t : gc list file name (4160x)

   -v : Verbose mode
   -x : Debug Mode
   -e : Email functionality
   -h : Help
EOF
}
	
