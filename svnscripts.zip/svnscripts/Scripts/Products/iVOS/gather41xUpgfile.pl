#!/usr/local/bin/perl -w
#
use Getopt::Std;
use warnings;
use strict;
use File::Basename;
use File::Find;
use Win32::OLE;
use Time::Local;

my $CmdStr ="";
my $CmdRtn = "";
my $RtnVal = "";
my $result = "";

my %opts = ();
getopts("p:f:b:vxh",\%opts);

if ($opts{h}) {
  	PrintHelp();
  	exit 0;
}

if (!$opts{f} || !$opts{b})
{
   	print "ERROR:  Invalid Options\n";
   	PrintHelp();
   	exit 0;
}

my $gcFl = $opts{f};


my $CQSession = "";
my $CQUID = "clearquest-svc";
my $PWD = "U#4=1**]163Yq";
my $CQDB = "VOSDF";
my $CQConnection = "AonCQEnterprise";
my $sqlQuery = "";
my $resultSet = "";

# FetchStatus Constants identify the status of moving the cursor in a request set.
$CQPerlExt::CQ_SUCCESS = 1;  #The next record in the request set was successfully obtained.

$CQSession = SetCQSession($CQUID,$PWD,$CQDB,$CQConnection,\$CQSession);
# my $fullname = $CQSession->GetUserFullName();
#

open(UPGFILE, $gcFl) || die("Could not open file!");
my @upgfileInfo=<UPGFILE>;
close(UPGFILE);


my $cqRptFile = 'CQRpt.txt';
open (CQRPTFILE, ">$cqRptFile") || die "Can't open $cqRptFile: $!\n";

$CmdStr = "cleartool pwv";
if ($opts{v}) { print "Running $CmdStr \n"; }
$CmdRtn = `$CmdStr 2>&1`;
my $pwd = "";
if ($?)
{   
	$RtnVal = $CmdStr.' failed : '.$CmdRtn;
	undef($RtnVal);	
}
$CmdRtn =~ s/\n//; 
($pwd) = $CmdRtn =~ m/\:\s+(.*)Set\s+view\:(.*)/; 

#Get hostName
my $hostid = `hostname`;
chomp($hostid);
if ($hostid eq "cbuild1") {
	$pwd = "C:\\$pwd\\ucm_ivos\\";
}
else {
	$pwd = "C:\\ccstg_c\\$pwd\\ucm_ivos\\";
}

my $pwdir = `cd`;
chomp($pwdir);



my $fullFile = "";
my @newArr = ();
my $cnt = 1;
my $upgFileLst = "";
my $sqlQry = "";
my $tmpVar = "";

my @DBupgfileInfo = ();
my %ViewHash = ();
%ViewHash = (
        41 => 'scm_release_41',
        416 => 'scm_ivos4_1_6_0x',
        417 => 'scm_4170x',
	41701 => 'scm_iVos4.1.7.0.1_QA_RC',
	1354 => 'scm_b1354x',
	1360 => 'scm_b1360x',
	1342 => 'scm_b1342x'
    );

foreach my $ln (@upgfileInfo)
{

	if ($ln =~ /[CQ:]|[CQ :]/i) {
		($tmpVar) = $ln =~ m/CQ:\s*(\d*)/;
		if ($tmpVar){
			# print "found\n$tmpVar\n";
			$tmpVar = "'VOSDF000" . $tmpVar . "'";
			$sqlQry	.= $tmpVar . ",";	
		}
	}


	($fullFile) = $ln =~ m/\s(.*)@@/;
	if ($fullFile) {
		if ($fullFile =~ /\./) {
		
		        $fullFile =~ s/\.java/\.class/;
			$fullFile =~ s/^src\\/WEB-INF\\classes\\/;
			$fullFile =~ s/^rules\\/WEB-INF\\classes\\/;
			$fullFile =~ s/^web//;

			$fullFile =~ s/^src\\WEB-INF\\/WEB-INF\\/;
			$fullFile =~ s/^etc\\licenses\\UC\\/WEB-INF\\/;


			$fullFile =~ s/\\servletdav\\/\\servlet\\/;



	        	$upgFileLst .= "$fullFile\n";
			$fullFile = "ivos\\" . $fullFile;
		        push (@newArr,$fullFile);
			if ($opts{v}) {
				print $cnt 	. "." . $fullFile . "\n";
			}
		}
	}
	else {	
		# print "not found\n";
	}
	$cnt++;

}
(my $TrimCqQry) = $sqlQry =~ m/(.*)\,$/;




# added by Dani on 6/22/2009


# Added by Dani on 04/15/2009 for retrieving all the WIs delivered
# ---------------------------------------------------
# CQ Report for all non - DB change
$sqlQuery = "select \
			distinct \
			T1.dbid \ 
			,T1.id \
			,T16.id \
			,T22.name \
			,T1.headline_3 \
			,T1.db_change \
			,T3.name \
			,T1.resolve_date  \
			,T16.CoreCustom \
		from  \
			task T1 \
			,statedef T3 \
			,statedef T22 \
			,Defect T16 \
			,parent_child_links T16mm \
		where  \
		    T1.state = T3.id  \
		    and T1.dbid = T16mm.child_dbid  \
		    and T16.State = T22.id  \
		    and 16779475 = T16mm.child_fielddef_id   \
		    and T16mm.parent_dbid = T16.dbid   \
		    and (T1.dbid <> 0 and ((T1.id IN ($TrimCqQry))))  \
		ORDER BY T1.id";
		

if ($opts{v}) {
	print "\n\n$sqlQuery\n\n";
	print "\n---------------------------------------------------------------------------------------------------------------\n";
}
$resultSet = $CQSession->BuildSQLQuery($sqlQuery);
$resultSet->Execute();
$cnt = 1;
print  CQRPTFILE "\n\tAll WIs checked in - Report\n";
print  CQRPTFILE "\t*********************************************************************************************************************************\n\n";
		
print(CQRPTFILE pack("A15", "WI ID"));
print(CQRPTFILE pack("A15", "CR ID"));
print(CQRPTFILE pack("A10", "CR State"));
print(CQRPTFILE pack("A12", "Core/Custom"));
print(CQRPTFILE pack("A80", "Headline"));
print(CQRPTFILE pack("A5", "DB?"));
print(CQRPTFILE pack("A10", "WI State"));
print(CQRPTFILE pack("A10", "Resolved Date"));
print  CQRPTFILE "\n-----------------------------------------------------------------------------------------------------------------------------------------------------------\n";

my @dbUpgWIs = ();
my $DBWIID = "";
while($resultSet->MoveNext() == $CQPerlExt::CQ_SUCCESS)
{
	if ($resultSet->GetColumnValue(2)) { 
		print(CQRPTFILE pack("A15", $resultSet->GetColumnValue(2)));
		($DBWIID) = $resultSet->GetColumnValue(2) =~ m/VOSDF000(.*)/;
		push(@dbUpgWIs,$DBWIID);
	}

	# if ($resultSet->GetColumnValue(2)) { print(CQRPTFILE pack("A15", $resultSet->GetColumnValue(2)));}
	# else {print(CQRPTFILE pack("A15", ""));}
	
	if ($resultSet->GetColumnValue(3)) { print(CQRPTFILE pack("A15", $resultSet->GetColumnValue(3)));}
	else {print(CQRPTFILE pack("A15", ""));}
	if ($resultSet->GetColumnValue(4)) { print(CQRPTFILE pack("A10", $resultSet->GetColumnValue(4)));}
	else {print(CQRPTFILE pack("A10", ""));}

	# Core/Custom Addition
	if ($resultSet->GetColumnValue(9)) { print(CQRPTFILE pack("A12", $resultSet->GetColumnValue(9)));}
	else {print(CQRPTFILE pack("A12", ""));}

	if ($resultSet->GetColumnValue(5)) { print(CQRPTFILE pack("A80", $resultSet->GetColumnValue(5)));}
	else {print(CQRPTFILE pack("A80", ""));}
	if ($resultSet->GetColumnValue(6)) { print(CQRPTFILE pack("A5", $resultSet->GetColumnValue(6)));}
	else {print(CQRPTFILE pack("A5", ""));}			
	if ($resultSet->GetColumnValue(7)) { print(CQRPTFILE pack("A10", $resultSet->GetColumnValue(7)));}
	else {print(CQRPTFILE pack("A10", ""));}			
	if ($resultSet->GetColumnValue(8)) { print(CQRPTFILE pack("A10", $resultSet->GetColumnValue(8)));}
	else {print(CQRPTFILE pack("A10", ""));}			
	print(CQRPTFILE "\n");		
}
print  CQRPTFILE "\n-----------------------------------------------------------------------------------------------------------------------------------------------------------\n";
print CQRPTFILE "\n*****************************************************************************************************\n";
print CQRPTFILE "*****************************************************************************************************\n\n";



# ---------------------------------------------------
# CQ Report for all non - DB change
$sqlQuery = "select distinct T1.dbid,T1.id,T16.id,T22.name,T33.Company,T1.headline_3,T1.db_change,T3.name,T1.resolve_date,T16.CoreCustom from \
		task T1,statedef T3, statedef T22, Defect T16,parent_child_links T16mm,Customer T33,parent_child_links T33mm where \
	       	T1.state = T3.id and T1.dbid = T16mm.child_dbid and T16.State = T22.id \
		and 16779475 = T16mm.child_fielddef_id  (+)  and T16mm.parent_dbid = T16.dbid  (+)  and T16.dbid = T33mm.parent_dbid  \
		and 16777880 = T33mm.parent_fielddef_id  (+)  and T33mm.child_dbid = T33.dbid  (+)  and (T1.dbid <> 0 and \
		((T1.id IN ($TrimCqQry)))) ORDER BY T33.Company";	

if ($opts{v}) {
	print "\n\n$sqlQuery\n\n";
	print "\n---------------------------------------------------------------------------------------------------------------\n";
}
$resultSet = $CQSession->BuildSQLQuery($sqlQuery);
$resultSet->Execute();
$cnt = 1;
print  CQRPTFILE "\n\t\t\tClearQuest Report  - All WIs by Customer\n";
print  CQRPTFILE "\t\t\t**************************************************************************\n\n";
		
print(CQRPTFILE pack("A15", "WI ID"));
print(CQRPTFILE pack("A15", "CR ID"));
print(CQRPTFILE pack("A10", "CR State"));
print(CQRPTFILE pack("A12", "Core/Custom"));
print(CQRPTFILE pack("A30", "Customer Name"));		
print(CQRPTFILE pack("A80", "Headline"));
print(CQRPTFILE pack("A5", "DB?"));
print(CQRPTFILE pack("A10", "WI State"));
print(CQRPTFILE pack("A10", "Resolved Date"));
print  CQRPTFILE "\n-----------------------------------------------------------------------------------------------------------------------------------------------------------\n";

# my @dbUpgWIs = ();
# my $DBWIID = "";
while($resultSet->MoveNext() == $CQPerlExt::CQ_SUCCESS)
{
	if ($resultSet->GetColumnValue(2)) { 
		print(CQRPTFILE pack("A15", $resultSet->GetColumnValue(2)));
#		($DBWIID) = $resultSet->GetColumnValue(2) =~ m/VOSDF000(.*)/;
#		push(@dbUpgWIs,$DBWIID);
	}

	# if ($resultSet->GetColumnValue(2)) { print(CQRPTFILE pack("A15", $resultSet->GetColumnValue(2)));}
	# else {print(CQRPTFILE pack("A15", ""));}
	
	if ($resultSet->GetColumnValue(3)) { print(CQRPTFILE pack("A15", $resultSet->GetColumnValue(3)));}
	else {print(CQRPTFILE pack("A15", ""));}
	if ($resultSet->GetColumnValue(4)) { print(CQRPTFILE pack("A10", $resultSet->GetColumnValue(4)));}
	else {print(CQRPTFILE pack("A10", ""));}

	# core/Custom
	if ($resultSet->GetColumnValue(10)) { print(CQRPTFILE pack("A12", $resultSet->GetColumnValue(10)));}
	else {print(CQRPTFILE pack("A12", ""));}			

	if ($resultSet->GetColumnValue(5)) { print(CQRPTFILE pack("A30", $resultSet->GetColumnValue(5)));}
	else {print(CQRPTFILE pack("A30", ""));}
	if ($resultSet->GetColumnValue(6)) { print(CQRPTFILE pack("A80", $resultSet->GetColumnValue(6)));}
	else {print(CQRPTFILE pack("A80", ""));}			
	if ($resultSet->GetColumnValue(7)) { print(CQRPTFILE pack("A5", $resultSet->GetColumnValue(7)));}
	else {print(CQRPTFILE pack("A5", ""));}			
	if ($resultSet->GetColumnValue(8)) { print(CQRPTFILE pack("A10", $resultSet->GetColumnValue(8)));}
	else {print(CQRPTFILE pack("A10", ""));}			
	if ($resultSet->GetColumnValue(9)) { print(CQRPTFILE pack("A10", $resultSet->GetColumnValue(9)));}
	else {print(CQRPTFILE pack("A10", ""));}			
	print(CQRPTFILE "\n");		
}
print  CQRPTFILE "\n-----------------------------------------------------------------------------------------------------------------------------------------------------------\n";


# Addition on Core/Custom date
print CQRPTFILE "\n*****************************************************************************************************\n\n";
print CQRPTFILE ("$TrimCqQry");
print CQRPTFILE "\n\n*****************************************************************************************************\n";
print CQRPTFILE "\n*****************************************************************************************************\n\n";

# Addition of new Report:
# FOR QA - List all the CRs (above report) and also shows if any QA WIs not in CANCELLED STATE





# end of new report


my %actHash = ();
my $SQLQry = "select distinct T1.dbid,T1.id,T16.id,T22.name,T33.Company,T1.headline_3,T1.db_change,T3.name,T1.resolve_date from \
		task T1,statedef T3, statedef T22, Defect T16,parent_child_links T16mm,Customer T33,parent_child_links T33mm where \
	       	T1.state = T3.id and T1.dbid = T16mm.child_dbid and T16.State = T22.id \
		and 16779475 = T16mm.child_fielddef_id  (+)  and T16mm.parent_dbid = T16.dbid  (+)  and T16.dbid = T33mm.parent_dbid  \
		and 16777880 = T33mm.parent_fielddef_id  (+)  and T33mm.child_dbid = T33.dbid  (+)  and (T1.dbid <> 0 and \
		((T1.id IN ($TrimCqQry)))) ORDER BY T33.Company";

print "\n\n" . $SQLQry . "\n\n";


$resultSet = $CQSession->BuildSQLQuery($SQLQry);
$resultSet->Execute();
$cnt = 1;
print  CQRPTFILE "\n\t\t\t (##### OLD REPORT #####) ClearQuest Report  - WIs delivered to ClearCase\n";
print  CQRPTFILE "\t\t\t**************************************************************************\n\n";
		
print(CQRPTFILE pack("A15", "WI ID"));
print(CQRPTFILE pack("A15", "CR ID"));
print(CQRPTFILE pack("A10", "CR State"));
print(CQRPTFILE pack("A30", "Customer Name"));		
print(CQRPTFILE pack("A80", "Headline"));
print(CQRPTFILE pack("A5", "DB?"));
print(CQRPTFILE pack("A10", "WI State"));
print(CQRPTFILE pack("A10", "Resolved Date"));
print  CQRPTFILE "\n-----------------------------------------------------------------------------------------------------------------------------------------------------------\n";
while($resultSet->MoveNext() == $CQPerlExt::CQ_SUCCESS)
{
	if ($resultSet->GetColumnValue(2)) { print(CQRPTFILE pack("A15", $resultSet->GetColumnValue(2)));}
	else {print(CQRPTFILE pack("A15", ""));}
	if ($resultSet->GetColumnValue(3)) { print(CQRPTFILE pack("A15", $resultSet->GetColumnValue(3)));}
	else {print(CQRPTFILE pack("A15", ""));}
	if ($resultSet->GetColumnValue(4)) { print(CQRPTFILE pack("A10", $resultSet->GetColumnValue(4)));}
	else {print(CQRPTFILE pack("A10", ""));}
	if ($resultSet->GetColumnValue(5)) { print(CQRPTFILE pack("A30", $resultSet->GetColumnValue(5)));}
	else {print(CQRPTFILE pack("A30", ""));}
	if ($resultSet->GetColumnValue(6)) { print(CQRPTFILE pack("A80", $resultSet->GetColumnValue(6)));}
	else {print(CQRPTFILE pack("A80", ""));}			
	if ($resultSet->GetColumnValue(7)) { print(CQRPTFILE pack("A5", $resultSet->GetColumnValue(7)));}
	else {print(CQRPTFILE pack("A5", ""));}			
	if ($resultSet->GetColumnValue(8)) { print(CQRPTFILE pack("A10", $resultSet->GetColumnValue(8)));}
	else {print(CQRPTFILE pack("A10", ""));}			
	if ($resultSet->GetColumnValue(9)) { print(CQRPTFILE pack("A10", $resultSet->GetColumnValue(9)));}
	else {print(CQRPTFILE pack("A10", ""));}			
	print(CQRPTFILE "\n");		
}
print  CQRPTFILE "\n-----------------------------------------------------------------------------------------------------------------------------------------------------------\n\n";
print CQRPTFILE "\n\n*********************** ClearQuest Report  - DB WIs delivered to ClearCase***********************************\n";



$SQLQry = "";
# DB Changes - Only DB Changes
$SQLQry = "select distinct T1.dbid,T1.id,T16.id,T22.name,T33.Company,T1.headline_3,T1.db_change,T3.name,T1.resolve_date from \
		task T1,statedef T3, statedef T22, Defect T16,parent_child_links T16mm,Customer T33,parent_child_links T33mm where \
	       	T1.state = T3.id and T1.dbid = T16mm.child_dbid and T16.State = T22.id \
		and 16779475 = T16mm.child_fielddef_id  (+)  and T16mm.parent_dbid = T16.dbid  (+)  and T16.dbid = T33mm.parent_dbid  \
		and 16777880 = T33mm.parent_fielddef_id  (+)  and T33mm.child_dbid = T33.dbid  (+)  and (T1.dbid <> 0 and \
		((T1.id IN ($TrimCqQry)))) and T1.db_change = 'Yes' ORDER BY T33.Company";
print "\n\n" . $SQLQry . "\n\n";

$resultSet = $CQSession->BuildSQLQuery($SQLQry);
$resultSet->Execute();
# push (@DBupgfileInfo,"DDLs\n=====================================\n");
while($resultSet->MoveNext() == $CQPerlExt::CQ_SUCCESS)
{
	if ($resultSet->GetColumnValue(2)) { print(CQRPTFILE pack("A15", $resultSet->GetColumnValue(2)));}
	else {print(CQRPTFILE pack("A15", ""));}
	if ($resultSet->GetColumnValue(3)) { print(CQRPTFILE pack("A15", $resultSet->GetColumnValue(3)));}
	else {print(CQRPTFILE pack("A15", ""));}
	if ($resultSet->GetColumnValue(4)) { print(CQRPTFILE pack("A10", $resultSet->GetColumnValue(4)));}
	else {print(CQRPTFILE pack("A10", ""));}
	if ($resultSet->GetColumnValue(5)) { print(CQRPTFILE pack("A30", $resultSet->GetColumnValue(5)));}
	else {print(CQRPTFILE pack("A30", ""));}
	if ($resultSet->GetColumnValue(6)) { print(CQRPTFILE pack("A80", $resultSet->GetColumnValue(6)));}
	else {print(CQRPTFILE pack("A80", ""));}			
	if ($resultSet->GetColumnValue(7)) { print(CQRPTFILE pack("A5", $resultSet->GetColumnValue(7)));}
	else {print(CQRPTFILE pack("A5", ""));}			
	if ($resultSet->GetColumnValue(8)) { print(CQRPTFILE pack("A10", $resultSet->GetColumnValue(8)));}
	else {print(CQRPTFILE pack("A10", ""));}			
	if ($resultSet->GetColumnValue(9)) { print(CQRPTFILE pack("A10", $resultSet->GetColumnValue(9)));}
	else {print(CQRPTFILE pack("A10", ""));}			
	push (@DBupgfileInfo,$resultSet->GetColumnValue(2));
	print(CQRPTFILE "\n");		
}
print CQRPTFILE "\n*****************************************************************************************************\n\n";




my @fileLst = ();

my @arrDbPrgUpg = "";
my $ChDbfile= "";
my $Chfile = "";
foreach my $group (keys %actHash) {
    # print FILE "The change set for the ClearQuest work item '$group' are, \n";
    foreach my $fullFile (@{$actHash{$group}}) {
	    print "\t$fullFile\n";
           
	    # iVos Upgrade
	    $Chfile = "";
	    ( $Chfile ) = $fullFile =~ m{\\([\w.\w]*)\@\@};

	    # if we need the full file path name here is it.
	    $fullFile =~ s/\@\@.*//s;
	    $fullFile =~ s/^\Q$pwd\E//;
	    if ($fullFile =~ /\./) {
	           	$fullFile =~ s/.java/.class/;
			$fullFile =~ s/\\src\\/\\WEB-INF\\classes\\/;
			$fullFile =~ s/\\rules\\/\\WEB-INF\\classes\\/;
		        $upgFileLst .= "$fullFile\n";
		        push(@fileLst,$fullFile);
	    }
    }	
}



my %hash   = map { $_ => 1 } @newArr;
my @unique = keys %hash;

print "\n****************************\n";


push (@unique,"ivos\\system\\systemInfo.jsp");

$cnt = 1;

my $srcUpgFl = "";
my $destDir = "";
my $destUpgFldr = "";
$gcFl =~ s/.txt//;
my $flnamne = "";
$cnt = 1;
my $missedFiles = "";
my $cntr = 1;

my $baseFile = "";
my $TmpFile = 'TmpFile.txt';
open (TMPFILE, ">$TmpFile") || die "Can't open $TmpFile: $!\n";

my $srcflDir = "";
foreach my $fls (@unique){
	$srcUpgFl = $fls;
	$destDir = dirname($fls);
	$destDir =~ s/^ivos\\//;
	$destUpgFldr =  $gcFl . "_Upg\\$destDir\\";

	if ($fls =~ /login\.jsp/) {
		$destUpgFldr =  $gcFl . "_Upg\\";
		# print "login.jsp found : \n" . "xcopy \"" . $srcUpgFl . "\" \"" . $destUpgFldr . "\" /Q /Y /I\n\n"; 
	}

	$CmdStr = "xcopy \"" . $srcUpgFl . "\" \"" . $destUpgFldr . "\" /Q /Y /I\n";
	print "running $CmdStr\n";
	$CmdRtn = `$CmdStr  2>&1`;
	if ($?)
	{
		print "xcopy failed on : $CmdStr\n";
		$missedFiles = basename($fls);
  	        # DB Upgrade
	        if (($missedFiles =~ m/_sql/) or ($missedFiles =~m/_ora/) or ($missedFiles =~ m/(.*[.])(sql|trg).*/))
	        {
			# $ChDbfile = "";
			# ($ChDbfile) = $fullFile =~ m{\\([\w.\w]*)\@\@};
			if ($missedFiles) {
				push(@DBupgfileInfo,$missedFiles);
	
			}
	        }

		$cntr++;
	}
	else {
		# find out if there are related files with $ sign.

		$baseFile = basename($fls);

		$srcflDir = "ivos\\" . $destDir;

		# Commented on 12/23 for 41 upgrade
		# opendir DIR, $srcflDir or die "cannot open dir $srcflDir: $!"; 

		opendir DIR, $srcflDir or print "cannot open dir $srcflDir: $!";

		my @files= readdir DIR;
		closedir DIR;
		
		foreach my $file (@files) {
			$srcflDir ="ivos\\" . $destDir;
			my $innClfile = $file;
			if ($file =~ m/\$/) {
				$file =~ s/\$\d//g;
				$baseFile =~ s/\.(.*)//;
				if ($file =~ m/$baseFile/) {
					$srcflDir = $srcflDir . "\\$innClfile";
					$CmdStr = "xcopy \"". $srcflDir . "\" \"" . $destUpgFldr . "\" /Q /Y /I\n";
					print "running $CmdStr\n";
					$CmdRtn = `$CmdStr  2>&1`;
					if ($?)
					{
						print "xcopy failed on : $CmdStr\n";
					}
					else {
						$srcflDir =~ s/^ivos\\//;
						$flnamne .= $cnt . "." . $srcflDir . "\n";
						$cnt++;
					}
				}
			}
		}
		$srcUpgFl =~ s/^ivos\\//;
		$flnamne .= $cnt . "." . $srcUpgFl . "\n";
		$cnt++;
	}
}
close(TMPFILE);
@upgfileInfo = ();
open(TMPFILE, $TmpFile) || die("Could not open file!");
@upgfileInfo=<TMPFILE>;
close(TMPFILE);


print "\n\n====================================================\nCopied files\n-------------------------\n$flnamne\n====================================================\n\n";

$destUpgFldr =  $gcFl . "_Upg";

$CmdStr = "wzzip -pr $opts{b}_iVosUpg.zip $destUpgFldr\\*.*";
print "running $CmdStr\n";
$CmdRtn = `$CmdStr  2>&1`;


my %UpgHash = ();
my ($sec, $min, $hr, $day, $mon, $yr) = (localtime)[0,1,2,3,4,5];
$UpgHash{'BldStartTimeInt'} = timelocal($sec, $min, $hr, $day, $mon, $yr); 
$UpgHash{'BldStartTime'} = sprintf("%04d-%02d-%02d_%02d.%02d.%02d", $yr+1900,$mon+1, $day, $hr, $min, $sec);
$UpgHash{'DateStr'} = sprintf("%02d-%02d-%02d", $mon+1, $day, $yr+1900);


my $UpgFldr = $opts{b} . "Upg_" . $UpgHash{'DateStr'};

$CmdStr = "xcopy $opts{b}_iVosUpg.zip $pwdir\\$UpgFldr\\* /Q /Y /I";
if ($opts{v}) { print "Running $CmdStr \n"; }
$CmdRtn = `$CmdStr 2>&1`;
if ($?)
{   
	$RtnVal = $CmdStr.' failed : '.$CmdRtn;
	undef($RtnVal);	
}

$CmdStr = "del $opts{b}_iVosUpg.zip";
if ($opts{v}) { print "Running $CmdStr \n"; }
$CmdRtn = `$CmdStr 2>&1`;
if ($?)
{   
	$RtnVal = $CmdStr.' failed : '.$CmdRtn;
	undef($RtnVal);	
}

$CmdStr = "rmdir $destUpgFldr /S /Q";
if ($opts{v}) { print "Running $CmdStr \n"; }
$CmdRtn = `$CmdStr 2>&1`;
if ($?)
{   
	$RtnVal = $CmdStr.' failed : '.$CmdRtn;
	undef($RtnVal);	
}





my @dbUpgDMLs = ();
@dbUpgWIs = ();
# push (@DBupgfileInfo,"\n\nDMLs\n=====================================\n");

my %dbhash   = map { $_ => 1 } @DBupgfileInfo;
@DBupgfileInfo = keys %dbhash;

foreach my $ln (@DBupgfileInfo)
{

	if ($ln =~ m/\s*VOSDF000(.*)\s*/) {
		$fullFile = "";
		($fullFile) = $ln =~ m/\s*VOSDF000(.*)\s*/;
		print $fullFile ."\n";
		# exit;
		push(@dbUpgWIs,$fullFile);
	}
	else {
		$fullFile = "";		
		$ln =~ m/(.*[.])(sql|trg)$/;
		if (($1) && ($2)) {
			$fullFile = $1 . $2;
			# exit;
			push(@dbUpgDMLs,$fullFile);
		}
	}

}

# $vos_dbbld_view - can create this temp if the following directory is not shared

# my $vos_dbbld_view = "\\\\cbuild1\\scm_view_dbstore\\dbstore";
my $vos_dbbld_view = "D:\\vwstore\\scm_view_dbstore\\dbstore";


open (TMPFILE, ">$TmpFile") || die "Can't open $TmpFile: $!\n";
$DBWIID = "";
foreach $DBWIID (@dbUpgWIs) {
	print "looking for file : $DBWIID \n";
	find( sub { /$DBWIID/ && print TMPFILE "$File::Find::name\n" }, $vos_dbbld_view);
}
close(TMPFILE);
@DBupgfileInfo = ();
open(TMPFILE, $TmpFile) || die("Could not open file!");
@DBupgfileInfo=<TMPFILE>;
close(TMPFILE);
my @prgDBUpgIDs = ();
my $dbUpgFldr = $opts{b} . "_DBUpg";


# DDLssss
foreach $DBWIID (@DBupgfileInfo) {
	if  (!$DBWIID) {
		print "Schema DB upgrade script could not found for WI - $DBWIID.\nPossible program DB upgrade script";
		$DBWIID = $DBWIID . "@\\ucm_pvob";
		push(@prgDBUpgIDs,$DBWIID);
	}
	else {
		chomp($DBWIID);
		$DBWIID =~ tr/\//\\/;
		# if ($opts{v}) { print "Found DB directory : $DBWIID\n"; }
		# Copy the ivos.war file from this location and explode
		if ($DBWIID =~ m/_sql/) {
			$CmdStr = "xcopy $DBWIID $pwdir\\$dbUpgFldr\\SQL\\Schema\\* /Q /Y /I";
		}
		elsif ($DBWIID =~ m/_ora/) {
			$CmdStr = "xcopy $DBWIID $pwdir\\$dbUpgFldr\\ORA\\Schema\\* /Q /Y /I";
		}
		if ($opts{v}) { print "Running $CmdStr \n"; }
		$CmdRtn = `$CmdStr 2>&1`;
		if ($?)
		{   
			$RtnVal = $CmdStr.' failed : '.$CmdRtn;
			undef($RtnVal);	
		}
	}	
}




# Triggers, SPs etc - DMLS
my $TmpDMLFile = '41xDMLs.txt';
open (DMLFILE, ">$TmpDMLFile") || die "Can't open $TmpDMLFile: $!\n";
foreach my $DML (@dbUpgDMLs) {
	# print $DMLs ."\n";
	# M:\\scm_ivos4_1_6_0x\\ivos\\src\\db',
	# M:\\$ViewHash{$opts{b}}\\ivos\\src\\db
	
	$CmdRtn = `cleartool startview $ViewHash{$opts{b}} 2>&1`;

	print "looking for file in view - " . "M:\\" . $ViewHash{$opts{b}} . "\\ivos\\src\\db" . " => : $DML \n";
	find( sub { /$DML/ && print DMLFILE "$File::Find::name\n" }, "M:\\" . $ViewHash{$opts{b}} . "\\ivos\\src\\db");
}
close(DMLFILE);
@DBupgfileInfo = ();
open(DMLFILE, $TmpDMLFile) || die("Could not open file!");
@DBupgfileInfo=<DMLFILE>;
close(DMLFILE);
my $dbUpgradeFileList = "";
foreach my $dbPrg (@DBupgfileInfo) {
	chomp($dbPrg);
	$dbPrg =~ tr/\//\\/;
	$dbUpgradeFileList .= $dbPrg . "\n";
	if ($dbPrg =~ m/mssql/) {
		$CmdStr = "xcopy $dbPrg $pwdir\\" . $opts{b} . "_DBUpg\\SQL\\Prgm\\* /Q /Y /I";
	}
	elsif ($dbPrg =~ m/oracle/) {
       		$CmdStr = "xcopy $dbPrg $pwdir\\" . $opts{b} . "_DBUpg\\ORA\\Prgm\\* /Q /Y /I";
	}
	if ($opts{v}) { print "Running $CmdStr \n"; }
	$CmdRtn = `$CmdStr 2>&1`;
	if ($?)
	{   
		$RtnVal = $CmdStr.' failed : '.$CmdRtn;
		undef($RtnVal);	
	}
}
$CmdStr = "wzzip -pr " . $opts{b} . "_DBUpg.zip  $pwdir\\" . $opts{b} . "_DBUpg\\*.*";
print "running $CmdStr\n";
$CmdRtn = `$CmdStr  2>&1`;


#PACKAGE AND CLEANUP
$CmdStr = "xcopy $opts{b}_DBUpg.zip $pwdir\\$UpgFldr\\* /Q /Y /I";
if ($opts{v}) { print "Running $CmdStr \n"; }
$CmdRtn = `$CmdStr 2>&1`;
if ($?)
{   
	$RtnVal = $CmdStr.' failed : '.$CmdRtn;
	undef($RtnVal);	
}

$CmdStr = "del $opts{b}_DBUpg.zip";
if ($opts{v}) { print "Running $CmdStr \n"; }
$CmdRtn = `$CmdStr 2>&1`;
if ($?)
{   
	$RtnVal = $CmdStr.' failed : '.$CmdRtn;
	undef($RtnVal);	
}

$CmdStr = "rmdir $opts{b}_DBUpg /S /Q";
if ($opts{v}) { print "Running $CmdStr \n"; }
$CmdRtn = `$CmdStr 2>&1`;
if ($?)
{   
	$RtnVal = $CmdStr.' failed : '.$CmdRtn;
	undef($RtnVal);	
}





# ***************************** User defined functions *****************************
# ***************************** Print Help *****************************
sub PrintHelp
{
   print <<EOF;
   
   usage: gather41xUpgfile.pl -f <GC list file name) -p <build location where ivos.war file resides> -b <41x Branch>

   -f : gc list file name (4160x)
   -p : ivos.war file name (optional)
   -b : Branch name (41|416|417|417QARC...)

   -v : Verbose mode
   -x : Debug Mode
   -e : Email functionality
   -h : Help

   	Additional Info
	---------------
        41 => 'M:\\scm_release_41\\ivos',
        416 => 'M:\\scm_ivos4_1_6_0x\\ivos',
        417 => 'M:\\scm_4170x\\ivos',
	41701 => 'M:\\scm_iVos4.1.7.0.1_QA_RC\\ivos'
EOF
}
	





# ***************************** Enable ClearQuest Session *****************************
sub SetCQSession
{
	my ($CQUser,$CQPwd,$CQDB,$CQConn,$CQSessionRef) = @_;
	$$CQSessionRef = Win32::OLE->new("CLEARQUEST.SESSION") or die "Can't create ClearQuest session object via call to Win32::OLE->new(): $!";
	eval
	{
		$$CQSessionRef->UserLogon("$CQUser", "$CQPwd","$CQDB", 2,$CQConn);
	};
	
	my $ufullname = $$CQSessionRef->GetUserFullName();
	if ($ufullname)
        {
		print "ClearQuest Session has established\n"; 
	}
	else {	
		print "Can not establish ClearQuest Session!!!\n"; 	
	}
	return $$CQSessionRef;
}

