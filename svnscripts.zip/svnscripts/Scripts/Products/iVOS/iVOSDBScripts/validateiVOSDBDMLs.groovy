import groovy.sql.*
   
def sql = Sql.newInstance("jdbc:oracle:thin:@atld-vosdb03.int.aonesolutions.us:1521:vosdev", 
	                      "dev_in_progress", 
						  "VosD3v", 
						  "oracle.jdbc.driver.OracleDriver")

def query = 
"""
SELECT object_type, object_name, status
FROM user_objects
WHERE status != 'VALID'
  AND object_type in ('PROCEDURE','TRIGGER','VIEW','FUNCTION')
ORDER BY object_type, object_name
"""

sql.executeUpdate("call DBMS_UTILITY.compile_schema('DEV_IN_PROGRESS')")

sql.eachRow(query) {
	println "$it.object_type\t$it.object_name;"
}

