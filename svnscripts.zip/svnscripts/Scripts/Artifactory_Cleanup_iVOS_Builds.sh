#!/bin/sh

# ##########################################################################
# Harman Connected Services Artifactory Cleanup Script
#
# Copyright (C) 2018 Harman Connected Services, Inc. All Rights Reserved.
#
# This software is confidential and proprietary information of
# Harman Connected Services, Inc. ("Confidential Information"). 
# 
# For more information, visit https://services.harman.com
#
# Version	: 1.0
# Last updated	: June 18, 2018
# Authors	: Subhash (sdelhi) & Bhagyaraj (bdesuri)
# Purpose	: Artifactory Cleanup
#
# ###########################################################################

artifactoryUrl="https://artifactory.corp.ventivtech.com/artifactory"
artifactoryStorUrl="https://artifactory.corp.ventivtech.com/artifactory/api/storage"
repoName="iVOS"
outputFile="fldrList.log"

curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoName} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | grep -P '^(4)|^(5)|^in-progress$' > ${outputFile}
chmod a+x ${outputFile}

while read -r repodir; do
    
    echo ""
    echo "Build Version is : ${repodir}"
    echo "Repo path is : ${artifactoryUrl}/${repoName}/${repodir}"
   	
    curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoName}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > $repodir.log

    repoVal=`echo $repodir | cut -c1`	
    buildCount=`cat $repodir.log | wc -l`
	
    if [[ ${repoVal} -eq "4" ]] && [[ ${buildCount} -gt "3" ]]; then
	echo "Expected count is : 3 or above"
	echo "$repodir count is : ${buildCount} GREATER THAN 3."
	
	curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoName}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | grep -e '^b' | sort -n | head -n -3 > 4xBuilds.log

#	curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoName}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | grep -e '^ETL' | sort -n | head -n -3 > 4xEtlBuilds.log
		
while read -r arcBuild; do

    noProp=`curl -s -k -u upload:upload "${artifactoryStorUrl}/${repoName}/${repodir}/${arcBuild}?properties" | grep -i "No properties could be found" | awk '{print substr($0,(length($0)-30))}'`
    keepForever=`curl -s -k -u upload:upload "${artifactoryStorUrl}/${repoName}/${repodir}/${arcBuild}?properties" | grep -i "scm.keepForever" | awk {'print $1'}`

    echo ""	
    echo "Build Number is : ${arcBuild}"
    echo "noProp=${noProp}"
    echo "keepForever=${keepForever}"

    if [[ ${noProp} == '"No properties could be found."' ]]; then
	echo "DELETING: No property set for build # ${arcBuild}. Hence deleting from artifactory."
	curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoName}/${repodir}/${arcBuild}"

    elif [[ ${keepForever} == '"scm.keepForever"' ]]; then
	echo "KEEP FOR EVER: 'scm.keepForever' property set for build # ${arcBuild}. Hence preserving this build forever in artifactory."

    else
	echo "ERROR: Issue in executing. Please check with admin and run again. Quitting the process."
	exit 0
    fi
    done < 4xBuilds.log

# ---------------
# ETL Builds
# ----------------

#while read -r EtlarcBuild; do

#  EtlnoProp=`curl -s -k -u upload:upload "${artifactoryStorUrl}/${repoName}/${repodir}/${EtlarcBuild}?properties" | grep -i "No properties could be found" | awk '{print substr($0,(length($0)-30))}'`
#  EtlkeepForever=`curl -s -k -u upload:upload "${artifactoryStorUrl}/${repoName}/${repodir}/${EtlarcBuild}?properties" | grep -i "scm.keepForever" | awk {'print $1'}`

#    echo ""
#    echo "ETL Build Number is : ${EtlarcBuild}"
#    echo "EtlnoProp=${EtlnoProp}"
#    echo "EtlkeepForever=${EtlkeepForever}"

#    if [[ ${EtlnoProp} == '"No properties could be found."' ]]; then
#       echo "DELETING: No property set for build # ${EtlarcBuild}. Hence deleting from artifactory."
#      curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoName}/${repodir}/${EtlarcBuild}"

#    elif [[ ${EtlkeepForever} == '"scm.keepForever"' ]]; then
#         echo "KEEP FOR EVER: 'scm.keepForever' property set for build # ${EtlarcBuild}. Hence preserving this build forever in artifactory."

#    else
#         echo "ERROR: Issue in executing. Please check with admin and run again. Quitting the process."
#         exit 0
#    fi
#    done < 4xEtlBuilds.log

	
    elif [[ ${repoVal} -eq "5" ]] && [[ ${buildCount} -gt "5" ]]; then
	echo "Expected count is : 5 or above"
	echo "$repodir count is : ${buildCount} GREATER THAN 5."

	curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoName}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | grep -e '^b' | sort -n | head -n -5 > 5xBuilds.log

#	curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoName}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | grep -e '^ETL' | sort -n | head -n -5 > 5xEtlBuilds.log


while read -r arcBuild; do

    noProp=`curl -s -k -u upload:upload "${artifactoryStorUrl}/${repoName}/${repodir}/${arcBuild}?properties" | grep -i "No properties could be found" | awk '{print substr($0,(length($0)-30))}'`
    keepForever=`curl -s -k -u upload:upload "${artifactoryStorUrl}/${repoName}/${repodir}/${arcBuild}?properties" | grep -i "scm.keepForever" | awk {'print $1'}`

    echo ""
    echo "Build Number is : ${arcBuild}"
    echo "noProp=${noProp}"
    echo "keepForever=${keepForever}"

    if [[ ${noProp} == '"No properties could be found."' ]]; then
       echo "DELETING: No property set for build # ${arcBuild}. Hence deleting from artifactory."
       curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoName}/${repodir}/${arcBuild}"
        
    elif [[ ${keepForever} == '"scm.keepForever"' ]]; then
         echo "KEEP FOR EVER: 'scm.keepForever' property set for build # ${arcBuild}. Hence preserving this build forever in artifactory."

    else
         echo "ERROR: Issue in executing. Please check with admin and run again. Quitting the process."
         exit 0
    fi
    done < 5xBuilds.log

# ---------------     
# ETL Builds
# ---------------

#while read -r EtlarcBuild; do

#   EtlnoProp=`curl -s -k -u upload:upload "${artifactoryStorUrl}/${repoName}/${repodir}/${EtlarcBuild}?properties" | grep -i "No properties could be found" | awk '{print substr($0,(length($0)-30))}'`
#   EtlkeepForever=`curl -s -k -u upload:upload "${artifactoryStorUrl}/${repoName}/${repodir}/${EtlarcBuild}?properties" | grep -i "scm.keepForever" | awk {'print $1'}`

#   echo ""
#   echo "ETL Build Number is : ${EtlarcBuild}"
#   echo "EtlnoProp=${EtlnoProp}"
#   echo "EtlkeepForever=${EtlkeepForever}"

#   if [[ ${EtlnoProp} == '"No properties could be found."' ]]; then
#      echo "DELETING: No property set for build # ${EtlarcBuild}. Hence deleting from artifactory."
#     curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoName}/${repodir}/${EtlarcBuild}"

#   elif [[ ${EtlkeepForever} == '"scm.keepForever"' ]]; then
#        echo "KEEP FOR EVER: 'scm.keepForever' property set for build # ${EtlarcBuild}. Hence preserving this build forever in artifactory."

#   else
#        echo "ERROR: Issue in executing. Please check with admin and run again. Quitting the process."
#        exit 0
#   fi
#   done < 5xEtlBuilds.log

	
   elif [[ ${repodir} == "in-progress" ]] && [[ ${buildCount} -gt "10" ]]; then
	echo "Expected count is : 10 or above"
	echo "$repodir count is : ${buildCount} GREATER THAN 10."

	curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoName}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | grep -e '^b' | sort -n | head -n -10 > inprsBuilds.log
	
#	curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoName}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | grep -e '^ETL' | sort -n | head -n -10 > inprsEtlBuilds.log

     
while read -r arcBuild; do

    noProp=`curl -s -k -u upload:upload "${artifactoryStorUrl}/${repoName}/${repodir}/${arcBuild}?properties" | grep -i "No properties could be found" | awk '{print substr($0,(length($0)-30))}'`
    keepForever=`curl -s -k -u upload:upload "${artifactoryStorUrl}/${repoName}/${repodir}/${arcBuild}?properties" | grep -i "scm.keepForever" | awk {'print $1'}`

    echo ""
    echo "Build Number is : ${arcBuild}"
    echo "noProp=${noProp}"
    echo "keepForever=${keepForever}"

    if [[ ${noProp} == '"No properties could be found."' ]]; then
       echo "DELETING: No property set for build # ${arcBuild}. Hence deleting from artifactory."
       curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoName}/${repodir}/${arcBuild}"
       
    elif [[ ${keepForever} == '"scm.keepForever"' ]]; then
         echo "KEEP FOR EVER: 'scm.keepForever' property set for build # ${arcBuild}. Hence preserving this build forever in artifactory."

    else
         echo "ERROR: Issue in executing. Please check with admin and run again. Quitting the process."
         exit 0
    fi
    done < inprsBuilds.log
     
# ---------------
# ETL Builds
# ---------------

#while read -r EtlarcBuild; do

#  EtlnoProp=`curl -s -k -u upload:upload "${artifactoryStorUrl}/${repoName}/${repodir}/${EtlarcBuild}?properties" | grep -i "No properties could be found" | awk '{print substr($0,(length($0)-30))}'`
#  EtlkeepForever=`curl -s -k -u upload:upload "${artifactoryStorUrl}/${repoName}/${repodir}/${EtlarcBuild}?properties" | grep -i "scm.keepForever" | awk {'print $1'}`

#    echo ""
#    echo "ETL Build Number is : ${EtlarcBuild}"
#    echo "EtlnoProp=${EtlnoProp}"
#    echo "EtlkeepForever=${EtlkeepForever}"

#    if [[ ${EtlnoProp} == '"No properties could be found."' ]]; then
#       echo "DELETING: No property set for build # ${EtlarcBuild}. Hence deleting from artifactory."
#      curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoName}/${repodir}/${EtlarcBuild}"

#    elif [[ ${EtlkeepForever} == '"scm.keepForever"' ]]; then
#         echo "KEEP FOR EVER: 'scm.keepForever' property set for build # ${EtlarcBuild}. Hence preserving this build forever in artifactory."

#    else
#         echo "ERROR: Issue in executing. Please check with admin and run again. Quitting the process."
#         exit 0
#    fi
#    done < inprsEtlBuilds.log

    else
	echo "Expected counts are : 4x(Builds: 3), 5x(Builds: 5), in-progress(Builds: 10) or above"
	echo "$repodir count is : ${buildCount} LESSER THAN expected. Hence SKIPPING verification process."
    fi

done < "${outputFile}"
# =================================================*** SCRIPT ENDS HERE ***==================================================
