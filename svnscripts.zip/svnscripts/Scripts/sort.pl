#!/usr/local/bin/perl -w
#
# This program should go through the comment input file and extract the story list.
# Then it should copy the db scripts from the extracted branch to create the story list for the release.
# created by Dani on 10/13 for the new db tool feed.


use strict;
use Time::Local;
use Getopt::Std;
my %opts = ();
use File::Find;
use File::Basename;


getopts("f:vxh",\%opts);

if ($opts{h}) {
  	PrintHelp();
  	exit 0;
}

# Validation part
if (!$opts{f})
{
   	print "ERROR:  Invalid Options\n";
   	PrintHelp();
   	exit 0;
}

# Locate DB scripts part
my $dblogfl = $opts{f};


my $CmdRtn = "";
my $RtnVal = "";
my $CtRet = "";
my $CmdStr = "";

open (DBLOGFILE, "$dblogfl") || die "Can't open $dblogfl: $!\n";
my @arrDbLog=<DBLOGFILE>;
close(DBLOGFILE);
my $dbid = "";
my @alldbids = ();
foreach my $lg (@arrDbLog) {
	if ($lg =~ m/^(VOSDF|V).*/i){
		push(@alldbids,$lg);
	}
}

my %hashHFs   = map { $_ => 1 } @alldbids;
my @uniqueDBIDs = keys %hashHFs;
@uniqueDBIDs = sort(@uniqueDBIDs);

foreach (@uniqueDBIDs) {
	print $_;
}





# *************************************************************************************************************************
# *************************************************************************************************************************
# *************************************************************************************************************************

# Functions 

# ***************************** Print Help *****************************
sub PrintHelp
{
   print <<EOF;
   
   usage: $0 -f <path to file including file name>

   Eg : perl -w $0 -f svndblog.txt

   -f : path to the log file with file name
   
   -v : Verbose mode
   -x : Debug Mode
   -h : Help
EOF
}



#**********************************************************************************************************************************
#  Function :  trim
#  Purpose  :  This function trims the string passed and returned.
#           :  
#  Paramters:  string
#**********************************************************************************************************************************
sub trim
{
	my $string = shift;
        if ($string) {
           $string =~ s/^\s+//;
           $string =~ s/\s+$//;
        }
	return $string;
}







# test
# test hook
#test