#!/usr/local/bin/perl -w
#

$dirname = 'C:\DBDMLGEN\iVOS_IP_11-07-2011_1320696456\sql';
$dirname = 'C:\DBDMLGEN\iVOS_IP_11-08-2012_1352396303';


opendir my($dh), $dirname or die "Couldn't open dir '$dirname': $!";
my @files = readdir $dh;
closedir $dh;


foreach(@files) {
	print $_ . "\n";
	if($_ !~ /^(.|..)$/) {
		chdir($dirname);
		$cmdstr = "rename \"$_\" \"$_.txt\"";
		print $cmdstr;
		`$cmdstr`;

	}


}

exit;



