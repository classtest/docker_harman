#!/usr/local/bin/perl -w

use Getopt::Std;

my %opts = ();
getopts("f:vxh",\%opts);

if ($opts{h}) {
  	PrintHelp();
  	exit 0;
}
if(!$opts{f})
{
   	print "ERROR:  Invalid Options\n";
   	PrintHelp();
   	exit 0;
}

my $CQRpt = $opts{f};

open(CQRPT, $CQRpt) || die("Could not open file $CQRpt!");
my @arrCQRpt=<CQRPT>;
my @crList = ();

foreach my $cRpt (@arrCQRpt) {
	if ($cRpt =~ m/^VOSDF000/) {
		if ($cRpt !~ m/Not matched with any pattern/) {
			$cRpt =~ m/^(VOSDF[\d]*)\s+(VOSDF[\d]*)\s+/;
			if ($2) {
				push(@crList,$2);
			}
		}	
	}
}


my %hash   = map { $_ => 1 } @crList;
my @unique = keys %hash;

if ($opts{v}) { print "-------------------------------------\n";}
@unique = sort(@unique);
my $sqlQry = "";
foreach (@unique) {
	if ($_) {
		$sqlQry .= "'$_',";
	}
}
$sqlQry =~  m/(.*)\,$/;

$sqlQry = "select distinct T1.dbid,T1.id,T1.Headline,T22.name,T1.resolve_date from Defect T1,statedef T22 where T1.State = T22.id and (T1.dbid <> 0 and T1.id IN ($1))";

print $sqlQry;



sub PrintHelp
{
   print <<EOF;
   
   usage: $0 -f CQRpt.exe (or the CQ Report file from upgrade package)

   (Mandatory)
   -f : input file (CQRpt.exe)

   (Optional arguments)
   -v : Verbose mode
   -x : Debug Mode
   -h : Help
EOF
}
