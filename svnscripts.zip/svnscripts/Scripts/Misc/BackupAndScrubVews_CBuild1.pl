#!/usr/local/bin/perl -w


# This program accepts the parameters 'n' as name of the view and 'b' as the backup folder and 'l' as the location of the view folder
# This should list the property of the view - for checking whether the view exists of not, if exists back up the view
# Once the backing up is completed, remove the view. Once the view is gone, we need to get rid of the all the folders inside that view 
# and delete the view folder it self for scrubbing.
# Written by Dani on 12/22/2008


# ****************************** This program is removeing and backing on the snapshot views!!! *************************************
# This program is mainly intended to build PC views (old 41 and 13x views)

use Getopt::Std;
use warnings;
use strict;
use Time::Local;
# use Data::Dumper;
use Win32::OLE;
use Carp qw( carp );
	
my %opts = ();
getopts("n:b:l:vxh",\%opts);

if ($opts{h}) {
  	PrintHelp();
  	exit 0;
}
if((!$opts{n}) || (!$opts{b}) || (!$opts{l}))
{
   	print "ERROR:  Invalid Options\n";
   	PrintHelp();
   	exit 0;
}

# ===============================================================================================
my $CCViewName = $opts{n};
my $CCViewBackupDir = $opts{b};
my $CCViewStDir = $opts{l};

my $CmdStr = "";
my $CmdRtn = "";
my $RtnVal = "";

chdir "$CCViewStDir" || die "Cannot cd to $CCViewStDir";

# lsview
$CmdStr = "cleartool lsview $CCViewName";
if ($opts{v}) { print "Running $CmdStr \n"; }
$CmdRtn = `$CmdStr 2>&1`;
if ($?)
{   
	$RtnVal = $CmdStr.' failed : '.$CmdRtn;
	print $RtnVal;
	undef($RtnVal);	
}
else {
	if ($opts{v}) { print "$CmdRtn\n"; }	

	# back up the view
	$CmdStr = "xcopy $CCViewStDir\\$CCViewName $CCViewBackupDir\\$CCViewName\\* /Q /Y /I /E";
	if ($opts{v}) { print "Running $CmdStr \n"; }
	$CmdRtn = `$CmdStr 2>&1`;
	if ($?)
	{   
		$RtnVal = $CmdStr.' failed : '.$CmdRtn;
		print $RtnVal . "\n";
		undef($RtnVal);	
	}
	else {

		if ($opts{v}) { print "Backing up the view has completed....\n$CmdRtn\n"; }	
		
		# remove up the view
		$CmdStr = "cleartool rmview $CCViewName";
		if ($opts{v}) { print "Running $CmdStr \n"; }
		$CmdRtn = `$CmdStr 2>&1`;
		if ($?)
		{   
			$RtnVal = $CmdStr.' failed : '.$CmdRtn;
			print $RtnVal . "\n";
			undef($RtnVal);	
		}
		else {
			if ($opts{v}) { print "Backing up the view $CCViewName has completed....\n$CmdRtn\n"; }	

			# Clear the view folder and all its left out subfolders and files
			$CmdStr = "rmdir $CCViewStDir\\$CCViewName /S /Q";
			if ($opts{v}) { print "Running $CmdStr \n"; }
			$CmdRtn = `$CmdStr 2>&1`;
			if ($?)
			{   
				$RtnVal = $CmdStr.' failed : '.$CmdRtn;
				print $RtnVal . "\n";
				undef($RtnVal);	
			}
			else {
				if ($opts{v}) { print "view folder $CCViewName has removed from $CCViewStDir....\n$CmdRtn\n"; }	
				print "\t************ View $CCViewName has removed successfully ************\n";
			
			}

		}

	}
}
			





# ===============================================================================================

sub PrintHelp
{
   print <<EOF;
   
   usage: perl -w iVos_ucm_Upg.pl -n <view name> -b <bakup directory> -l <view folder location> [-d] [-v] [-x]

   -n : view name
   -b : backup directory name
   -l : build location

   -v : Verbose mode
   -x : Debug Mode
   -h : Help
EOF
}




