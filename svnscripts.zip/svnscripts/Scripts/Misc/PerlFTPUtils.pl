#!/usr/local/bin/perl -w


# Created by Dani on 1/6/2009 for FTP Utils.
# PerlFTPUtils
# FTP Retrieve
# FTP Upload
#    RETR: Retrieve (get) a file from the server.
#    STOR: Store (put) a file on the server, overwriting it if it's already there.
#    STOU: Store (put) a file on the server by generating a unique name.
#    APPE: Append to a file on the server. 

ftpUpload();


sub ftpUpload
{
	use Net::FTP;
	use Fcntl qw(O_WRONLY O_RDONLY O_APPEND O_CREAT O_TRUNC);

	my $dns    = 'vosftp.valleyoakasp.com';
	my $user   = 'wsi';
	my $passwd = 'TGw2XRMG*@';
	

	my $ftp = Net::FTP->new( $dns, Debug => 0 ) 
	  or die "Cannot connect to $dns: $@";
	$ftp->login( $user, $passwd )
	  or die "Cannot login ", $ftp->message;


	# ********** UPLOAD TO FTP WITH OVERWRITE *************
	$ftp->cwd("iVOS 422 Build")
    		or die "Cannot change working directory ", $ftp->message;

	$directory = 'Z:\BiWeeklyBuilds\REL4.2.2.0.x\01-01-2009\iVos4.2.2.0.0_79_2009-01-01_21.00.02';
	
	# Create biweekly build directory - date and build folders
	my $ftpnewdir = "";
	my $ftpnewdirpath = "";
	
	$ftpnewdir = $directory;

	my ($ftpblddir) = $ftpnewdir =~ m/([\w\d|\.\_\-]*)$/;

	$ftpnewdirpath = substr ($ftpnewdir, 0,length($ftpnewdir)-(length($ftpblddir)+1));
	my ($ftpblddatedir) = $ftpnewdirpath =~ m/([\w\d|\.\_\-]*)$/;
	#print $ftpblddatedir;
	
	# $ftpblddatedir =~ s/-//g;

	$ftpnewdirpath = substr ($ftpnewdirpath, 0,length($ftpnewdirpath)-(length($ftpblddatedir)+1));
	$ftpnewdirpath .= "$ftpblddatedir";

	#print $ftpblddatedir . "\n";
	#print $ftpnewdirpath . "\n";

	$ftpnewdir = $ftpnewdirpath . "\\$ftpblddir";
	#print $ftpblddir . "\n";
	#print $ftpnewdir . "\n";
	

	$ftp->mkdir($ftpblddatedir) or die "Cannot create directory $ftpblddatedir ", $ftp->message;
	$ftp->cwd($ftpblddatedir) or die "Cannot change working directory $ftpnewdirpath", $ftp->message;

	$ftp->mkdir($ftpblddir) or die "Cannot create directory $ftpblddir ", $ftp->message;
	$ftp->cwd($ftpblddir)  or die "Cannot change working directory $ftpnewdir", $ftp->message;


	# set binary mode which is needed for image upload
	$ftp->binary();
	
	opendir(DIR, "$directory");
	my @files = readdir(DIR);
	
	foreach my $file (@files)
	{
	    	if (not -d $file)      	{
	        	# make sure the names are lower case on the server
		        $file = lc($file);
        		# upload the file
	        	$ftp->put("$directory\\$file");
        	}
    	}

 	
	# ********** READ DATA *************	

	# Retriieve iVos.war file iVos directory
	# my $dir    = 'iVOS';
	# $ftp->cwd($dir)
	#  or die "Cannot change working directory ", $ftp->message;

	# my ( $loc, $buf, $data );
	# my ( $remote, $local );
	# $remote = $local = 'ivos.war';

	# $data = $ftp->retr($remote)
	#  or die "unable to retrieve $remote\n";

	# unless ( sysopen( $loc, $local, O_WRONLY | O_TRUNC | O_CREAT ) ) { 
	#    die "Cannot open $local: $!\n";
	# }

	# while ( my $len = $data->read( $buf, 2048 ) ) { 
	#	printf( " %d bytes read\n", $len );

	#	unless ( print $loc $buf ) { 
	#		die "Cannot write to $local: $!\n";
	#	        $data->abort;
	#		close($loc);
	#	}   
	# }
	# print "Total read : ", $data->bytes_read(), "\n";

	# $data->close;
	
	$ftp->quit;
}
