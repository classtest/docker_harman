#!/usr/local/bin/perl -w

use Getopt::Std;

my %opts = ();
getopts("f:vxh",\%opts);

if ($opts{h}) {
  	PrintHelp();
  	exit 0;
}
if(!$opts{f})
{
   	print "ERROR:  Invalid Options\n";
   	PrintHelp();
   	exit 0;
}

my $linkFile = $opts{f};

open(TMPFILE, $linkFile) || die("Could not open file!");
my @allLinks=<TMPFILE>;

my @fileNames = ();


foreach my $fl (@allLinks) {
	$fl =~ m/([\w]*)\\([\w]*)\\([\w.\w]*)$/;
	if ($1) {
		#	push (@fileNames,"$cnt. $1\\$2\\$3");
		push (@fileNames,"$1\\$2\\$3");

	}
}

@fileNames = sort(@fileNames);

#my $cnt = 1;
#foreach (@fileNames) {
#	print $cnt . ". " . $_. "\n";
#	$cnt++;
#}


foreach (@fileNames) {
	print $_. "\n";
}



sub PrintHelp
{
   print <<EOF;
   
   usage: perl -w iVos_ucm_Upg.pl -f <file> [-d] [-v] [-x]

   -f : To Baseline

   -v : Verbose mode
   -x : Debug Mode
   -e : Email functionality
   -h : Help
EOF
}
