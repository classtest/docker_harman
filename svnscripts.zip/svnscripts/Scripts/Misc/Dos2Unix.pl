#!/usr/local/bin/perl -w
# Written by Dani on 1/12/2009
#
#
use Getopt::Std;
use warnings;
use strict;

my %opts = ();

getopts("p:vxh",\%opts);

if ($opts{h}) {
  	PrintHelp();
  	exit 0;
}

if (!$opts{p})
{
   	print "ERROR:  Invalid Options : Please specify the root of the directory\n";
   	PrintHelp();
   	exit 0;
}

my $CmdRtn = "";
my $RtnVal = "";
my $CmdStr = "";

my $base_path = $opts{p};
my @allfiles = process_files ($base_path);

my $num = 1;
foreach my $fl (@allfiles) {
	
	$fl =~ s/\\/\//g;
	# if ($fl =~ m/.*\/(.*[.])(html|xml|jsp|js)$/) {
		# Execute the dos2unix command here on the file
		$CmdStr = "DOS2UNIX $base_path\\$fl";
		if ($opts{v}) {
		 	print "$CmdStr\n";
		}
		$CmdRtn = `$CmdStr 2>&1`;
		if ($?)
		{   
			$RtnVal = 'Error : ' . $CmdStr.' failed : '.$CmdRtn . '\n';
			print $RtnVal . "\n";
			undef($RtnVal);	
		}
		else {
			print "$num. " . $fl . "\n";
			$num++;
		}
	#}
}
# *********************************************************************************






# Accepts one argument: the full path to a directory.
# Returns: A list of files that reside in that path.
sub process_files {
    my $db_dir = shift;



    opendir(DIR, $db_dir) || print "can't opendir $db_dir: $!";
    my @a = ();
    @a =  sort {(stat "$db_dir/$a")[9] <=> (stat "$db_dir/$b")[9]}
    	  grep {  -f "$db_dir/$_" }
	  readdir(DIR);
    closedir DIR;
    return @a;
}





sub PrintHelp
{
   print <<EOF;
   
   usage: $0 -p path to the ivos directory

   -v : Verbose mode
   -x : Debug Mode
  
   -h : Help
EOF
}

