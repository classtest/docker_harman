#!/usr/local/bin/perl -w
#
#

use Getopt::Std;
my %opts = ();

getopts("p:vxh",\%opts);

if ($opts{h}) {
  	PrintHelp();
  	exit 0;
}
if(!$opts{p})
{
  	print  "Invalid options\n";
	PrintHelp();
	exit;
}

use File::Find;
use File::Basename;

my $FullFileList = 'FullFileList.txt';
open (FLLST, ">$FullFileList") || die "Can't open $FullFileList : $!\n";
find( sub { // && print FLLST "$File::Find::name\n" },$opts{p});
close(FLLST);
open(FLLST, $FullFileList) || die("Could not open file $FullFileList!");
my @fls=<FLLST>;
close(FLLST);
@fls = sort(@fls);

my $flName = "";
my $fullfile = "";
my @dirs = ();
my @files = ();
foreach my $fullfl (@fls){
	$flName = "";
	$flName = basename($fullfl);
	if ($flName =~ m/\./) {
		# ($fullfile) = $fullfl =~ m/(.*)/;
		# print $fullfile;
		# exit;
		$fullfl =~ tr/\//\\/;
		push(@files,$fullfl);
	}
	$flName = dirname($fullfl);
	push (@dirs,$flName);
}

my $cnt = 1;

my %hash = ();

%hash = ();
%hash   = map { $_ => 1 } @files;
@files = keys %hash;
@files = sort (@files);
# print "Full file names : \n-----------------------------------\n";
$cnt = 1;
foreach (@files) {
	# print "$cnt. $_";
	$cnt++;
}

$pwd = `pwd`;
chomp($pwd);
$pwd =~ tr/\//\\/;

my $bsName = "";
my $drName = "";
my $bsFlName = basename($opts{p});
my $fulllFinalFile = "";
print "File list : \n-----------------------------------\n";
foreach my $fl (@files) {
	$bsName = basename($fl);
	$drName = dirname($fl);

	$drName =~ m/([\w]*)\\([\w]*)$/;
	$fulllFinalFile = "$1\\$2\\$bsName";
	$fulllFinalFile =~ s/$bsFlName\\//;
	push (@fileNames,$fulllFinalFile);
}
@fileNames = sort(@fileNames);

$cnt = 1;
foreach (@fileNames) {
	print $cnt . ". " . $_;
	$cnt++;
}


# foreach (@fileNames) {
#	print $_. "\n";
#}
exit;

%hash = ();
%hash   = map { $_ => 1 } @dirs;
@dirs = keys %hash;
@dirs = sort (@dirs);
print "Directory names : \n-----------------------------------\n";
$cnt = 1;
foreach (@dirs) {
	print "$cnt. $_\n";
	$cnt++;
}

exit;

recurse_dir_new($opts{p});


sub process_file {
    my $fl = shift;
    #open F, shift;
    print "in File\n";
    push(@fls,$fl);
    # close F;
}

sub recurse_dir {
        my $dir  = shift;
	print "in recurse dir**************\n";
	opendir(DIR,$dir);
	# @files = ();
	# @files = readdir(DIR);
	while (readdir DIR) {
	    if (-d) {
        	recurse_dir($_) unless ($_ eq '.' or $_ eq '..')
	        }
	    else {
        	process_file($_) if -f
	        }
	    }
        closedir DIR;
}



sub recurse_dir_new {
   my $dir = shift();

   opendir D, $dir;
   while (readdir D) {
      process_file ($dir/$_) if -f $dir/$_;
      recurse_dir_new  ($dir/$_) if -d _;
   }
   closedir D;
}


@fls = sort(@fls);
$cnt = 1;
foreach (@fls){
	# if ($_ !~ m/./) {
		print "$cnt. $_\n";
		$cnt++;
	# }
}







# ***************************** User defined functions *****************
# ***************************** Print Help *****************************
sub PrintHelp
{
   print <<EOF;

   usage: $0 -p 

   All optional arguments :

   -p : Path to the directory where you need to read the files names and format

   -v : Verbose mode
   -x : Debug Mode
   -h : Help
EOF
}



