#!/usr/local/bin/perl -w
use strict;

	my $pwdir = 'C:\scm_SCMUtils\SCMUtils';
		
	my $dbUpgFolder = 'Misc';

	my $dbdir = "";
	my $dbUpgMode = "";
	my $cnCDbfl = "";
	
	# Concatenate Oracle DB Upgrade scripts
	$cnCDbfl = "";
	chdir $pwdir || die "Cannot cd to $pwdir";
	$dbdir = "$dbUpgFolder\\ORA\\Schema";
	$dbUpgMode = "ORA";
	$cnCDbfl .= "\n\n/* ******************** DDLs (Schema) ******************** */\n\n";
	$cnCDbfl .= dbFlConcat($dbdir,$dbUpgMode,$pwdir); 

	chdir $pwdir || die "Cannot cd to $pwdir";
	$dbdir = "$dbUpgFolder\\ORA\\Prgm";
	$dbUpgMode = "ORA";
	$cnCDbfl .= "\n\n/* ******************** DMLs (Schema) ******************** */\n\n";
	$cnCDbfl .= dbFlConcat($dbdir,$dbUpgMode,$pwdir); 
	
	chdir $pwdir || die "Cannot cd to $pwdir";
	open DBCONORAFILE, ">", "ORA_" . $dbUpgFolder . ".txt" or die $!;
	if ($cnCDbfl) {
		print DBCONORAFILE $cnCDbfl;
	}
	close DBCONORAFILE;

	# Concatenate SQL DB Upgrade scripts
	$cnCDbfl = "";
	chdir $pwdir || die "Cannot cd to $pwdir";
	$dbdir = "$dbUpgFolder\\SQL\\Schema";
	$dbUpgMode = "SQL";
	$cnCDbfl .= "\n\n/* ******************** DDLs (Schema) ******************** */\n\n";
	$cnCDbfl .= dbFlConcat($dbdir,$dbUpgMode,$pwdir);
	
	chdir $pwdir || die "Cannot cd to $pwdir";
	$dbdir = "$dbUpgFolder\\SQL\\Prgm";
	$dbUpgMode = "SQL";
	$cnCDbfl .= "\n\n/* ******************** DMLs (Schema) ******************** */\n\n";
	$cnCDbfl .= dbFlConcat($dbdir,$dbUpgMode,$pwdir);
	
	chdir $pwdir || die "Cannot cd to $pwdir";
	open DBCONSQLFILE, ">", "SQL_" . $dbUpgFolder . ".txt" or die $!;
	if ($cnCDbfl) {	
		print DBCONSQLFILE $cnCDbfl;
	}
	close DBCONSQLFILE;
	# Addition over - 1/4/2009 - Dani - Concatenation


sub dbFlConcat {
	my $db_dir = shift;
	my $DBUpgMode = shift;
	
	opendir(DIR, $db_dir) || print "can't opendir $db_dir: $!";
	my @a = ();
	@a =
	  sort {(stat "$db_dir/$a")[9] <=> (stat "$db_dir/$b")[9]}
	  grep {  -f "$db_dir/$_" }
	  readdir(DIR);
	closedir DIR;

	# print join "\n", @a;
	my $dbUpgfile = "";

	my $dbFile = "";
	foreach $dbFile(@a) {
		# print $dbFile . "\n";

		# print "\n\n\n====================================\n\n";

		chdir "$pwdir\\$db_dir" || print "Cannot cd to $pwdir\\$db_dir";

		open (DBFILE, "$dbFile") || print "Can't open $dbFile: $!\n";
		my @dbfileData=<DBFILE>;

		$dbUpgfile .= "\n/* *************** $dbFile *************** */\n\n";
		foreach my $dbfldt (@dbfileData) {
			$dbUpgfile .= $dbfldt;
		}
		$dbUpgfile .= "\n/*  -------- End of $dbFile -------- */\n\n\n";

		close(DBFILE);
	}
	return $dbUpgfile;
}
