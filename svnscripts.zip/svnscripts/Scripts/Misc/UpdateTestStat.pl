#!/usr/local/bin/perl -w
#
use Win32::ODBC;

our $scmDb = new Win32::ODBC('driver={SQL Server};Server=DVARGHESE-CQ\SQLEXPRESS;database=scm;UID=sa;PWD=s@mivosr3l;') or print Win32::ODBC::Error();
our $Bld_ID = "";


# \\files\dev\ProductManagement\QualityAssurance\Automation\status.txt

my $QARptFile = '\\\\files\\dev\\ProductManagement\\QualityAssurance\\Automation\\status.txt';
open (FILE, "$QARptFile") || die "Can't open $QARptFile : $!\n";
my @flData=<FILE>;
my @TstVals = ();
foreach my $fl (@flData) {
	if (trim($fl)) {
		@TstVals = split(" ",$fl);
		print "Test Date  : $TstVals[0]\n";
		print "TestProject  : $TstVals[1]\n";
		print "Test Status  : $TstVals[2]\n";
		print "Test results link : $TstVals[3]\n";
		$Bld_ID = retBldID($TstVals[1],$scmDb);
		print "Build ID is : " . $Bld_ID . "\n";
		updateDBHfInfo($Bld_ID,$scmDb,$TstVals[0],$TstVals[2],$TstVals[3]);
	}
}





#**********************************************************************************************************************************
#  Function :  updateEvents
#  Purpose  :  Update hotfix info
#  Return   :  
#  Paramters:  $cstmr,$hfNum,$dbOb
#**********************************************************************************************************************************
sub retBldID{
	my ($bld_name,$dbObj) = @_;
	$sqlQuery = "SELECT Bld_PID FROM bld_Master WHERE Bld_Name = '$bld_name'";

	$dbObj->Sql($sqlQuery);
	$ret = $dbObj->error() if !$ret;
	my %Blddata = ();

	my $bdID = "";

	while($dbObj->FetchRow() && !$ret)
	{
		%Blddata = $dbObj->DataHash() if !$ret;
		$ret = $dbObj->error() if !$ret;
		$bdID = $Blddata{"Bld_PID"};

	}
	return $bdID;
}





#**********************************************************************************************************************************
#  Function :  trim
#  Purpose  :  This function trims the string passed and returned.
#           :  
#  Paramters:  string
#**********************************************************************************************************************************
sub trim
{
	my $string = shift;
        if ($string) {
           $string =~ s/^\s+//;
           $string =~ s/\s+$//;
        }
	return $string;
}





#**********************************************************************************************************************************
#  Function :  updateEvents
#  Purpose  :  Update hotfix info
#  Return   :  
#  Paramters:  $cstmr,$hfNum,$dbOb
#**********************************************************************************************************************************
sub updateDBHfInfo{
	my ($bldid,$dbobj,$testDt,$AutoTestStat,$autoTestLink) = @_;

	$ret = "";

	my $tstEvntID = "";

	# Define Test Status Colors
	if ($AutoTestStat =~ m/InProgress/i) {
		$tstEvntID = 8;
	}
	elsif ($AutoTestStat =~ /PASS/i) {
		$tstEvntID = 7;		
	}
	elsif ($AutoTestStat =~ m/Fail/i) {
		$tstEvntID = 9;
	}
	else {
		$tstEvntID = "";		
	}

	# Test_Events_FID	

	# AutoTestStatus
	# UPDATE
	$sqlQuery = "UPDATE Bld_Details SET AutoTestStatus = '$AutoTestStat',Test_Events_FID = $tstEvntID,AutoTestDt = '$testDt',AutoTestLink='$autoTestLink'  WHERE Bld_FID = $bldid";
	print "$sqlQuery\n";
	$dbobj->sql($sqlQuery);
	if ($dbobj->error())  {	$ret .= $dbobj->error(); }

	$dbobj->Transact($dbobj->SQL_COMMIT) if (!$ret && $dbobj->GetFunctions($dbobj->SQL_API_SQLTRANSACT)) ;
	if ($dbobj->error())  {	$ret .= $dbobj->error(); }

	return $ret;
}
# 

