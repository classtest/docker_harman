#!/usr/local/bin/perl -w
# Created By Dani Varghese
#
#
use Getopt::Std;
use warnings;
use strict;
use Time::Local;
# use Data::Dumper;
use Win32::OLE;
use Net::SMTP;
#use CQPerlExt;
use Carp qw( carp );
use Win32::ODBC;

# FetchStatus Constants identify the status of moving the cursor in a request set.
$CQPerlExt::CQ_SUCCESS = 1;  #The next record in the request set was successfully obtained.


my %opts = ();
getopts("c:f:t:vxhe",\%opts);

if ($opts{h}) {
  	PrintHelp();
  	exit 0;
}

my $pwdir = `cd`;
chomp($pwdir);

my $CQSession = "";
my $CQUID = "clearquest-svc";
my $PWD = "U#4=1**]163Yq";
my $CQDB = "VOSDF";
my $CQConnection = "AonCQEnterprise";
my $sqlQuery = "";
my $resultSet = "";
my @arrCRDets = ();
my $flg = "";
my @arrCrs = ();
my $result = "";


$CQSession = SetCQSession($CQUID,$PWD,$CQDB,$CQConnection,\$CQSession);
# my $fullname = $CQSession->GetUserFullName();
#

$sqlQuery  = "select  Company,T1.Description,T1.account_type,T1.active,T1.Phone,T1.Email,T1.Fax from Customer T1 \
		where T1.dbid <> 0 order by T1.Company";
		# and  T1.active='Y'
if ($opts{v}) {
	print "\n\n$sqlQuery\n\n";
	print "\n---------------------------------------------------------------------------------------------------------------\n";
}



$resultSet = $CQSession->BuildSQLQuery($sqlQuery);
$resultSet->Execute();



my $i = 0;
my $j = 1;
my @custInfo = ();
my $CusDet = "";
while($resultSet->MoveNext() == $CQPerlExt::CQ_SUCCESS)
{
	$CusDet = "";
	for ($j =1; $j <= 7; $j++) {
		if (!$resultSet->GetColumnValue($j)){
			$CusDet .= "-". "~";
		}
		else {
			$CusDet .=$resultSet->GetColumnValue($j). "~"; 
		}
	}
	$custInfo[$i] = $CusDet;
	$i++;
}	


my $scmDb = new Win32::ODBC('driver={SQL Server};Server=DVARGHESE-CQ\SQLEXPRESS;database=scm;UID=sa;PWD=s@mivosr3l;') or print Win32::ODBC::Error();


# Insert customer records
# @custInfo = sort(@custInfo);
# my @CompDet = ();
# foreach my $compDet (@custInfo) {
#	@CompDet = ();
#	@CompDet = split(/~/,$compDet);
#	$sqlQuery = "INSERT INTO customer  (CustName, Description, AcType, CustActive, Phone, Fax, Email) VALUES \
#		    ('$CompDet[0]', '$CompDet[1]', '$CompDet[2]', '$CompDet[3]', '$CompDet[4]', '$CompDet[5]', '$CompDet[6]')";
#
#	if ($opts{x}) { print "$sqlQuery\n";}
#	$scmDb->Sql($sqlQuery);
#	$result = $scmDb->error();
#	if (($opts{x}) && ($result)) {print $result . "\n";}
#
#	$scmDb->Transact($scmDb->SQL_COMMIT) if (!$result && $scmDb->GetFunctions($scmDb->SQL_API_SQLTRANSACT)) ;
#	$result = $scmDb->error() if !$result;
#	if (($opts{x}) && ($result)) {print $result . "\n";}
#}
#


# Update the hotfix release table:
my %HFDet = ();
my $RelFile = "C:\\Dani\\Scripts\\HFRelDet.txt";
open (RELFILE, "$RelFile") || print "Can't open $RelFile: $!\n";
my @relFlData=<RELFILE>;
my @hfhfflds = ();
my $dts = "";
foreach (@relFlData) {
	#print "$_\n";
	@hfhfflds = split(/\s+/,$_);
	$dts = "";
	foreach (@hfhfflds){
		$dts .= $_. "~"; 
	}
	push(@{$HFDet{$hfhfflds[1]}}, $dts);
}

my @indMemb = ();
my $basePrj = ();
foreach my $ht (keys %HFDet) {
	foreach my $memb (@{$HFDet{$ht}}) {
		@indMemb = split(/~/,$memb);
		($basePrj) = $indMemb[3] =~ m/\\\\[\w]*\\[\w]*\\(.*)\\.*/;

		$sqlQuery = "INSERT INTO HFRelease(HF_Name, HF_Num, HF_Date, HF_Path, HFTempCust, AonContact, BaseProj) VALUES \
				('$ht', $indMemb[0], '$indMemb[2]', '$indMemb[3]', '$indMemb[4]', '$indMemb[5]', ' $basePrj')";
		if ($opts{x}) { print "$sqlQuery\n";}
		$scmDb->Sql($sqlQuery);
		$result = $scmDb->error();
		if (($opts{x}) && ($result)) {print $result . "\n";}
		$scmDb->Transact($scmDb->SQL_COMMIT) if (!$result && $scmDb->GetFunctions($scmDb->SQL_API_SQLTRANSACT)) ;
		$result = $scmDb->error() if !$result;
		if (($opts{x}) && ($result)) {print $result . "\n";}		
	}
}
# *************** end of program ************************







# ***************************** Enable ClearQuest Session *****************************
sub SetCQSession
{
	my ($CQUser,$CQPwd,$CQDB,$CQConn,$CQSessionRef) = @_;
	$$CQSessionRef = Win32::OLE->new("CLEARQUEST.SESSION") or die "Can't create ClearQuest session object via call to Win32::OLE->new(): $!";
	eval
	{
		$$CQSessionRef->UserLogon("$CQUser", "$CQPwd","$CQDB", 2,$CQConn);
	};
	
	my $ufullname = $$CQSessionRef->GetUserFullName();
	if ($ufullname)
        {
		# print "ClearQuest Session has established\n"; 
	}
	else {	
		print "Can not establish ClearQuest Session!!!\n"; 	
	}
	return $$CQSessionRef;
}
