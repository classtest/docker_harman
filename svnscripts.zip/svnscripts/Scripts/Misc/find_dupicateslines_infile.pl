#!/usr/local/bin/perl -w


use Getopt::Std;
use warnings;
use strict;
use Time::Local;
# use Data::Dumper;
use File::Find;
use File::Basename;
use Win32::OLE;
use Carp qw( carp );

my %opts = ();
getopts("f:vxh",\%opts);

if ($opts{h}) {
  	PrintHelp();
  	exit 0;
}
if(!$opts{f})
{
   	print "ERROR:  Invalid Options\n";
   	PrintHelp();
   	exit 0;
}

my $linkFile = $opts{f};

open(TMPFILE, $linkFile) || die("Could not open file!");
my @allLinks=<TMPFILE>;
foreach (@allLinks) {
	# print $_ . "\n";
	#print $_;
}
close(TMPFILE);

my %hash   = map { $_ => 1 } @allLinks;
my @unique = keys %hash;

# print "-------------------------------------\n";
@unique = sort(@unique);

my $num = 1;
foreach (@unique) {
	# print $_ . "\n";
	print "$num. " . $_;
	$num++;
}


sub PrintHelp
{
   print <<EOF;
   
   usage: perl -w iVos_ucm_Upg.pl -f <file> [-d] [-v] [-x]

   -f : To Baseline

   -v : Verbose mode
   -x : Debug Mode
   -e : Email functionality
   -h : Help
EOF
}



