#!/usr/bin/perl -w

# ********************************************************************************
# Written by Dani
# Date : March 21 2012
#

use Net::LDAP;
use Getopt::Std;
use strict;
use warnings;
use feature qw(say);

my %opts = ();
getopts("u:hvx",\%opts) or die "ERROR : Invalid  options \n";

my ($sec,$min,$hour,$day,$month,$yr19,@rest) =   localtime(time);
my $dttm = ++$month . "-$day-".($yr19+1900) . " $hour:$min:$sec ";

if ($opts{h}) { 
	PrintHelp();
	exit;
}

if (!$opts{u}) { 
 	if ($opts{v}) { verbosePrint($dttm, "HELP option called");};
	PrintHelp();
	exit;
}
my $svnUser = $opts{u};

# Function prototyping
sub GetSidByID($$);
sub GetDNByID($$);
sub GetSidByDN($$);
sub GetTokenGroups($$);
sub IsMemberOf($$$);
sub GetRootDN($);
sub GetIDBySid($$);

use constant {
    LDAP_URL => "ldap://10.130.66.41/ou=esolutions,dc=int,dc=aonesolutions,dc=us?sAMAccountName?sub?(objectClass=*)",
    LDAP_SCHEME => "ldap",
    AuthLDAPBindDN => "CN=rcsvnbind,OU=Service_Accounts,OU=User_Control,OU=eSolutions,DC=int,DC=aonesolutions,DC=us",
    BIND_PWORD => "Ld4pgtKrb5",
    USER_DN => "sAMAccountName",
};


#  Create LDAP Connection
my $ldap = Net::LDAP->new(LDAP_URL, async => 0) or die $@;
print "Binding...\n";
my $message = $ldap->bind(AuthLDAPBindDN, password => BIND_PWORD);
if ($message->code != 0) {
   die qq(Error in LDAP Binding: ) . $message->error_desc;
}

# my $results = $ldap->search(filter => USER_DN . "=$svnUser", attrs  => "memberOf");

# Get currently logged in user
my $userDN = GetDNByID($ldap, $ENV{USERNAME});
# print "User DN: $userDN\n";
 

# Quick check if user is a member of a group
# print "User is a member of 'IT': ", IsMemberOf($ldap, $userDN, GetDNByID($ldap, 'IT')) ? 'True' : 'False', "\n";
print "User is a member of 'Svn_Dev_Users': ", IsMemberOf($ldap, $userDN, GetDNByID($ldap, 'Svn_Dev_Users')) ? 'True' : 'False', "\n";


# Enumerate all member group names
my @tkUser = GetTokenGroups($ldap, $userDN); # Get tokens of member groups
print "User is a member of ", scalar @tkUser, " groups:\n";
foreach my $tk (@tkUser) {
   print "   ", GetIDBySid($ldap, $tk), "\n";
}


## Scan token list for groups
# my $ITSid = GetSidByID($ldap, 'IT');
# my $isMemberIT = !!scalar grep { $ITSid eq $_ } @tkUser;
# print "User is a member of 'IT': ", $isMemberIT ? 'True' : 'False', "\n";

# my $FoobarSid = GetSidByID($ldap, 'Foobar');
# my $isMemberFoobar = !!scalar grep { $FoobarSid eq $_ } @tkUser;
# print "User is a member of 'Foobar': ", $isMemberFoobar ? 'True' : 'False', "\n";
 

# Done
$ldap->unbind;
exit;
 
 
# =====================================
# Token query routines
# =====================================
 
# Is DN a member of security group?
# Usage: <bool> = IsMemberOf(<DN of object>, <DN of group>)
sub IsMemberOf($$$) {
   my ($ldap, $objectDN, $groupDN) = @_;
   return if ($groupDN eq "");
 
   my $groupSid = GetSidByDN($ldap, $groupDN);
   return if ($groupSid eq "");
 
   my @matches = grep { $_ eq $groupSid } GetTokenGroups($ldap, $objectDN);
 
   @matches > 0;
}
 
# Gets tokenGroups attribute from the provided DN
# Usage: <Array of tokens> = GetTokenGroups(<LDAP ref>, <DN of object>)
sub GetTokenGroups($$) {
   my ($ldap, $objectDN) = @_;
 
   my $results = $ldap->search(
      base => $objectDN,
      scope => 'base',
      filter => '(objectCategory=*)',
      attrs => ['tokenGroups']
   );
 
   if ($results->count) {
      return $results->entry(0)->get_value('tokenGroups');
   }
}
 
 
# =====================================
# Query helper routines
# =====================================
 
# Get object's SID by DN
# Usage: <SID> = GetSidByDN(<LDAP ref>, <DN>)
sub GetSidByDN($$) {
   my ($ldap, $objectDN) = @_;
 
   my $results = $ldap->search(
      base => $objectDN,
      scope => 'base',
      filter => '(objectCategory=*)',
      attrs => ['objectSid']
   );
 
   if ($results->count) {
      return $results->entry(0)->get_value('objectSid');
   }
}
 
# Get object's SID by sAMAccountName
# Usage: <SID> = GetSidByID(<LDAP ref>, <sAMAccountName>)
sub GetSidByID($$) {
   my ($ldap, $ID) = @_;
 
   my $results = $ldap->search(
      base => GetRootDN($ldap),
      filter => "(sAMAccountName=$ID)",
      attrs => ['objectSid']
   );
 
   if ($results->count) {
      return $results->entry(0)->get_value('objectSid');
   }
}
 
# Get DN by sAMAccountName
# Usage: <DN> = GetDNByID(<LDAP ref>, <ID>)
sub GetDNByID($$) {
   my ($ldap, $ID) = @_;
 
   my $results = $ldap->search(
      base => GetRootDN($ldap),
      filter => "(sAMAccountName=$ID)",
      attrs => ['distinguishedName']
   );
 
   if ($results->count) {
      return $results->entry(0)->get_value('distinguishedName');
   }
}
 
# Get sAMAccountName by object's SID
# Usage: <ID> = GetIDBySid(<LDAP ref>, <SID>)
sub GetIDBySid($$) {
   my ($ldap, $objectSid) = @_;
 
   my $results = $ldap->search(
      base => '<SID=' . unpack('H*', $objectSid) . '>',
      scope => 'base',
      filter => '(objectCategory=*)',
      attrs => ['sAMAccountName']
   );
 
   if ($results->count) {
      return $results->entry(0)->get_value('sAMAccountName');
   }
}
 
# =====================================
# LDAP routines
# =====================================
 
# Get Root DN of logged in domain (e.g. DC=yourdomain,DC=com)
# Usage: <DN> = GetRootDN(<LDAP ref>)
sub GetRootDN($) {
   my ($ldap) = @_;
   ($ldap->root_dse->get_value('namingContexts'))[0];
}



# ** User defined functions **
# Print Help
sub PrintHelp
{
   print <<EOF;
   
   usage: $0 -u <user name>

    $0 -u scm -v -x

   -v : Verbose mode
   -x : Debug Mode
   -h : Help
EOF
}



# Print the verbose message
sub verbosePrint  {
	my $dttm = shift;
	my $Debugmsg = shift;
	print $dttm . $Debugmsg . "\n";
}


sub trim
{
        my $string = shift;
        $string =~ s/^\s+//;
        $string =~ s/\s+$//;
        return $string;
}

