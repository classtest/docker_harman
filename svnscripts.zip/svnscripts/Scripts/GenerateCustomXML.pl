#!/usr/bin/perl -w


my $filename = "custom.prop";
open(FILE, "< $filename" ) or die "Can't open $filename : $!";
my @flinfo=<FILE>;

my $str = "";
foreach my $fl (@flinfo) {
	$fl =~ s/^\s*//;
	$fl =~ s/\s*$//;
	$str .= "<customer name=\"Client\">\n\t<jsp></jsp>\n\t<reports></reports>\n\t<lib>$fl</lib>\n\t<custom_icon></custom_icon>";
	$str .= "\n\t<custom_help></custom_help>\n\t<custom_image></custom_image>\n\t<custom_reports></custom_reports>\n\t<cms>yes</cms>\n</customer>\n";
}
print $str;


