#!/usr/local/bin/perl -w

# Generate report between 2 baselines
#
# Options : 	
#		-v -> verbose mode
# 		-x -> Debug mode
# 		-f -> Recommend baseline after build
# 		-t -> Build Name
# 		-h -> Help
#		
# Steps to get through this...	  
# Accept baseline information (from and to baseline)
# Gather the activities have been delivered (diffbl) (we dont do the contributing activities for now)
# For each activity, find the change set associated with it. (name of the files)
# Login to ClearQuest and get the necessary details from ClearQuest like (DB change, State etc).
# Generate report
#	
# Copy the ivos.war file from built location
# Unzip the ivos.var
# search the file in the ivos folder
# copy the file from there and create a new directory named with the patch name and paste there
# once we have all files, using the command line zip, zip the file
# create readme
# email
# Get the WI information from CQ
# Find the dB change list
# Gather DB change list and create DB upgrade file for SQL as well as Oracle

use Getopt::Std;
use warnings;
use strict;
use Time::Local;
# use Data::Dumper;
use File::Find;
use File::Basename;

my $CmdStr ="";
my $CmdRtn = "";
my $RtnVal = "";
my $result = "";
my $Paramattrb = "";	
my $ParamattribVal = "";
my $ParamattribObj = "";
my $AttrType = "";
# how to use data::dumper explains below
# use Data::Dumper
# print Dumper($var name);


# ***************************** Full List with complete version information for each activity *****************************
my $logFile = 'ActivityFullversionInfo.txt';
open (FILE, ">$logFile") || die "Can't open $logFile: $!\n";

my $TmpFile = 'TmpFile.txt';
open (TMPFILE, ">$TmpFile") || die "Can't open $TmpFile: $!\n";


my %opts = ();
my %BldHash = ();

getopts("f:t:vxh",\%opts);

if ($opts{h}) {
  	PrintHelp();
  	exit 0;
}

if((!$opts{f}) || (!$opts{t}))
{
   	print "ERROR:  Invalid Options\n";
   	PrintHelp();
   	exit 0;
}


$CmdStr = "cleartool pwv";
if ($opts{v}) { print "Running $CmdStr \n"; }
$CmdRtn = `$CmdStr 2>&1`;
my $pwd = "";
if ($?)
{   
	$RtnVal = $CmdStr.' failed : '.$CmdRtn;
	undef($RtnVal);	
}
$CmdRtn =~ s/\n//; 
($pwd) = $CmdRtn =~ m/\:\s+(.*)Set\s+view\:(.*)/; 

#Get hostName
my $hostid = `hostname`;
chomp($hostid);
if ($hostid eq "cbuild1") {
	$pwd = "C:\\$pwd\\ucm_ivos\\";
}
else {
	$pwd = "C:\\ccstg_c\\$pwd\\ucm_ivos\\";
}

my $pwdir = `cd`;
chomp($pwdir);

my $frmBlName = $opts{f};
my $toBlName = $opts{t};

# Gather and explod the war file from built location 
# Added by Dani on 9/12/08
# find the folder with the baseline name in the build location.
# Copy to the program area in the ivos folder and explod it to ivos directory.
if ($opts{v}) { print "\n\nSearching the build directory...Please wait, as this may take some time...\n"; }
my $vos_bld_dir = "\\\\cbuild1\\Builds";
my $BldWarBl = $toBlName;
$BldWarBl =~ s/@\\ucm_pvob//;
find( sub { /^$BldWarBl$/ && print TMPFILE "$File::Find::name" }, $vos_bld_dir);
close(TMPFILE);
open(TMPFILE, $TmpFile) || die("Could not open file!");
my @upgfileInfo=<TMPFILE>;
close(TMPFILE);
$upgfileInfo[0] =~ tr/\//\\/;
if ($opts{v}) { print "Found uild directory : $upgfileInfo[0]\n"; }
$CmdStr = "DEL /F $TmpFile";
if ($opts{v}) { print "Running $CmdStr \n"; }
$CmdRtn = `$CmdStr 2>&1`;

$CmdStr = "rmdir /Q $pwdir\\ivos";
if ($opts{v}) { print "Running $CmdStr \n"; }
$CmdRtn = `$CmdStr 2>&1`;

# Copy the ivos.war file from this location and explode
$CmdStr = "xcopy $upgfileInfo[0]\\ivos.war $pwdir\\ivos\\* /Q /Y /I";
if ($opts{v}) { print "Running $CmdStr \n"; }
$CmdRtn = `$CmdStr 2>&1`;
if ($?)
{   
	$RtnVal = $CmdStr.' failed : '.$CmdRtn;
	undef($RtnVal);	
}
chdir "$pwdir\\ivos" || die "Cannot cd to $pwdir\\ivos";
$CmdStr = "jar xvf $pwdir\\ivos\\ivos.war";
if ($opts{v}) { print "Running $CmdStr \n"; }
$CmdRtn = `$CmdStr 2>&1`;
if ($?)
{
    $RtnVal = $CmdStr.' failed : '.$CmdRtn;
    undef($RtnVal);	
}
# Change directory back to the program direcotry
chdir $pwdir || die "Cannot cd to $pwdir";

$CmdStr = "cleartool diffbl -activities $frmBlName $toBlName";
if ($opts{v}) { print "Running $CmdStr \n"; }
$CmdRtn = `$CmdStr 2>&1`;
if ($opts{v}) { print "$CmdStr returned \n $CmdRtn \n"; }
if ($?)
{
    $RtnVal = $CmdStr.' failed : '.$CmdRtn;
    undef($RtnVal);	
}
else
{ 
	$BldHash{'deldActs'} = $CmdRtn;		
} # end find project

my @lnSplitActs = split(/\n/,$BldHash{'deldActs'});
my @arrBaseActs = ();
my @arrTmpAct = ();
my @activities = ();
my $acts = "";
foreach my $tmpVar (@lnSplitActs) {
	
	# print "$tmpVar\n";
	
	if ($tmpVar =~ /deliver|rebase/) {
	#	print "contains deliver/rebase\n\n";
			
	}
	else {
		@arrBaseActs = ();
		@arrTmpAct = ();
		@arrBaseActs = split(/@/,$tmpVar);		
		@arrTmpAct = split(/\s/,$arrBaseActs[0]);
		push(@activities,$arrTmpAct[1]);
	}
}


my $cnt = 1;
@arrTmpAct = ();
my @arrTmp = ();
my %actHash = ();
my $str = "";
my $cqQry = "'";
foreach $acts(@activities){
	if ($acts) {
		$cqQry .= "$acts','";
	}
	$cnt++;
	@arrTmpAct = "";	
	$acts = $acts . '@\ucm_pvob';
	$CmdStr = "cleartool lsact -fmt %[versions]p $acts";
	if ($opts{v}) { print "Running $CmdStr \n"; }
	$CmdRtn = `$CmdStr 2>&1`;
	if ($opts{v}) { print "$CmdStr returned \n $CmdRtn \n"; }
	
	if ($?)
	{
	    $RtnVal = $CmdStr.' failed : '.$CmdRtn;
	    undef($RtnVal);	
	}
	else
	{ 
		@arrTmpAct = split(/\s/,$CmdRtn);
	
		foreach (@arrTmpAct) {
			push(@{$actHash{$acts}}, $_);
		}	
	} 
}
(my $TrimCqQry) = $cqQry =~ m/(.*)\,\'$/;
print "\n\n$TrimCqQry\n\n";


my $upgFileLst = "";

my @fileLst = ();
my $fullFile = "";
foreach my $group (keys %actHash) {
    print FILE "The change set for the ClearQuest work item '$group' are, \n";
    foreach my $fullFile (@{$actHash{$group}}) {
	    print FILE "\t$fullFile\n";
           
	    # my ( $Chfile ) = $fullFile =~ m{\\([\w.\w]*)\@\@};
	    
	    # if we need the full file path name here is it.
	    $fullFile =~ s/\@\@.*//s;
	    $fullFile =~ s/^\Q$pwd\E//;
	    if ($fullFile =~ /\./) {
	        $fullFile =~ s/.java/.class/;

		$fullFile =~ s/\\src\\/\\WEB-INF\\classes\\/;
		$fullFile =~ s/\\rules\\/\\WEB-INF\\classes\\/;

	        $upgFileLst .= "$fullFile\n";
	        push(@fileLst,$fullFile);
	    }
    }
    print FILE"-------------------------------------------------------------------------------------\n\n";
}


$upgFileLst .= "ivos/system/systemInfo.jsp\n";
print FILE "Version Info File : ivos/system/systemInfo.jsp\n";
push(@fileLst,$fullFile);

my %hash   = map { $_ => 1 } @fileLst;
my @unique = keys %hash;

# A differt approach... - Dani - 9/6/08
my $destUpgFldr = "";
my $srcUpgFl = "";
my $destDir = "";
$frmBlName =~ s/\@\\.*//;  
$toBlName =~ s/\@\\.*//; 

$CmdStr = "rmdir $frmBlName " . "_" . $toBlName . "_Upg";
print "running $CmdStr\n";
$CmdRtn = `$CmdStr  2>&1`;
if ($?)
{
	print "failed on : $CmdStr"
}
foreach my $fls (@unique){
	$fls =~ tr/\//\\/;
	$srcUpgFl = $fls;
	# ($destFl) = $fls =~ m/([\w.\w]*)$/;
	# $fls =~ s/$destFl//;
	$destDir = dirname($fls);
	$destUpgFldr = $frmBlName . "_to_" . $toBlName . "_Upg\\$destDir\\";

	$CmdStr = "xcopy $srcUpgFl $destUpgFldr /Q /Y /I";
	print "running $CmdStr\n";
	$CmdRtn = `$CmdStr  2>&1`;
	if ($?)
	{
		print "xcopy failed on : $CmdStr"
	}

}

$destUpgFldr =  $frmBlName . "_to_" . $toBlName . "_Upg";

# print "**********************************************************************************************\n\n";
# $cnt = 1;
# $frmBlName =~ s/\@\\.*//;  
# $toBlName =~ s/\@\\.*//; 
# my $upgFldr = $frmBlName . "_" . $toBlName  . "_" .  "Upg";
# foreach my $fls (@unique){
#	find( sub { /^$fls$/ && print UPGFILE "xcopy $File::Find::name $upgFldr\\$File::Find::dir\\\n" }, 'ivos');
#	print  "$cnt. ". $fls . "\n";
#	$cnt++;
# }

# close(UPGFILE);
# open(UPGFILE, $upgFileInfo) || die("Could not open file!");
# my @upgfileInfo=<UPGFILE>;
# close(UPGFILE);
# print "**********************************************************************************************\n\n";
 
# foreach $CmdStr (@upgfileInfo)
# {
#	$CmdStr =~ tr/\//\\/;
#	$CmdStr .= " /Q /Y /I";
#	print "running $CmdStr\n";
#	$CmdRtn = `$CmdStr  2>&1`;
# }


$CmdStr = "wzzip -pr $destUpgFldr.zip $destUpgFldr\\ivos\\*.*";
print "running $CmdStr\n";
$CmdRtn = `$CmdStr  2>&1`;


# ***************************** User defined functions *****************************
# ***************************** Print Help *****************************
sub PrintHelp
{
   print <<EOF;
   
   usage: GenChgNote.pl -f <From baseline> -t <Two baseline>;

   -f : from Baseline
   -t : To Baseline

   -v : Verbose mode
   -x : Debug Mode
   -e : Email functionality
   -h : Help
EOF
}


