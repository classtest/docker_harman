#!/bin/sh
#This script is to cleanup docker images older than two weeks on server atld-vosapp07.int.aonesolutions.us. It has been setup in cron tab to run on weekly basis
docker images | grep in-progress-[0-9] | grep "weeks" > imagecleanup_in_progress.log
echo "Docker images qualified for deletion are:"
echo ""
cat ./imagecleanup_in_progress.log
old_images=`docker images | grep in-progress-[0-9] | grep "weeks" | awk '{print $3}'`
echo "**********Deleting image ids are*******"
echo ${old_images[@]}
docker rmi ${old_images[@]}
echo "Cleanup of images done."

