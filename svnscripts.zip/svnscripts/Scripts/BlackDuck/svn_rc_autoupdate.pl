#!/usr/local/bin/perl -w
use strict;
use Getopt::Std;
my %opts = ();
use Time::Local;
use Switch;


# RCSVNAutoUpdate
# perl script to pull latest RC branch source from SVN and place to /home/blackduck/RiskConsole/latest
# Written by  : Dani Varghese
# Date : 09.18.2015

# RC SVN Branches
# AdvancedQuery
# DataExchange
# EmailJournal
# LetterServer
# RiskConsole
# RuleServer
# SpreadsheetAdd
# StiffServer
# TimeBasedEvents
# Modules/Administration
# Modules/DataWarehouseRefresh
# Modules/Download2XL
# Cogons/Cap  - http://svn.int.aonesolutions.us/rc/java/cognos
# ConfigRC - http://svn.int.aonesolutions.us/common/java
#
# http://svn.int.aonesolutions.us/rc/java/cognos/cap/branches
# http://svn.int.aonesolutions.us/common/java

# Todo in linux : 
# Change SVN executable path
# $rccomp . "\\" . $svn_checkout_folder to $rccomp . "/" . $svn_checkout_folder

getopts("r:cuvxh",\%opts);

if ($opts{h}) {
  	PrintHelp();
  	exit 0;
}

# Path to the checkout directory
$opts{p} = 'C:\DBDMLGEN\test';


my $fl_lstchkt = 'C:\DBDMLGEN\dont_delete\rc_last_checkedout_version.do_not_delete';
my $fl_curchkt = 'C:\DBDMLGEN\dont_delete\rc_current_checkout_versions.do_not_delete';

if ($opts{c}) {
	if (!$opts{r}) {
   		print "ERROR:  Invalid Options. Please provide the SVN release branch\n";
	   	PrintHelp();
   		exit 0;
	}
}

if ((!$opts{c}) && (!$opts{u})) {
	print "\nInvalid options..Please provide -c (svn checkout) or -u (svn update) options <>\n\n";
	printHelp();
	exit;
}


my $pwdir = $opts{p};
my $CmdRtn = "";
my $RtnVal = "";
my $CtRet = "";
my $CmdStr = "";
my $svn_url = "";
my $svn_checkout_folder = "latest";

# global vars
my $AdvancedQuery = "";
my $DataExchange = "";
my $EmailJournal = "";
my $LetterServer = "";
my $RiskConsole = "";
my $RuleServer = "";
my $SpreadsheetAdd = "";
my $StiffServer = "";
my $TimeBasedEvents = "";
my $ModulesAdministration = "";
my $ModulesDataWarehouseRefresh = "";
my $ModulesDownload2XL = "";
my $CogonsCap="";
my $ConfigRC="";
my $verifysvnurl = "";


my @rc_comps = qw (
			AdvancedQuery
			Modules/Download2XL
			DataExchange
			EmailJournal
			LetterServer
			RiskConsole
			RuleServer
			SpreadsheetAdd
			StiffServer
			TimeBasedEvents
			Modules/Administration
			Modules/DataWarehouseRefresh		
		);

my $svnbin = ""; # THIS NEEDS TO BE UPDATED WITH THE /opt/...

# Debug
# @rc_comps = ();
# @rc_comps = qw (
#		AdvancedQuery
#		);


my $base_rc_svnurl = 'http://svn.int.aonesolutions.us/rc/java/';
my $rcurl = "";
my $CORtn = "";

# Read last checkout version file
# If last checkout version is greater than current checkout version, donot checkout and exit
# of if the last checkout version is equal to current request - print message and exit
# else check if the checkout folder is empty; if not empty, delete the folder and do the checkout


open (FL_READLSTCHKT, $fl_lstchkt) || print "Can't open $fl_lstchkt: $!\n";
my @flData=<FL_READLSTCHKT>;
close (FL_READLSTCHKT);

if ($flData[0]) {
	$flData[0] =~ s/\D//g;
	if ($opts{v})  { print "The last checkout version is : ". $flData[0] . "\n. If doing svn update, you will be updating branch - $flData[0]\n"; }
}
else { $flData[0] = 0; }

my $optdr = "";
if ($opts{r}) {
	$optdr = $opts{r};
	$optdr =~ s/\D//g;
	if (($opts{v}) && ($opts{c})) { print "The input checkout parameter is : ". $optdr. "\n"; }
}

if ($opts{c}) {
	if ($flData[0] gt $optdr)  {
		print "The current working directory is on R$flData[0]. You cannot downgrade the working copy $opts{r}";
		exit;
	}	
	elsif ($flData[0] eq $optdr)  {
		print "The current working directory is on R$flData[0]. You may update your working copy";
		exit;
	}
	else {
		foreach my $rccomp (@rc_comps) {
			$rcurl = "$base_rc_svnurl" . "$rccomp" . "/branches/$opts{r}";
			chdir $pwdir || die "Cannot cd to $pwdir";

			if ($rccomp =~ m/\//) {
				my @cmpfldr = split("/",$rccomp);
				DoMkDIR ($cmpfldr[0]);
				DoMkDIR ($cmpfldr[0] . "\\" . $cmpfldr[1] . "\\" . $svn_checkout_folder);
				if (!is_folder_empty($pwdir . "\\" . $cmpfldr[0] . "\\" . $cmpfldr[1] . "\\" . $svn_checkout_folder)) {
					if (VerifySVNurl($rcurl)) {
						rmDIR ($pwdir . "\\" . $cmpfldr[0] . "\\" . $cmpfldr[1] . "\\" . $svn_checkout_folder);
						DoMkDIR ($cmpfldr[0] . "\\" . $cmpfldr[1]);
						DoMkDIR ($cmpfldr[0] . "\\" . $cmpfldr[1] . "\\" . $svn_checkout_folder);
					}
				}
				$CORtn = DoCheckout($pwdir,$rcurl,$cmpfldr[0] . "\\" . $cmpfldr[1]); # SVN Checkout
				if ($opts{v}) { print "Checkout returned : " . $CORtn . "\n"; }

				DoUpdateRCModVars($cmpfldr[1],$CORtn);

			}
			else {	
				DoMkDIR ($rccomp);
				DoMkDIR ($rccomp . "\\" . $svn_checkout_folder);
				if (!is_folder_empty($pwdir . "\\" . $rccomp . "\\" . $svn_checkout_folder)) {
					if (VerifySVNurl($rcurl)) {
						rmDIR ($pwdir . "\\" . $rccomp . "\\" . $svn_checkout_folder);
						DoMkDIR ($rccomp . "\\" . $svn_checkout_folder);
					}
				}
				$CORtn = DoCheckout($pwdir,$rcurl,$rccomp); # SVN Checkout
				if ($opts{v}) { print "Checkout returned : " . $CORtn . "\n"; }

				DoUpdateRCModVars($rccomp,$CORtn);
			}
		}

		chdir $pwdir || die "Cannot cd to $pwdir";
		$rcurl = "$base_rc_svnurl" . "cognos/cap/branches/$opts{r}";
		DoMkDIR ("cognos");
		DoMkDIR ("cognos" . "\\" . $svn_checkout_folder);
		if (!is_folder_empty($pwdir . "\\" . "cognos" . "\\" . $svn_checkout_folder)) {
			if (VerifySVNurl($rcurl)) {
				rmDIR ("cognos" . "\\" . $svn_checkout_folder);
				DoMkDIR ("cognos" . "\\" . $svn_checkout_folder);
			}
		}
		$CORtn = DoCheckout($pwdir,$rcurl,"cognos",\$AdvancedQuery); # SVN Checkout
		if ($opts{v}) { print "Checkout returned : " . $CORtn . "\n"; }
		DoUpdateRCModVars("cognos",$CORtn);

		chdir $pwdir || die "Cannot cd to $pwdir";
		$rcurl = "http://svn.int.aonesolutions.us/common/java";
		DoMkDIR ("common");
		DoMkDIR ("common" . "\\" . $svn_checkout_folder);
		if (!is_folder_empty($pwdir . "\\" . "common" . "\\" . $svn_checkout_folder)) {
			if (VerifySVNurl($rcurl)) {
				rmDIR ("common" . "\\" . $svn_checkout_folder);
				DoMkDIR ("common" . "\\" . $svn_checkout_folder);
			}
		}
	
		$CORtn = DoCheckout($pwdir,$rcurl,"common"); # SVN Checkout
		if ($opts{v}) { print "Checkout returned : " . $CORtn . "\n"; }
		DoUpdateRCModVars("common",$CORtn);
	}
}	


if ($opts{u}) {
	foreach my $rccomp (@rc_comps) {
		if ($rccomp =~ m/\//) {
			my @cmpfldr = split("/",$rccomp);
			DoUpdate($pwdir . "\\" . $cmpfldr[0] . "\\" . $cmpfldr[1] . "\\" . $svn_checkout_folder); # SVN update
		}
		else {	
			DoUpdate($pwdir . "\\" . $rccomp . "\\" . $svn_checkout_folder); # SVN udpate
		}
	}
	DoUpdate($pwdir . "\\cognos"); # SVN update
	DoUpdate($pwdir . "\\common"); # SVN update
}

open(FL_LSTCHKT, "> $fl_lstchkt" ) or die "Can't open $fl_lstchkt : $!";
open(FL_CURCHKT, ">> $fl_curchkt" ) or die "Can't open $fl_curchkt : $!";

my $timestamp = MkTimeStamp();

if ($opts{c}) {

print FL_LSTCHKT "$opts{r}";

print FL_CURCHKT "		
******* CHECKOUT LOG FOR $opts{r} branch - $timestamp *******
AdvancedQuery ------------------$AdvancedQuery
DataExchange -------------------$DataExchange
EmailJournal -------------------$EmailJournal
LetterServer -------------------$LetterServer
RiskConsole --------------------$RiskConsole
RuleServer ---------------------$RuleServer
SpreadsheetAdd -----------------$SpreadsheetAdd
StiffServer --------------------$StiffServer
TimeBasedEvents ----------------$TimeBasedEvents
Modules/Administration ---------$ModulesAdministration
Modules/DataWarehouseRefresh ---$ModulesDataWarehouseRefresh
Modules/Download2XL ------------$ModulesDownload2XL
Cogons/Cap ---------------------$CogonsCap
ConfigRC -----------------------$ConfigRC


";

print "\nSVN checkout has been completed...\n";

}
elsif ($opts{u}) {
	print FL_CURCHKT "
******* UPDATE LOG - $timestamp *******
Working directory update completed.

";

print "\nSVN update has been completed...\n";

}



close(FL_LSTCHKT);
close(FL_CURCHKT);

# ***************************** User defined functions *****************
sub DoMkDIR {
	my $dir = shift;
	$CmdStr = "mkdir $dir";
	if ($opts{v}) { print "\nrunning $CmdStr\n"; }
	$CtRet = `$CmdStr  2>&1`;
	if ($?) {
	  if ($opts{v}) { print "\n$CmdStr returned \n $CmdRtn \n"; }
	}
}

sub DoUpdateRCModVars {
	my $comp = shift;
	my $var = shift;
	switch ($comp) {
		case "AdvancedQuery" { $AdvancedQuery = "$var";  }
		case "DataExchange" { $DataExchange = "$var"; }
		case "EmailJournal" { $EmailJournal = "$var"; }
		case "LetterServer" { $LetterServer = "$var"; }
		case "RiskConsole" { $RiskConsole = "$var"; }
		case "RuleServer" { $RuleServer = "$var"; }
		case "SpreadsheetAdd" { $SpreadsheetAdd = "$var"; }
		case "StiffServer" { $StiffServer = "$var"; }
		case "TimeBasedEvents" { $TimeBasedEvents = "$var"; }
		case "Administration" { $ModulesAdministration = "$var"; }
		case "DataWarehouseRefresh" { $ModulesDataWarehouseRefresh = "$var"; }
		case "Download2XL" { $ModulesDownload2XL = "$var"; }
		case "cognos" { $CogonsCap = "$var"; }
		case "common" { $ConfigRC = "$var"; }
	}
}


# ***************************** User defined functions *****************
sub rmDIR {
	my $dir = shift;

	if ($^O eq "MSWin32") {
		$CmdStr = "rmdir $dir /s /q";
	}
	else {
		$CmdStr = "rm -rf  $dir";
	}
	if ($opts{v}) { print "\nrunning $CmdStr\n"; }
	$CtRet = `$CmdStr  2>&1`;
	if ($?) {
	  if ($opts{v}) { print "\n$CmdStr returned \n $CmdRtn \n"; }
	}
}


# ***************************** Check to see if the folder is empty or not *****************
sub is_folder_empty {
    my $dirname = shift;
    if ($opts{v}) {  print "Check folder empty : $dirname"; }
    opendir(my $dh, $dirname) or die "Not a directory";
    return scalar(grep { $_ ne "." && $_ ne ".." } readdir($dh)) == 0;
}



# ***************************** Print Help *****************************
sub PrintHelp
{
   print <<EOF;

   usage: $0 -r <release> -c|-u -v

   example : $0 -r R167 -u -v

   -r : release name
   -c : SVN checkout
   -u : SVN update

   -v : Verbose mode
   -x : Debug Mode
   -h : Help
EOF
}


# ***************************** Make time stamp Function *****************************
sub MkTimeStamp
{
  my $sec;
  my $min;
  my $hr;
  my $day;
  my $mon;
  my $yr; 
  my $timestamp;


  ($sec, $min, $hr, $day, $mon, $yr) = (localtime)[0,1,2,3,4,5];
  my $Epoch = timelocal($sec, $min, $hr, $day, $mon, $yr);
  $timestamp = sprintf("%04d-%02d-%02d %02d:%02d:%02d", $yr+1900, 
                        $mon+1, $day, $hr, $min, $sec);
  return $timestamp;
}



# ***************************** Add to log *****************************
sub AddtoLog
{
#   my $logMsg = shift;
#   my $dttm = MkTimeStamp();
#   print FILE "$dttm : $logMsg\n";
}

# ***************************** Add to log *****************************
sub VerifySVNurl{
	my $url = shift;

	if ($opts{v}) { print "\nVerify SVN url\n"; }

	$CmdStr = "$svnbin svn ls $url";
	
	if ($opts{v}) { print "\nrunning $CmdStr\n"; }
	$CtRet = `$CmdStr  2>&1`;
	if ($?) {
	   if ($opts{v}) { print "\n$CmdStr returned \n $CmdRtn \n"; }
	   $RtnVal = "";
	}
	else {
	   $RtnVal = "SVN url exists - $url";
	   chomp($RtnVal);
	}
	return $RtnVal;
}


# ***************************** checkout stream *****************************
sub DoCheckout
{

	my $curDir = shift;
	my $path = shift;
	my $chkdir =shift;

	my $chkoutdir = "$curDir\\$chkdir";

	chdir $chkoutdir || die "Cannot cd to $chkoutdir";
	
	if ($opts{v}) { print "\nCheckout directory is : $chkoutdir\n"; }

	$CmdStr = "$svnbin svn checkout $path $svn_checkout_folder";
	
	if ($opts{v}) { print "\nrunning $CmdStr\n"; }
	$CtRet = `$CmdStr  2>&1`;

	if ($?) {
	   if ($opts{v}) { print "\n$CmdStr returned \n $CmdRtn \n"; }
	   $RtnVal = "No $opts{r} branch";
	}
	else {
	   $RtnVal = "updated source - $path";
	   chomp($RtnVal);
	}
	return $RtnVal;
}

# ***************************** SVN update *****************************
sub DoUpdate
{

	my $svn_working_dir = shift;

	chdir $svn_working_dir || die "Cannot cd to $svn_working_dir";

	print "\n\nUpdating working directory - $svn_working_dir";

	$CmdStr = "svn cleanup";
	if ($opts{v}) { print "running $CmdStr\n"; }
	$CtRet = `$CmdStr  2>&1`;

	$CmdStr = "svn update";
	if ($opts{v}) { print "running $CmdStr\n"; }
	$CtRet = `$CmdStr  2>&1`;
	if ($?) {
	   if ($opts{v}) { print "$CmdStr returned \n $CmdRtn \n"; }
	   $RtnVal = -1;
	}
	else {
	   $RtnVal = $CtRet;
	   chomp($RtnVal);
	}
}




