#!/bin/sh

# ##########################################################################
# Harman Connected Services Artifactory Cleanup Script
#
# Copyright (C) 2018 Harman Connected Services, Inc. All Rights Reserved.
#
# This software is confidential and proprietary information of
# Harman Connected Services, Inc. ("Confidential Information"). 
# 
# For more information, visit https://services.harman.com
#
# Version	: 1.0
# Last updated	: March 27, 2018
# Authors	: Subhash (sdelhi) & Bhagyaraj (bdesuri)
# Purpose	: Artifactory Cleanup
#
# ###########################################################################

artifactoryUrl="https://artifactory.corp.ventivtech.com/artifactory"
artifactoryStorUrl="https://artifactory.corp.ventivtech.com/artifactory/api/storage"
repoPath="RiskConsole"
outputFile="rc.out.log"
repoListFile="rc.repo.log"
subDirLog="subdir.out.log"

# ******************************************************
# Main function
# ******************************************************

function RCcleanup() {

curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > ${outputFile}
chmod a+x ${outputFile}

while IFS= read -r repodir; do

   case $repodir in

### (1)
     RC-Administration)
        echo "Performing ${repodir} ***"
        echo "============================"
        touch "$repodir.log"
        curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > $repodir.log

        while IFS= read -r reposubdir; do

                echo "Directory Path: ${repodir}/${reposubdir}"
                curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > ${subDirLog}

                buildCount=`cat ${subDirLog} | wc -l`
                echo "count is : ${buildCount}"

        if [ ${buildCount} -eq "5" ]; then
                echo "Count is Equal to 5."
                echo ""

        elif [ ${buildCount} -ge "5" ]; then
                echo "Count is Greater than or equal to 5."

                buildsNum=`curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | cut -d "b" -f2 | sort -n | head -n -5`

                echo "Build numbers to delete : b${buildsNum}"
                echo "${buildsNum}" > delete.builds.log
                sed 's/^/b/' delete.builds.log > rem.builds.log
                rm -rf delete.builds.log
                echo ""

                while read -r arcBuild; do
                        echo "Deleting build is : ${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                        echo ""
                        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                done < rem.builds.log
        else
                echo "Count is Less than 5."
                echo ""
        fi

        done < $repodir.log
        ;;

### (2)
        RC-AdvancedQuery)
        echo "Performing ${repodir} ***"
        echo "============================"
        touch "$repodir.log"
        curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > $repodir.log

        while IFS= read -r reposubdir; do

                echo "Directory Path: ${repodir}/${reposubdir}"
                curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > ${subDirLog}

                buildCount=`cat ${subDirLog} | wc -l`
                echo "count is : ${buildCount}"

        if [ ${buildCount} -eq "5" ]; then
                echo "Count is Equal to 5."
                echo ""

        elif [ ${buildCount} -ge "5" ]; then
                echo "Count is Greater than or equal to 5."

                buildsNum=`curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | cut -d "b" -f2 | sort -n | head -n -5`

                echo "Build numbers to delete : b${buildsNum}"
                echo "${buildsNum}" > delete.builds.log
                sed 's/^/b/' delete.builds.log > rem.builds.log
                rm -rf delete.builds.log
                echo ""

                while read -r arcBuild; do
                        echo "Deleting build is : ${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                        echo ""
                        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                done < rem.builds.log
        else
                echo "Count is Less than 5."
                echo ""
        fi

        done < $repodir.log
        ;;

### (3)
        RC-CognosCAP)
        echo "Performing ${repodir} ***"
        echo "============================"
        touch "$repodir.log"
        curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > $repodir.log

        while IFS= read -r reposubdir; do

                echo "Directory Path: ${repodir}/${reposubdir}"
                curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > ${subDirLog}

                buildCount=`cat ${subDirLog} | wc -l`
                echo "count is : ${buildCount}"

        if [ ${buildCount} -eq "5" ]; then
                echo "Count is Equal to 5."
                echo ""

        elif [ ${buildCount} -ge "5" ]; then
                echo "Count is Greater than or equal to 5."

                buildsNum=`curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | cut -d "b" -f2 | sort -n | head -n -5`

                echo "Build numbers to delete : b${buildsNum}"
                echo "${buildsNum}" > delete.builds.log
                sed 's/^/b/' delete.builds.log > rem.builds.log
                rm -rf delete.builds.log
                echo ""

                while read -r arcBuild; do
                        echo "Deleting build is : ${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                        echo ""
                        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                done < rem.builds.log
        else
                echo "Count is Less than 5."
                echo ""
        fi

        done < $repodir.log
        ;;

### (4)
        RC-DataExchange)
        echo "Performing ${repodir} ***"
        echo "============================"
        touch "$repodir.log"
        curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > $repodir.log

        while IFS= read -r reposubdir; do

                echo "Directory Path: ${repodir}/${reposubdir}"
                curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > ${subDirLog}

                buildCount=`cat ${subDirLog} | wc -l`
                echo "count is : ${buildCount}"

        if [ ${buildCount} -eq "5" ]; then
                echo "Count is Equal to 5."
                echo ""

        elif [ ${buildCount} -ge "5" ]; then
                echo "Count is Greater than or equal to 5."

                buildsNum=`curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | cut -d "b" -f2 | sort -n | head -n -5`

                echo "Build numbers to delete : b${buildsNum}"
                echo "${buildsNum}" > delete.builds.log
                sed 's/^/b/' delete.builds.log > rem.builds.log
                rm -rf delete.builds.log
                echo ""

                while read -r arcBuild; do
                        echo "Deleting build is : ${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                        echo ""
                        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                done < rem.builds.log
        else
                echo "Count is Less than 5."
                echo ""
        fi

        done < $repodir.log
        ;;

### (5)
        RC-DataWarehouseRefresh)
        echo "Performing ${repodir} ***"
        echo "============================"
        touch "$repodir.log"
        curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > $repodir.log

        while IFS= read -r reposubdir; do

                echo "Directory Path: ${repodir}/${reposubdir}"
                curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > ${subDirLog}

                buildCount=`cat ${subDirLog} | wc -l`
                echo "count is : ${buildCount}"

        if [ ${buildCount} -eq "5" ]; then
                echo "Count is Equal to 5."
                echo ""

        elif [ ${buildCount} -ge "5" ]; then
                echo "Count is Greater than or equal to 5."

                buildsNum=`curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | cut -d "b" -f2 | sort -n | head -n -5`

                echo "Build numbers to delete : b${buildsNum}"
                echo "${buildsNum}" > delete.builds.log
                sed 's/^/b/' delete.builds.log > rem.builds.log
                rm -rf delete.builds.log
                echo ""

                while read -r arcBuild; do
                        echo "Deleting build is : ${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                        echo ""
                        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                done < rem.builds.log
        else
                echo "Count is Less than 5."
                echo ""
        fi

        done < $repodir.log
        ;;

### (6)
        RC-Download2XL)
        echo "Performing ${repodir} ***"
        echo "============================"
        touch "$repodir.log"
        curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > $repodir.log

        while IFS= read -r reposubdir; do

                echo "Directory Path: ${repodir}/${reposubdir}"
                curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > ${subDirLog}

                buildCount=`cat ${subDirLog} | wc -l`
                echo "count is : ${buildCount}"

        if [ ${buildCount} -eq "5" ]; then
                echo "Count is Equal to 5."
                echo ""

        elif [ ${buildCount} -ge "5" ]; then
                echo "Count is Greater than or equal to 5."

                buildsNum=`curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | cut -d "b" -f2 | sort -n | head -n -5`

                echo "Build numbers to delete : b${buildsNum}"
                echo "${buildsNum}" > delete.builds.log
                sed 's/^/b/' delete.builds.log > rem.builds.log
                rm -rf delete.builds.log
                echo ""

                while read -r arcBuild; do
                        echo "Deleting build is : ${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                        echo ""
                        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                done < rem.builds.log
        else
                echo "Count is Less than 5."
                echo ""
        fi

        done < $repodir.log
        ;;

### (7)
        RC-EmailJournal)
        echo "Performing ${repodir} ***"
        echo "============================"
        touch "$repodir.log"
        curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > $repodir.log

        while IFS= read -r reposubdir; do

                echo "Directory Path: ${repodir}/${reposubdir}"
                curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > ${subDirLog}

                buildCount=`cat ${subDirLog} | wc -l`
                echo "count is : ${buildCount}"

        if [ ${buildCount} -eq "5" ]; then
                echo "Count is Equal to 5."
                echo ""

        elif [ ${buildCount} -ge "5" ]; then
                echo "Count is Greater than or equal to 5."

                buildsNum=`curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | cut -d "b" -f2 | sort -n | head -n -5`

                echo "Build numbers to delete : b${buildsNum}"
                echo "${buildsNum}" > delete.builds.log
                sed 's/^/b/' delete.builds.log > rem.builds.log
                rm -rf delete.builds.log
                echo ""

                while read -r arcBuild; do
                        echo "Deleting build is : ${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                        echo ""
                        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                done < rem.builds.log
        else
                echo "Count is Less than 5."
                echo ""
        fi

        done < $repodir.log
        ;;

### (8)
        RC-JAVA)
        echo "Performing ${repodir} ***"
        echo "============================"
        touch "$repodir.log"
        curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > $repodir.log

        while IFS= read -r reposubdir; do

                echo "Directory Path: ${repodir}/${reposubdir}"
                curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > ${subDirLog}

                buildCount=`cat ${subDirLog} | wc -l`
                echo "count is : ${buildCount}"

        if [ ${buildCount} -eq "5" ]; then
                echo "Count is Equal to 5."
                echo ""

        elif [ ${buildCount} -ge "5" ]; then
                echo "Count is Greater than or equal to 5."

                buildsNum=`curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | cut -d "b" -f2 | sort -n | head -n -5`

                echo "Build numbers to delete : b${buildsNum}"
                echo "${buildsNum}" > delete.builds.log
                sed 's/^/b/' delete.builds.log > rem.builds.log
                rm -rf delete.builds.log
                echo ""

                while read -r arcBuild; do
                        echo "Deleting build is : ${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                        echo ""
                        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                done < rem.builds.log
        else
                echo "Count is Less than 5."
                echo ""
        fi

        done < $repodir.log
        ;;

### (9)
        RC-Letterserver)
        echo "Performing ${repodir} ***"
        echo "============================"
        touch "$repodir.log"
        curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > $repodir.log

        while IFS= read -r reposubdir; do

                echo "Directory Path: ${repodir}/${reposubdir}"
                curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > ${subDirLog}

                buildCount=`cat ${subDirLog} | wc -l`
                echo "count is : ${buildCount}"

        if [ ${buildCount} -eq "5" ]; then
                echo "Count is Equal to 5."
                echo ""

        elif [ ${buildCount} -ge "5" ]; then
                echo "Count is Greater than or equal to 5."

                buildsNum=`curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | cut -d "b" -f2 | sort -n | head -n -5`

                echo "Build numbers to delete : b${buildsNum}"
                echo "${buildsNum}" > delete.builds.log
                sed 's/^/b/' delete.builds.log > rem.builds.log
                rm -rf delete.builds.log
                echo ""

                while read -r arcBuild; do
                        echo "Deleting build is : ${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                        echo ""
                        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                done < rem.builds.log
        else
                echo "Count is Less than 5."
                echo ""
        fi

        done < $repodir.log
        ;;

### (10)
        RC-OktaInteract)
        echo "Performing ${repodir} ***"
        echo "============================"
        touch "$repodir.log"
        curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > $repodir.log

        while IFS= read -r reposubdir; do

                echo "Directory Path: ${repodir}/${reposubdir}"
                curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > ${subDirLog}

                buildCount=`cat ${subDirLog} | wc -l`
                echo "count is : ${buildCount}"

        if [ ${buildCount} -eq "5" ]; then
                echo "Count is Equal to 5."
                echo ""

        elif [ ${buildCount} -ge "5" ]; then
                echo "Count is Greater than or equal to 5."

                buildsNum=`curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | cut -d "b" -f2 | sort -n | head -n -5`

                echo "Build numbers to delete : b${buildsNum}"
                echo "${buildsNum}" > delete.builds.log
                sed 's/^/b/' delete.builds.log > rem.builds.log
                rm -rf delete.builds.log
                echo ""

                while read -r arcBuild; do
                        echo "Deleting build is : ${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                        echo ""
                        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                done < rem.builds.log
        else
                echo "Count is Less than 5."
                echo ""
        fi

        done < $repodir.log
        ;;

### (11)
        RC-Ruleserver)
        echo "Performing ${repodir} ***"
        echo "============================"
        touch "$repodir.log"
        curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > $repodir.log

        while IFS= read -r reposubdir; do

                echo "Directory Path: ${repodir}/${reposubdir}"
                curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > ${subDirLog}

                buildCount=`cat ${subDirLog} | wc -l`
                echo "count is : ${buildCount}"

        if [ ${buildCount} -eq "5" ]; then
                echo "Count is Equal to 5."
                echo ""

        elif [ ${buildCount} -ge "5" ]; then
                echo "Count is Greater than or equal to 5."

                buildsNum=`curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | cut -d "b" -f2 | sort -n | head -n -5`

                echo "Build numbers to delete : b${buildsNum}"
                echo "${buildsNum}" > delete.builds.log
                sed 's/^/b/' delete.builds.log > rem.builds.log
                rm -rf delete.builds.log
                echo ""

                while read -r arcBuild; do
                        echo "Deleting build is : ${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                        echo ""
                        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                done < rem.builds.log
        else
                echo "Count is Less than 5."
                echo ""
        fi

        done < $repodir.log
        ;;

### (12)
        RC-SpreadsheetAdd)
        echo "Performing ${repodir} ***"
        echo "============================"
        touch "$repodir.log"
        curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > $repodir.log

        while IFS= read -r reposubdir; do

                echo "Directory Path: ${repodir}/${reposubdir}"
                curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > ${subDirLog}

                buildCount=`cat ${subDirLog} | wc -l`
                echo "count is : ${buildCount}"

        if [ ${buildCount} -eq "5" ]; then
                echo "Count is Equal to 5."
                echo ""

        elif [ ${buildCount} -ge "5" ]; then
                echo "Count is Greater than or equal to 5."

                buildsNum=`curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | cut -d "b" -f2 | sort -n | head -n -5`

                echo "Build numbers to delete : b${buildsNum}"
                echo "${buildsNum}" > delete.builds.log
                sed 's/^/b/' delete.builds.log > rem.builds.log
                rm -rf delete.builds.log
                echo ""

                while read -r arcBuild; do
                        echo "Deleting build is : ${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                        echo ""
                        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                done < rem.builds.log
        else
                echo "Count is Less than 5."
                echo ""
        fi

        done < $repodir.log
        ;;

### (13)
        RC-Stiffserver)
        echo "Performing ${repodir} ***"
        echo "============================"
        touch "$repodir.log"
        curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > $repodir.log

        while IFS= read -r reposubdir; do

                echo "Directory Path: ${repodir}/${reposubdir}"
                curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > ${subDirLog}

                buildCount=`cat ${subDirLog} | wc -l`
                echo "count is : ${buildCount}"

        if [ ${buildCount} -eq "5" ]; then
                echo "Count is Equal to 5."
                echo ""

        elif [ ${buildCount} -ge "5" ]; then
                echo "Count is Greater than or equal to 5."

                buildsNum=`curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | cut -d "b" -f2 | sort -n | head -n -5`

                echo "Build numbers to delete : b${buildsNum}"
                echo "${buildsNum}" > delete.builds.log
                sed 's/^/b/' delete.builds.log > rem.builds.log
                rm -rf delete.builds.log
                echo ""

                while read -r arcBuild; do
                        echo "Deleting build is : ${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                        echo ""
                        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                done < rem.builds.log
        else
                echo "Count is Less than 5."
                echo ""
        fi

        done < $repodir.log
        ;;

### (14)
        RC_JBOSS_Configuration_4.0.5)
        echo "Performing ${repodir} ***"
        echo "============================"
        touch "$repodir.log"
        curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > $repodir.log

        while IFS= read -r reposubdir; do

                echo "Directory Path: ${repodir}/${reposubdir}"
                curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > ${subDirLog}

                buildCount=`cat ${subDirLog} | wc -l`
                echo "count is : ${buildCount}"

        if [ ${buildCount} -eq "5" ]; then
                echo "Count is Equal to 5."
                echo ""

        elif [ ${buildCount} -ge "5" ]; then
                echo "Count is Greater than or equal to 5."

                buildsNum=`curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | cut -d "b" -f2 | sort -n | head -n -5`

                echo "Build numbers to delete : b${buildsNum}"
                echo "${buildsNum}" > delete.builds.log
                sed 's/^/b/' delete.builds.log > rem.builds.log
                rm -rf delete.builds.log
                echo ""

                while read -r arcBuild; do
                        echo "Deleting build is : ${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                        echo ""
                        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                done < rem.builds.log
        else
                echo "Count is Less than 5."
                echo ""
        fi

        done < $repodir.log
        ;;

### (15)
        RC_OktaInteract_develop)
        echo "Performing ${repodir} ***"
        echo "============================"
        touch "$repodir.log"
        curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > $repodir.log

        while IFS= read -r reposubdir; do

                echo "Directory Path: ${repodir}/${reposubdir}"
                curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > ${subDirLog}

                buildCount=`cat ${subDirLog} | wc -l`
                echo "count is : ${buildCount}"

        if [ ${buildCount} -eq "5" ]; then
                echo "Count is Equal to 5."
                echo ""

        elif [ ${buildCount} -ge "5" ]; then
                echo "Count is Greater than or equal to 5."

                buildsNum=`curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | cut -d "b" -f2 | sort -n | head -n -5`

                echo "Build numbers to delete : b${buildsNum}"
                echo "${buildsNum}" > delete.builds.log
                sed 's/^/b/' delete.builds.log > rem.builds.log
                rm -rf delete.builds.log
                echo ""

                while read -r arcBuild; do
                        echo "Deleting build is : ${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                        echo ""
                        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                done < rem.builds.log
        else
                echo "Count is Less than 5."
                echo ""
        fi

        done < $repodir.log
        ;;

### (16)
        RC_Stiffserver_R169.3)
        echo "Performing ${repodir} ***"
        echo "============================"
        touch "$repodir.log"
        curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > $repodir.log

        while IFS= read -r reposubdir; do

                echo "Directory Path: ${repodir}/${reposubdir}"
                curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > ${subDirLog}

                buildCount=`cat ${subDirLog} | wc -l`
                echo "count is : ${buildCount}"

        if [ ${buildCount} -eq "5" ]; then
                echo "Count is Equal to 5."
                echo ""

        elif [ ${buildCount} -ge "5" ]; then
                echo "Count is Greater than or equal to 5."

                buildsNum=`curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | cut -d "b" -f2 | sort -n | head -n -5`

                echo "Build numbers to delete : b${buildsNum}"
                echo "${buildsNum}" > delete.builds.log
                sed 's/^/b/' delete.builds.log > rem.builds.log
                rm -rf delete.builds.log
                echo ""

                while read -r arcBuild; do
                        echo "Deleting build is : ${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                        echo ""
                        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                done < rem.builds.log
        else
                echo "Count is Less than 5."
                echo ""
        fi

        done < $repodir.log
        ;;

### (17)
        RC_Stiffserver_branches)
        echo "Performing ${repodir} ***"
        echo "============================"
        touch "$repodir.log"
        curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > $repodir.log

        while IFS= read -r reposubdir; do

                echo "Directory Path: ${repodir}/${reposubdir}"
                curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > ${subDirLog}

                buildCount=`cat ${subDirLog} | wc -l`
                echo "count is : ${buildCount}"

        if [ ${buildCount} -eq "5" ]; then
                echo "Count is Equal to 5."
                echo ""

        elif [ ${buildCount} -ge "5" ]; then
                echo "Count is Greater than or equal to 5."

                buildsNum=`curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | cut -d "b" -f2 | sort -n | head -n -5`

                echo "Build numbers to delete : b${buildsNum}"
                echo "${buildsNum}" > delete.builds.log
                sed 's/^/b/' delete.builds.log > rem.builds.log
                rm -rf delete.builds.log
                echo ""

                while read -r arcBuild; do
                        echo "Deleting build is : ${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                        echo ""
                        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                done < rem.builds.log
        else
                echo "Count is Less than 5."
                echo ""
        fi

        done < $repodir.log
        ;;

### (18)
        RC_TimeBasedEvents_R170)
        echo "Performing ${repodir} ***"
        echo "============================"
        touch "$repodir.log"
        curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > $repodir.log

        while IFS= read -r reposubdir; do

                echo "Directory Path: ${repodir}/${reposubdir}"
                curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > ${subDirLog}

                buildCount=`cat ${subDirLog} | wc -l`
                echo "count is : ${buildCount}"

        if [ ${buildCount} -eq "5" ]; then
                echo "Count is Equal to 5."
                echo ""

        elif [ ${buildCount} -ge "5" ]; then
                echo "Count is Greater than or equal to 5."

                buildsNum=`curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | cut -d "b" -f2 | sort -n | head -n -5`

                echo "Build numbers to delete : b${buildsNum}"
                echo "${buildsNum}" > delete.builds.log
                sed 's/^/b/' delete.builds.log > rem.builds.log
                rm -rf delete.builds.log
                echo ""

                while read -r arcBuild; do
                        echo "Deleting build is : ${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                        echo ""
                        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                done < rem.builds.log
        else
                echo "Count is Less than 5."
                echo ""
        fi

        done < $repodir.log
        ;;

### (19)
        RC_TimeBasedEvents_develop)
        echo "Performing ${repodir} ***"
        echo "============================"
        touch "$repodir.log"
        curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > $repodir.log

        while IFS= read -r reposubdir; do

                echo "Directory Path: ${repodir}/${reposubdir}"
                curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' > ${subDirLog}

                buildCount=`cat ${subDirLog} | wc -l`
                echo "count is : ${buildCount}"

        if [ ${buildCount} -eq "5" ]; then
                echo "Count is Equal to 5."
                echo ""

        elif [ ${buildCount} -ge "5" ]; then
                echo "Count is Greater than or equal to 5."

                buildsNum=`curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repodir}/${reposubdir} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | cut -d "b" -f2 | sort -n | head -n -5`

                echo "Build numbers to delete : b${buildsNum}"
                echo "${buildsNum}" > delete.builds.log
                sed 's/^/b/' delete.builds.log > rem.builds.log
                rm -rf delete.builds.log
                echo ""

                while read -r arcBuild; do
                        echo "Deleting build is : ${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                        echo ""
                        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${repodir}/${reposubdir}/${arcBuild}"
                done < rem.builds.log
        else
                echo "Count is Less than 5."
                echo ""
        fi

        done < $repodir.log
        ;;

        *)
                echo "ERROR: Script not executed properly. Please check and try again !!!"

        ;;

        esac
done < "${outputFile}"
}

# ======================================================
# calling main function - script execution starts here
# ======================================================
RCcleanup

# =================================================*** SCRIPT ENDS HERE ***==================================================
