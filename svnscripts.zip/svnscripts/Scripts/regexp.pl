#!/usr/local/bin/perl -w
#
#
#
#
#
#


print "Dani";


$dir = 'D:\ClientDeployment\test\432233\tmp';
$dir =~ m/(.*)/;
print $_;

exit;


reset_release('D:\ClientDeployment\test\432233\tmp');
# Reset release
sub reset_release {
		my $delfldr = shift;
		# closedir($delfldr);
		chdir ($delfldr);
		$CmdStr = "attrib -R $delfldr\\* /S /D";
		# print "Running $CmdStr\n";
		$CmdRtn = `$CmdStr  2>&1`;
		$CmdStr = "rmdir $delfldr /S /Q";
		# print "Running $CmdStr\n";
		$CmdRtn = `$CmdStr  2>&1`;
		if ($?)
		{   
			$RtnVal = $CmdStr.' failed : '.$CmdRtn;
			undef($RtnVal);	
		}
		rmdir($delfldr);
}

exit;

use Win32::OLE;



		# Step 2 - Copy Release build
		$releasenumber = "9";
		$msg = "Searching the build directory for approved release build...";
		my $pwdir = `cd`;
		chdir($pwdir);
		my $TmpFile = "$pwdir\\TmpFile.txt";
		my $dbTmpFl = "$pwdir\\DBTmpFile.txt";
		my $dbTmpDmlFl = "$pwdir\\DBTmpDmlFile.txt";
		open (TMPFILE, ">$TmpFile") || die "Can't open $TmpFile: $!\n";
		my $vos_bld_dir = "\\\\atli-fs01\\eSolutions_Builds\\iVos\\iVOS-44015";
		find( sub { /^$releasenumber$/ && print TMPFILE "$File::Find::name" }, $vos_bld_dir);
		close(TMPFILE);
		open(TMPFILE, $TmpFile) || die("Could not open file!");
		my @relFileLoc=<TMPFILE>;
		close(TMPFILE);
		$relFileLoc[0] =~ tr/\//\\/;
		print $relFileLoc[0];
		exit;


		

$nonQrel = "422012";
(my $iDgqrel) = $nonQrel =~ m/^(\d{2}).*/;
print $iDgqrel;
exit;

my $userid = "ajarrell";

my @arrRepUsers = qw(ajarrell danggraeni jkiefer ysetiawan bleyderman esorbet mcalica chotz jchung ppatel dvarghese);
if ( grep { $_ eq $userid} @arrRepUsers ) {
	# Disable check-in for reporting users for non-reports folders/files
	if ($cmd !~ m/web\/WEB-INF\/reports/) {
		print STDERR "You can't check-in anything other than 'Reports'!";
		exit(1);
	}
}


foreach (@arrRepUsers) {
# 	print $_ . "\n";
}

exit;


$iVOSCoreFileChecklist = "Jan_2012/test.txt, folder";

my @arrCoreFls = split(/,/, $iVOSCoreFileChecklist);
my @arrFls = ();
my @arrFolders = ();
my $filelist = "";
my $folderlist = "";
my $fllist = "";
my $fldlist = "";

foreach my $crf (@arrCoreFls) {
	if ($crf =~ m/\./){
		$crf = trim($crf);
		push(@arrFls, $crf);
		$filelist .= $crf . ",";
	}
	else {
		$crf = trim($crf);
		push (@arrFolders, $crf);
		$folderlist .= $crf . ",";
	}
}


if (@arrFolders) {
	($fldlist) = $folderlist =~ m/(.*),$/;
	if (scalar(@arrFolders) == 1) {
		print STDERR "All files under folder '$fldlist' are core iVOS files and cannot be checked-in! Please remove/uncheck the file(s) from the 'commit' list to proceed. Please contact your scrum master if you still need to modify file(s) under this folder.";	
		exit(1);
	}
	elsif  (scalar(@arrFolders) > 1) {
		print STDERR "All files under folders '$fldlist' are core iVOS files and cannot be checked-in! Please remove/uncheck the file(s) from the 'commit' list to proceed. Please contact your scrum master if you still need to modify file(s) under this folder.";	
		exit(1);
	}
} elsif (@arrFls) {
	
	($fllist) = $filelist =~ m/(.*),$/;

	if (scalar(@arrFls) == 1) {
		print STDERR "'$fllist' is a core iVOS file and cannot be checked-in! Please remove/uncheck this file from the 'commit' list to proceed. Please contact your scrum master if you still need to modify this file.";
		exit(1);
	}
	elsif  (scalar(@arrFls) > 1) {
		print STDERR "'$fllist' are core iVOS files and cannot be checked-in! Please remove/uncheck the file list from the 'commit' file list to proceed. Please contact your scrum master if you still need to modify this files.";
		exit(1);
	}
} 




sub trim
{
        my $string = shift;
        $string =~ s/^\s+//;
        $string =~ s/\s+$//;
        return $string;
}



exit;
my $fg = "All_-_Diary.htm~scm,";
if ($fg !~ m/\./) {
	print "no dot in the variable\n";
}
else {
	print "DOT in the variable\n";
}



exit;


my $fg = "All_-_Diary.htm~scm,";
($fg) = $fg =~ m/(.*),$/;
print $fg;

exit;


my $fl="All_-_Audit.htm~dvarghese,scm";
@arrData = split('~', $fl);
print $arrData[0];



exit;


$fl = 'c:\DBDMLGEN\iVOS_IP_10-13-2011_1318540025\export\VOSDF00025182';
print $id;


exit;


$dirname = "\\\\atli-fs01\\eSolutions_Builds\\iVos\\_Archive\\TestBuild\\IA_432500";
opendir my($dh), $dirname or die "Couldn't open dir '$dirname': $!";
my @files = readdir $dh;
closedir $dh;


foreach(@files) {
	print $_ . "\n";
	$clientpropstring = "# \n# @(#)client.properties	8/2/2011\n# \n# \"$_\" Properties file\n# \n# Created by : Dani\n#\nCLIENTNAME=";
	chdir "D:\\Install_Package\\Source\\Dist\\Properties";
	DoMkDIR($_);
	chdir "D:\\Install_Package\\Source\\Dist\\Properties\\$_";
	open FILE, ">", "client.properties" or die $!;
	print FILE $clientpropstring;
	close FILE;
}

sub DoMkDIR {
	my $dir = shift;
	$CmdStr = "mkdir $dir";
	if ($opts{v}) { print "\nrunning $CmdStr\n"; }
	$CtRet = `$CmdStr  2>&1`;

	if ($?) {
	  if ($opts{v}) { print "\n$CmdStr returned \n $CmdRtn \n"; }
	}
}



exit;


$comment = "SID:VOSDF12345678 TID : TK12345 : Description";
chomp($comment);
if ($comment =~ m/^SID\s*:\s*(S\d{5}|VOSDF\d{8})\s+TID\s*:\s*TK\d{5}\s*:.*/i) {
	print "\n\n\n".$comment;
}
else {
	print "Comment format should be : SID:S##### TID: T##### : Description";
}
exit;

# .*

# :

$str = "SCM Merge : SID:VOSDF12000112: 4322 : 432215 : 95656-565,454-456 : Comment1212!@!";
# ($tmp) = $str =~ m/^(SCM\s+Merge\s*:\s*SID\s*:\s*VOSDF\d{8}\s*:\s*(\w+|\w+\-+\w+|\w+\-+\w+\-+\w+|\w+\-+\w+\-+\w+\-+\w+|\w+\-+\w+\-+\w+\-+\w+\-+\w+)\s*:\s*(\w+|\w+\-+\w+|\w+\-+\w+\-+\w+|\w+\-+\w+\-+\w+\-+\w+|\w+\-+\w+\-+\w+\-+\w+\-+\w+)\s*:\s*\d+\s*)/i;
#
 
#	print "\n\nSuccess\n\n";
#}
#else {
#	print "\n\noops\n\n";
#}

if ($str !~ m/^(SCM\s+Merge\s*:\s*SID\s*:\s*VOSDF\d{8}\s*:\s*(\w+|\w+\-+\w+|\w+\-+\w+\-+\w+|\w+\-+\w+\-+\w+\-+\w+|\w+\-+\w+\-+\w+\-+\w+\-+\w+)\s*:\s*(\w+|\w+\-+\w+|\w+\-+\w+\-+\w+|\w+\-+\w+\-+\w+\-+\w+|\w+\-+\w+\-+\w+\-+\w+\-+\w+)\s*:\s*([\d,-])+\s*:\s*.*)/i) {

	print "\n\nwrong :";
}
else {
	print "good";
}
exit;



$str = "path1/path2/ivosconfig.propertie1s";
(my $dan) = $str =~ m/ivosconfig.xml|ivosconfig.properties$/;
if ($dan) {
	print "exists\n";
}
else {
	print "not exists\n";
}
exit;

$str = "r8284 | egbekou | 2011-01-11 17:36:12 -0500 (Tue, 11 Jan 2011) | 1 line";
print "\n\n";
$str =~ m/\|(\s+\w+\s+)\|(\s+\d+\-\d+\-\d+\s+\d+\:\d+\:\d)/;
$dt = $2;
$dt =~ s/^\s*//;
$dt =~ s/\s*$//;
print $dt;
print "\n\n";
exit;


# Web Service
use HTTP::Request;
use LWP::UserAgent;
# my $agent = LWP::UserAgent->new(env_proxy => 1,keep_alive => 1, timeout => 30); 
my $agent = LWP::UserAgent->new; 
my $url = "http://atld-ivosdevqa.int.aonesolutions.us:8080/ScmViewer/search/syncRevisions?revision_type=I&revision_id=2227"; 
# my $url = "http://www.google.com"; 
my $header = HTTP::Request->new(GET => $url);
my $request = HTTP::Request->new('GET', $url, $header);

# my $response = $agent->request($header);
my $response = $agent->request($request);

if ($response->is_success){ 
	print $response->content; 
}

# print "Dani";

exit;

$path = 'branches/sdfas-33-4-3-232/test.txt/test';
$path =~ m/(\w+)$/;
print $1;

exit;

$comment = "U branches/sdfas-33-4-3-232/test.txt/test";
chomp($comment);
$comment =~ m/\/(\w+|\w+\-+\w+|\w+\-+\w+\-+\w+|\w+\-+\w+\-+\w+\-+\w+|\w+\-+\w+\-+\w+\-+\w+\-+\w+)\//;
print $1;
exit;
if ($1 eq "4321") {
	print "\n".$1;
}
else {
	print "Dani";
}
exit;

my $lg = "http://svn.int.aonesolutions.us/ivos/java/branches/in-progress";
($rev) = $lg  =~ m/(.*)\/(.*)$/;
print "\n\n" . $2 . "\n";
exit;



#$comment = "43222/web/WEB-INF/classes/test.class";
$comment = "43222/web/test.txt";
$comment =~ m/WEB-INF\/classes(.*)/i;
if ($1) {
	print "\n\n\nCheck in can not allow anything under web-inf/classes location\n";
}
exit;



my $RelStrfile = 'ReleasedStoryList.txt';
open (FL, "$RelStrfile") || print "Can't open $RelStrfile: $!\n";


my $RelsStrfile = 'REL-StoryList.txt';
open (FLS, ">$RelsStrfile") || print "Can't open $RelsStrfile: $!\n";

my @relStFlList=<FL>;
my $sids = "";
my $stry = "";

my @pArrSlist = ();
foreach my $fl (@relStFlList) {
	chomp($fl);
	($sids) = $fl =~ m/\((\d+)/;
	# ($sids) = $fl =~ m/(.*)/;
	if ($sids) {
		if (($sids !~ m/sids/) && (length($sids) eq 5)) {	
			$stry = "VOSDF000" . $sids;
		}
		elsif (($sids !~ m/VOSDF/) && (length($sids) eq 6)) {
			$stry = "VOSDF00" . $sids;
		}
		else {
			$stry = $sids;
		}
	}
	push(@pArrSlist,$stry);
}

my %hash   = map { $_ => 1 } @pArrSlist;
@pArrSlist = keys %hash;
@pArrSlist = sort(@pArrSlist);:/tr


foreach (@pArrSlist) {
	print FLS $_ ."\n";
	print $_ ."\n";
}
close(FL);
close(FLS);
exit;





$dbOPfile = 'brtypes.txt';
open (FL, "$dbOPfile") || print "Can't open $dbOPfile: $!\n";
@dbfileData=<FL>;
foreach $fl (@dbfileData) {
	chomp($fl);
	$fl =~ m/\"(.*)\"/;
	print "$1\n";
}
close(FL);
exit;



$comment = "Story Id:117638 Task IdTK08690:Sh";
chomp($comment);
if ($comment =~ m/^(Story\s+Id|SID)\s*:\s*(\d+|\w+\d+)\s+(Task\s+Id|Tid)\s*:\s*(\d+|\w+\d+)\s*:.*/i) {
	print "\n\n\n".$comment;
}
else {
	print "Comment format should be : Story Id: xxxxx Task Id: xxxxx : Task headline";
}



exit;

$str =  "r373 | dvarghese | 2010-06-23 20:02:20 -0400 (Wed, 23 Jun 2010) | 1 line
Changed paths:
   M /branches/432/ant/bin/build.xml

Story id: VOSDF00120083 Task Id:TK08664
------------------------------------------------------------------------
r413 | nkanthed | 2010-06-24 14:33:09 -0400 (Thu, 24 Jun 2010) | 1 line
Changed paths:
   M /branches/432/src/java/com/valleyoak/db/io/BillReviewImportInterface.java

Story Id : 113400 Task Id:08848 : Medical to Expense Changes for California Bill
------------------------------------------------------------------------
r430 | nkanthed | 2010-06-24 21:39:12 -0400 (Thu, 24 Jun 2010) | 1 line
Changed paths:
   M /branches/432/src/db/mssql/sprint35_sql.txt

Story Id: 107665 Task Id: 08838 : CMS User Guide version 3.0 changes
------------------------------------------------------------------------
r471 | nkanthed | 2010-06-25 14:19:22 -0400 (Fri, 25 Jun 2010) | 1 line
Changed paths:
   M /branches/432/src/db/oracle/sprint35_ora.txt

Story Id: 107665 Task Id: 08836 : CMS User Guide version 3.0 changes
------------------------------------------------------------------------";

$str =~ m/(.*)/;
print $1;
exit;




# FetchStatus Constants identify the status of moving the cursor in a request set.
$CQPerlExt::CQ_SUCCESS = 1;  #The next record in the request set was successfully obtained.
my $CQSession = "";
my $CQUID = "clearquest-svc";
my $PWD = "U#4=1**]163Yq";
my $cqdb = "VOSDF";
my $CQConnection = "AonCQEnterprise";

$CQSession = SetCQSession($CQUID,$PWD,$cqdb,$CQConnection,$CQSession);
if ($CQSession eq "FALSE") {
	# "No CQ Session. Aborting the program...";
	exit;
}

push(@arrCQMasterCRs,"VOSDF00057997");

@ArrMstrCRs = generateMasterCRList(@arrCQMasterCRs);
@ArrMstrCRs = sort(@ArrMstrCRs);
(my $a) = $arrCQMasterCRs[0] =~ m/VOSDF(\d*)/;
$a = 0 + $a;
	
push(@finalCRlist,$arrCQMasterCRs[0]);
foreach my $qlfCRs(@ArrMstrCRs) {
	(my $c) = $qlfCRs =~ m/VOSDF(\d*)/;
	$c = 0 + $c;
		# print $c . ">" . $a . "<br>";
	if ($c > $a) {
		push(@finalCRlist,$qlfCRs);
		#	print "in";
	}
}
	# foreach (@finalCRlist) {
#	print $_ . "<BR>";
#}

my $DepCRLine = getdependantCRs(@finalCRlist,$a);
print $DepCRLine;


#**********************************************************************************************************************************
#  Function :  generateMasterCRList
#  Purpose  :  Generate Master CR list.
#           :  
#  Paramters:  CR, clearcase stream info
#**********************************************************************************************************************************
sub generateMasterCRList {
	my @arrtmpCr = shift;
	my @CRs = @arrCQMasterCRs;
	my @depCRArr = ();
	# my @unique = ();
	my @arrCompiledCR = ();
	my $depcrid = "";
	my %hash = ();
	foreach my $cr (@CRs) {
		%hash = ();
		my $indexCR = "";
		($indexCR)= grep {@arrCompiledCR[$_] eq $cr } 0..$#arrCompiledCR;

		if ($indexCR eq "") {
			my $crdet = GetCRDet($cr);
			my @tempArr = split("~",$crdet);
			
			@depCRArr = GetDepCRs($cr);
			if (scalar (@depCRArr) > 0) {
				# my( $index )= grep { $CRs[$_] eq $cr } 0..$#CRs;
				# delete $CRs[$index];

				foreach my $deCrs (@depCRArr) {
					($depcrid) = $deCrs =~ m/(VOSDF\d*)\~/;
					my( $index )= grep { $CRs[$_] eq $depcrid } 0..$#CRs;
					if ($index eq "") {
						push(@CRs,$depcrid);
						# push(@CRs,$cr . "~" .$depcrid);
					}
				}
				# %hash   = map { $_ => 1 } @CRs;
				# @CRs = keys %hash;
			}
			push(@arrCompiledCR,$cr);
		}
	}
	return @CRs;
}






#**********************************************************************************************************************************
#  Function :  getdependantCRs
#  Purpose  :  Find the dependant CRs
#           :  
#  Paramters:  CR, clearcase stream info
#**********************************************************************************************************************************
sub getdependantCRs {
	my @CRs = shift;
	my $RequestedCR = shift;

	@CRs = @finalCRlist;
	
	my @depCRArr = ();
	# my @unique = ();
	my @arrCompiledCR = ();
	my $depcrid = "";
	my %hash = ();
	my @ArrdepCRDet = ();
	$depCrDetails .=  "Master CR details\tChild CR ID\tChild CR State\tChild CR Severity\tChild CR Submitted Date\tChild CR Headline\n";
	foreach my $cr (@CRs) {
		%hash = ();
		my $indexCR = "";
		($indexCR)= grep { @arrCompiledCR[$_] eq $cr } 0..$#arrCompiledCR;

		if ($indexCR eq "") {
			@depCRArr = GetDepCRs($cr);
			if (scalar (@depCRArr) > 0) {
				my ($index)= grep { $CRs[$_] eq $cr } 0..$#CRs;
		
				my $crdet = GetCRDet($cr);
				my @tempArr = split("~",$crdet);
				$depCrDetails .=  "$tempArr[0]\t\t$tempArr[1]\n";

				foreach my $deCrs (@depCRArr) {
					($depcrid) = $deCrs =~ m/(VOSDF\d*)\~/;

					@ArrdepCRDet = split("~",$deCrs);
					my $depcrrow = "";

					$indexCR = "";
					($indexCR)= grep { @arrCompiledCR[$_] eq $depcrid } 0..$#arrCompiledCR;	

					if ($indexCR eq "") {
						foreach my $ddet (@ArrdepCRDet) {
							if ($ddet) {
								if ($ddet =~ m/VOSDF\d*/) {
									$depCrDetails .= "$ddet\t";							
								}
								else {
									$depCrDetails .=  "$ddet\t";
								}
							}
							else {
								$depCrDetails .=  "\t";
							}
						}
						$depCrDetails .=  "\n";
					}
				}
				%hash   = map { $_ => 1 } @CRs;
				@CRs = keys %hash;
				# @CRs = sort(@CRs);
				
			}
			push(@arrCompiledCR,$cr);
		}
	}
	return $depCrDetails;
}



#  Function :  trim
#  Purpose  :  This function trims the string passed and returned.
#           :  
#  Paramters:  string
#**********************************************************************************************************************************
sub trim {
	my $string = shift;
        if ($string) {
           $string =~ s/^\s+//;
           $string =~ s/\s+$//;
        }
	return $string;
}





#**********************************************************************************************************************************
#  Function :  GetDepCRs
#  Purpose  :  Find the dependant CRs
#           :  
#  Paramters:  CR, clearcase stream info
#**********************************************************************************************************************************
sub GetDepCRs {
	my $mstrcr = shift;
	my @arrDepCRs = ();	
	$mstrcr = trim($mstrcr);
	my $sqlQuery  = "select distinct T1.dbid,T2.id,T3.name,T2.Severity,T2.Submit_Date,T2.Headline from Defect T1,Defect T2,parent_child_links T2mm,statedef T3 where T1.dbid = T2mm.parent_dbid  (+)  and 16781916 = T2mm.parent_fielddef_id  (+)  and T2mm.child_dbid = T2.dbid  (+)  and T2.State = T3.id (+)  and (T1.dbid <> 0 and ((T2.id is not NULL and T1.id = '$mstrcr')))";

	
	# my $sqlQuery  = "select distinct T1.dbid,T24.id,T50.name,T24.Severity,T24.resolve_date,T24.Headline from Defect T1,Defect T24,parent_child_links T24mm,statedef T50 where T1.dbid = T24mm.parent_dbid (+) and 16781916 = T24mm.parent_fielddef_id (+) and T24mm.child_dbid = T24.dbid (+) and T24.State = T50.id (+)  and (T1.dbid <> 0 and ((T24.id is not NULL and T1.id = '$mstrcr')))";

	# print $sqlQuery;


	my $resultSet = $CQSession->BuildSQLQuery($sqlQuery);
	$resultSet->Execute();
	while($resultSet->MoveNext() == $CQPerlExt::CQ_SUCCESS)
	{
		# print "Dependant CRs : ". $resultSet->GetColumnValue(2)."\n";	

		# @arrSprints
		push(@arrDepCRs,$resultSet->GetColumnValue(2). "~" . $resultSet->GetColumnValue(3) . "~" . $resultSet->GetColumnValue(4) . "~" . $resultSet->GetColumnValue(5) . "~" . $resultSet->GetColumnValue(6));

	}
	return @arrDepCRs;
}





#**********************************************************************************************************************************
#  Function :  GetCRDet
#  Purpose  :  Find the CR details
#           :  
#  Paramters:  CR, clearcase stream info
#**********************************************************************************************************************************
sub GetCRDet {
	my $mstrcr = shift;
	my $retCRDet = "";

	my $sqlQuery  = "select distinct T1.dbid,T1.id,T29.name,T1.Severity,T1.Submit_Date,T1.Headline from Defect T1,statedef T29 where T1.State = T29.id and (T1.dbid <> 0 and (T1.id = '$mstrcr'))";

	
	my $resultSet = $CQSession->BuildSQLQuery($sqlQuery);
	$resultSet->Execute();
	while($resultSet->MoveNext() == $CQPerlExt::CQ_SUCCESS)
	{
		$retCRDet .= $resultSet->GetColumnValue(2) . "~State=" . $resultSet->GetColumnValue(3) . "\t\tSeverity=" . $resultSet->GetColumnValue(4) . "\t\tSubmitted Date=" . $resultSet->GetColumnValue(5) . "\t\tHeadline=" . $resultSet->GetColumnValue(6);

	}
	return $retCRDet;
}



# ***************************** Enable ClearQuest Session *****************************
sub SetCQSession
{
	my ($CQUser,$CQPwd,$CQDB,$CQConn,$CQSession) = @_;
	$CQSession = Win32::OLE->new("CLEARQUEST.SESSION") or die "Can't create ClearQuest session object via call to Win32::OLE->new(): $!";

	eval
	{
		$CQSession->UserLogon("$CQUser", "$CQPwd","$CQDB", 2,$CQConn);
	};
	
	my $ufullname = $CQSession->GetUserFullName();
	if ($ufullname)
        {
		return $CQSession;
	}
	else {	
		return "FALSE"; 	
	}
	
	
}


exit;

$cr = "VOSDF001212345";
(my $c) = $cr =~ m/VOSDF(\d*)/;
$c = 0 + $c;
print $c;

exit;


$bl = "VOSDF00074607~Resolved~2-Major~2009-11-23 16:24:20~WSI Payment Transactions for Withholding Save Error";
($bls) = $bl =~ m/(VOSDF\d*)\~/;
@ArrdepCRDet = split("~",$bl);
foreach (@ArrdepCRDet) {
	print $_;
}
print $bls;


exit;

$bl = 'baseline:iVos4.2.4.0.0_Core_272_2010-04-07_07.43.57@\ucm_pvob';
(my $bls) = $bl =~ m/\:(.*)\@/;
print $bls;


exit;

$dbcrs = "VOSDF812345";
(my $dbw) = $dbcrs =~ m/VOSDF(.*)/;
$dbw =~ s/^0*//;
print $dbw;

exit;



$dbOPfile = 'C:\Dani\Scripts\removeSpecialChars.txt';
open (FL, "$dbOPfile") || print "Can't open $dbOPfile: $!\n";
@dbfileData=<FL>;
foreach $fl (@dbfileData) {
	chomp($fl);
	$fl =~ s/\s//;
	push(@tmpArr,$fl);
	print "$fl\n";
}
close(FL);
exit;







open (OUTFL, "+>$dbOPfile") || print "Can't open $dbOPfile: $!\n";
@dbfileData=<FL>;
@tmpArr = ();
foreach $fl (@dbfileData) {
	chomp($fl);
	$fl = "'$fl',";
	print OUTFL $fl;
	push(@tmpArr,$fl)
}
exit;

$str = "iVos4.2.3.1.0_33";

$str =~ m/(.*)\_/;
print $1;

exit;


$dbOPfile = "C:\\Dani\\Scripts\\WIDBChangeCRIdsOutput.txt";
open (OUTFL, ">$dbOPfile") || print "Can't open $dbOPfile: $!\n";


$dbfile = "C:\\Dani\\Scripts\\WIDBChangeCRIds.txt";
open (FL, "$dbfile") || print "Can't open $dbfile: $!\n";
@dbfileData=<FL>;
@tmpArr = ();
foreach $fl (@dbfileData) {
	chomp($fl);
	$fl = "'$fl',";
	print OUTFL $fl;
	push(@tmpArr,$fl)
}
exit;



$srcFldr = "RC:ucm_ivos\\ivos\\src\\java\\com\\valleyoak\\action\\claim\\EigIncidentClaimAction.java";
$srcFldr =~ s/\s/$srcFldr/;


$fl = "SRC:ucm_ivos\\ivos\\src\\java\\com\\valleyoak\\action\\claim\\EigIncidentClaimAction.java  DEST:ucm_ivos\\ivos\\custom\\eig\\src\\java\\com\\valleyoak\\action\\claim";

$fl =~ m/SRC\:(.*)\s+DEST\:(.*)/;
# print $1 . "\n" . $2;

$first = $1;
(my $srcFldr) = $first =~ m/(.*)\\(.*)\\(.*)/;

print $1 . "\n" . $2. "\n" . $3  ;

# print $srcFldr;



exit;


#my $ctrbval = 'M:\REL4.2.CB1_Int_Bld_View\ucm_ivos\ivos\event@@\main\MAIN_INT\achidambaram_rel_4.3x_qa\2\chevronCaseEvent.jsp\main\REL4.2.CB1\lliu_AON_4.2CB1x\5';
#my $ctrbval = 'M:\REL4.2.CB1_Int_Bld_View\ucm_ivos\ivos\src\java\com\valleyoak\model@@\main\MAIN_INT\rel4.2x\lliu_AON_4.2x\12\Timezone.java\main\lliu_AON_4.2CB1x\1';
my $ctrbval = 'M:\REL4.2.CB1_Int_Bld_View\ucm_ivos\ivos\src\java\com\valleyoak\model@@\main\MAIN_INT\rel4.2x\REL4.2.CB1\lliu_AON_4.2CB1x\1';


$ctrbval =~ m/.*(\\.*\.(java|jsp|xml)).*/;
print $1;
exit;

$fls =  'C:\HotFix\2009-04-0913_47_17\ivos\WEB-IN\web.xm1l';
if (($fls !~ m/ivosConfig.xml|license.xml|web.xml/)) {
	print "not exists";
}
else {
	print "iVosConfig/license/web xml files...no need to copy...\n";
}

exit;

my ($bl) = $str =~ m/.*(\\.*\\.*)\@\@.*$/;
if ($bl =~ m/\./) {
	print $bl . "\n";
}


exit;

$fl = 'stream:TstRel424x@\ucm_test_project, stream:TstRel425x@\ucm_test_project, stream:TstRel426x@\ucm_test_project, stream:TstRel427x@\ucm_test_project, stream:scm_TstRel424x@\ucm_test_project, stream:scm_TstRel425x@\ucm_test_project, stream:scm_TstRel426x@\ucm_test_project, stream:scm_TstRel427x@\ucm_test_project, stream:TstRel424x_Bld@\ucm_test_project, stream:TstRel425x_Bld@\ucm_test_project, stream:TstRel426x_Bld@\ucm_test_project, stream:TstRel427x_Bld@\ucm_test_project, stream:TstRel428x@\ucm_test_project, stream:TstRel429x@\ucm_test_project, stream:TstRel428x_Bld@\ucm_test_project, stream:scm_TstRel429x@\ucm_test_project, stream:scm_TstRel428x@\ucm_test_project, stream:TstRel429x_Bld@\ucm_test_project, stream:TstRel42x_Bld@\ucm_test_project';
# print $fl;
@arr = split (", ",$fl);
foreach (@arr) {
	$cmd = "cleartool lsstream -fmt %[views]p $_";
	$rtn = `$cmd $_ 2>&1`;
	print "$_\n";
	my @arr1 = split (" ",$rtn);
	foreach (@arr1) {
		print "\t".$_ . "\n";
		if ($_ =~ m//) {

		}
	}
}
exit;


$tmpfls = 'resources/pas_en_US.properties';

$str = 'C:\HotFix\2009-02-1818_23_47\ivos/WEB-INF/classes/pas_en_US.properties';
if ($str =~ m/.*\.(properties)$/) {
	$tmpfls =~ s/resources\///;
}
print $tmpfls;
exit;

@arr1 = qw(1 2 3 4 5);
@arr2 = qw(6 7 8 9 10);

foreach (@arr1){
	push (@arr2,$_);
}

foreach (@arr2) {
	print "$_\n";
}
exit;


$srtr = "test.sql";
if ($srtr =~ m/(\.sql)|(\.trg)/) {
	print "exits";
}
exit;

#my @date1 = (2008,9,21,22,00,00);-  Function format
	$frmCompDtTime = "iVos4.2.1.0.1_270_2009-02-12_11.00.52";
	$frmCompDtTime =~ m/\_[\d]+\_([\d]+)\-([\d]+)\-([\d]+)\_([\d]+)\.([\d]+)\.([\d]+)/;
	$strFrmDt = "$1 $2 $3 $4 $5 $6";
	# print $strFrmDt; 


	$frmCompDtTime ='2008-11-17 18:18:54';
	$frmCompDtTime =~ m/([\d]+)\-([\d]+)\-([\d]+)\s([\d]+)\:([\d]+)\:([\d]+)/;
	$strFrmDt = "$1 $2 $3 $4 $5 $6";
	print $strFrmDt; 
	exit;



	@EmailLst = 'dvarghese@valleyoak.com,scm@valleyoak.com,test.com,';

	foreach $emLst (@EmailLst) {
		$emLst .= $emLst . ",";
	}
	print $emLst ."\n";
	$emToLst = $emLst =~ m/(.*)\,$/;
	print $emToLst;
	exit;


$CQCRs = "12121,12321,23223,88888";

if ($CQCRs =~ m/,/)  {
	my @tmparrCQCRs = split(/,/,$CQCRs);	
	foreach my $tmcr (@tmparrCQCRs) {
		if ($tmcr !~ m/VOSDF000/) {
			$CQCR = "VOSDF000" . $tmcr;
		}
		else {
			$CQCR = $tmcr;
		}
		push(@arrCQCRs,$CQCR);
	}

}
else {
	if ($CQCRs !~ m/VOSDF000/) {
		$CQCR = "VOSDF000" . $CQCRs;
	}
	else {
		$CQCR = $CQCRs;
	}
	push(@arrCQCRs,$CQCR);
	
	# 
}

foreach (@arrCQCRs) {
	print "$_\n";
}	

exit;

$dbwi = "VOSDF00012345";
$dbwi =~ m/VOSDF000(.*)/;
print $1;
exit;

@WIChngSet =qw(1.CSU\check_register.sql 2.payment_processing\check_register2.xml);

my @DMLDBChanges = ();
foreach my $dbprg (@WIChngSet) {
	if ($dbprg =~ m/\.sql/) {
		$dbprg =~ m/([\w]*\.[\w]*)$/;
	}
}

exit;






exit;

$dbfile = "C:\\Dani\\Scripts\\sql1.txt";
open (FL, "$dbfile") || print "Can't open $dbfile: $!\n";
@dbfileData=<FL>;
@tmpArr = ();
foreach $fl (@dbfileData) {
	chomp($fl);
	$fl = "select REL_FID,custNAme from customer where custName like '%$fl%'\n";
	print $fl;
	push(@tmpArr,$fl)

}
exit;

$rel = "iVos4.2.1.0.1_137 + HF-6,28,30,31,32,36,45,47,48,60,74,77,100,119,133,139";
$rel =~ m/(.*)\_.*$/;
print $1;
exit;



$custRelString = "iVos4.2.1.0.1_<>+HF102,1,12,112,1,2121,121,12";
if ($custRelString =~ m/\</) {
	$custRelString =~ m/(.*)\_\<\>(.*)/;
	$fhRelName =  $1.$2;
}
else {
	$custRelString =~ m/(.*)\_(.*)/;
	$fhRelName =  $1.$2;
}
$custRelString =~ m/(.*)\_(.*)/;
print 	$fhRelName;
exit;

$VosRel = "iVos4.2.1.0.1";
$VosRel =~ m/iVos(\d)\.(\d).*/;
my $hfRelArea = "D:\\Releases\\" . $1 . $2 . "x\\Hotfixes\\Customer";
print $hfRelArea;

exit;

use Win32::ODBC;

print pad_zeros(1);

sub pad_zeros {    
    my $optimal_length = 4;
    my $num = shift;
    $num =~s/^(\d+)$/("0"x($optimal_length-length$1)).$1/e;
    return $num;
}

exit;



my $scmDb = new Win32::ODBC('driver={SQL Server};Server=DVARGHESE-CQ\SQLEXPRESS;database=scm;UID=sa;PWD=s@mivosr3l;') or print Win32::ODBC::Error();

my $hfPath = "C:\\HotFix\\020609";
my $prj = "rel4.2x";
my $customer = "ADM";

# return hotfix number and increment the same
my $HFRelNum = retHFRelNum($customer,$scmDb);
$HFRelNum++; # increment for the next hotfix


my $sysInfopath = "$hfPath\\$prj\\system\\systemInfo.jsp";
open (SYSINFOFILE, "$sysInfopath") || die "Can't open $sysInfopath: $!\n";
my @arrSysInfo=<SYSINFOFILE>;
close(SYSINFOFILE);

my $custVers = "iVos4.2CB1_<>";
my $tmp1 = "HF-12,13,16,17,20,21,28,39";
my $custRelString = "";
# Build hotfix release string and update the same with customer info table.
if ($tmp1) { 
	$custRelString = $custVers . " + " . $tmp1. ",$HFRelNum";
}
else {
	$custRelString = $custVers . " + "  . "HF $HFRelNum";
}

# <span style="position:absolute;top:14;left:5;font-size:9px;color:green;">Release #: "iVos4.2.1.0.1"     </span>

my @modSysInfoFl = ();
foreach my $sysln (@arrSysInfo) {
	if ($sysln =~ m/Release #:/) {
		(my $sysVerLn) =  $sysln =~ m/\>(.*)\</;
		$sysln =~ s/$sysVerLn/Release #:$custRelString/; 
	}
	push(@modSysInfoFl,$sysln);
}


$sysInfopath = "$hfPath\\$prj\\system\\systemInfo.jsp";
open (SYSINFOFL, ">$sysInfopath") || die "Can't open $sysInfopath: $!\n";
foreach (@arrSysInfo) {
	print SYSINFOFL "$_";
}
close(SYSINFOFL);



my ($cstmr,$hfNum,$dbObj) = @_;
my $result = updateDBHfInfo($customer,$HFRelNum,$custRelString,$scmDb);


exit;


#**********************************************************************************************************************************
#  Function :  retHFRelNum
#  Purpose  :  Hotfix Release number
#  Return   :  
#  Paramters:  $cstmr
#**********************************************************************************************************************************
sub retHFRelNum{
	my ($cstmr,$dbObj) = @_;

	$sqlQuery = "SELECT max(hfrel.HF_Num) as relNumber FROM HFRelease hfrel 
	INNER JOIN customer cust ON (hfrel.HFCustFID = cust.custPID) 
	INNER JOIN Release rel ON (cust.REL_FID = rel.RelPID)
	WHERE 
	cust.REL_FID = rel.RelPID
	AND REL_FID = (SELECT cust.REL_FID from customer cust where cust.CustName = '$cstmr')";
	

	$dbObj->Sql($sqlQuery);
	$ret = $dbObj->error() if !$ret;
	my %custData = ();
	my $relNumber;

	while($dbObj->FetchRow() && !$ret)
	{
		%custData = $dbObj->DataHash() if !$ret;
		$ret = $dbObj->error() if !$ret;
		$relNumber = $custData{"relNumber"};

	}
	return $relNumber;
}




#**********************************************************************************************************************************
#  Function :  updateDBHfInfo
#  Purpose  :  Update hotfix info
#  Return   :  
#  Paramters:  $cstmr,$hfNum,$dbOb
#**********************************************************************************************************************************
sub updateDBHfInfo{
	my ($cust,$hfnum,$relString,$dbobj) = @_;


	# UPDATE CUSTOMER RECORD WITH THE NEW UPDATED COMPLETE RELEASE STRING WHICH CONTAINS THE HOTFIX INFO
	$sqlquery = "update customer set HF_RelStr = '$relString' where custname = '$cust'";
	print "$sqlquery\n";
	$dbobj->sql($sqlquery);
	$result = $dbobj->error();

	$dbobj->transact($dbobj->sql_commit) if (!$result && $dbobj->getfunctions($dbobj->sql_api_sqltransact)) ;
	$result = $dbobj->error() if !$result;

	return $result;
}



# ---------------------------------------------------------

my %hfdet = ();
my $relfile = "c:\\dani\\scripts\\hfreldet.txt";
#open (relfile, "$relfile") || print "can't open $relfile: $!\n";
#my @relfldata=<relfile>;
my @hfhfflds = ();
my $dts = "";
#foreach (@relfldata) {
	#print "$_\n";
	@hfhfflds = split(/\s+/,$_);
	$dts = "";
	foreach (@hfhfflds){
		$dts .= $_. "~"; 
	}
	push(@{$HFDet{$hfhfflds[1]}}, $dts);
#}

my @indMemb = ();
my $basePrj = ();
foreach my $ht (keys %HFDet) {
	foreach my $memb (@{$HFDet{$ht}}) {
		@indMemb = split(/~/,$memb);
		($basePrj) = $indMemb[3] =~ m/\\\\[\w]*\\[\w]*\\(.*)\\.*/;

		$sqlString = "INSERT INTO HFRelease(HF_Name, HF_Num, HF_Date, HF_Path, HFTempCust, AonContact, BaseProj) VALUES \
				('$ht', $indMemb[0], '$indMemb[1]', '$indMemb[2]', '$indMemb[3]', '$indMemb[4]', ' $basePrj')";
		print "$sqlString\n";		
	}
}




exit;


chdir('C:\ccstg_c\dvarghese_SCMUtils\SCMUtils');

$res = `cleartool lscheckout -all -brtype bkalra_AON_4.2x`;
print $res;
exit;


my $rtn ='c:\scm_SCMUtils\ucm_ivos\ivos\src\com\valleyoak@@\main\MAIN_INT\czhang_AON_4_2x\1\pas\main\czhang_AON_4_2x\2\controller\main\czhang_AON_4_2x\15\ClearRatingController.java\main\czhang_AON_4_2_3_0\1';

(my $fls) = $rtn =~ m/\\[\w]*\\(.*)/;

print "$fls\n\n\n";
chomp($fls);
if ($fls  !~ m/UniversityOfColorado/) {
	print $fls;
}
exit;

if (!$flcps) {
	($flcps) = $fls =~ m/.*\\ivos\\(.*)/;
}
print $flcps;
exit;


$fls = 'C:\scm_SCMUtils\SCMUtils\Scripts\UCMHotfixAuto\ivos\WEB-INF\classes\com\valleyoak\action\claim\AcordClaimAction.class';
$fls =~ tr/\\/\//;
print $fls;

exit;	       


my ($dirfile) = $tmp =~ m/.*\/(.*\.[\w]*)$/;
print $dirfile;

exit;


$tmp = "billreview\\BillAmountAllowedDescComparator.class";
$tmp =~ tr/\\/\//;

# my ($dirfile) = $tmp =~ m/(.*)\$.*$/;
 ($dirfile) = $tmp =~ m/\/(.*\.[\w]*)$/;
print $dirfile;


exit;

$fls = 'C:\scm_SCMUtils\SCMUtils\Scripts\UCMHotfixAuto\ivos\WEB-INF\classes\com\valleyoak\action\claim\AcordClaimAction.class';
# my ($flcps) = $fls  =~ m/\/(.*)/;
# my ($flcps) = $fls  =~ m/\/(.*)/;
my ($flcps) = $fls  =~ m/.*\\(.*[\\].*[.].*)$/;

$flcps =~ m/(.*)\.[\w]*$/;
print $1;
exit;



print $flcps;
exit;

my $tmp = "WI-VOSDF00038847-Dev - 4.2x - Hartford Claim Export 12/29/2008 Rejection";
$tmp =~ m/^WI\-(VOSDF[\d]*)\-/;
print $1;
exit;

$base_path = 'C:\Dani\ptkdb';
@allfiles = process_files ($base_path);
foreach my $fl (@allfiles){
	print $fl . "\n";
}

# Accepts one argument: the full path to a directory.
# Returns: A list of files that reside in that path.
sub process_files {
    my $path = shift;

    opendir (DIR, $path)
        or die "Unable to open $path: $!";


    my @files =
        # Third: Prepend the full path
        map { $path . '/' . $_ }
        # Second: take out '.' and '..'
        grep { !/^\.{1,2}$/ }
        # First: get all files
        readdir (DIR);

    closedir (DIR);

    for (@files) {
        if (-d $_) {
            # Add all of the new files from this directory
            # (and its subdirectories, and so on... if any)
	    
            push @files, process_files ($_);

        } else {
            # Do whatever you want here =) .. if anything.
	    # print "$_\n";
        }
    }
    
    # NOTE: we're returning the list of files
    return @files;
}

exit;


$str = "xcopy failed on : xcopy ivos\\etc\\licenses\\UC\\license.xml sbhongal_4.2x_7_29_2008_0247PM.1802_to_REL4.2.1.0.1x_2008-09-12_20.00.03_Upg\\ivos\\etc\\licenses\\UC\\ /Q /Y /I";
$str =~ s/xcopy failed on : xcopy//;
@tmparr = split(/\s/,$str);
($restr) = $tmparr[1] =~ m/.*\\(.*[.].*)$/;
print $restr;
exit;

ftpUpload();


sub ftpUpload
{
	use Net::FTP;
	use Fcntl qw(O_WRONLY O_RDONLY O_APPEND O_CREAT O_TRUNC);

	my $dns    = 'ftp://vosftp.valleyoakasp.com/';
	my $user   = 'wsi';
	my $passwd = 'TGw2XRMG*@';
	my $dir    = 'tmp';

	my $ftp = Net::FTP->new( $dns, Debug => 0 ) 
	  or die "Cannot connect to $dns: $@";
	$ftp->login( $user, $passwd )
	  or die "Cannot login ", $ftp->message;
	$ftp->cwd($dir)
	  or die "Cannot change working directory ", $ftp->message;

	my ( $loc, $buf, $data );
	my ( $remote, $local );
	$remote = $local = 'Test.txt';

	$data = $ftp->retr($remote)
	  or die "unable to retrieve $remote\n";

	unless ( sysopen( $loc, $local, O_WRONLY | O_TRUNC | O_CREAT ) ) { 
	    die "Cannot open $local: $!\n";
	}

	while ( my $len = $data->read( $buf, 2048 ) ) { 
		printf( " %d bytes read\n", $len );

		unless ( print $loc $buf ) { 
        		die "Cannot write to $local: $!\n";
		        $data->abort;
        		close($loc);
		}   
	}
	print "Total read : ", $data->bytes_read(), "\n";

	$data->close;
	$ftp->quit;
}

exit;

my $fl = '2.reports\Quick Reports\litigation\litigationClaimant_Detail.xml';
$fl =~ m/([\w.\w]*)$/;
print $1. "\n";


exit;

my $dbdir = "C:\\Dani\\Scripts\\testfiles";
my $dbUpgMode = "ORA"; 
my $cnCDbfl = dbFlConcat($dbdir,$dbUpgMode);
print $cnCDbfl;

sub dbFlConcat {

	my $db_dir = shift;
	my $DBUpgMode = shift;
	
	opendir(DIR, $db_dir) || print "can't opendir $db_dir: $!";
	my @a = ();
	@a =
	  sort {(stat "$db_dir/$a")[9] <=> (stat "$db_dir/$b")[9]}
	  grep {  -f "$db_dir/$_" }
	  readdir(DIR);
	closedir DIR;

	# print join "\n", @a;
	my $dbUpgfile = "";

	my $dbFile = "";
	foreach $dbFile(@a) {
		# print $dbFile . "\n";

		# print "\n\n\n====================================\n\n";

		chdir "$db_dir" || print "Cannot cd to $db_dir";

		open (DBFILE, "$dbFile") || print "Can't open $dbFile: $!\n";
		my @dbfileData=<DBFILE>;

		# if ($DBUpgMode eq "ORA") {
			$dbUpgfile .= "/* *************** $dbFile *************** */\n\n";
		# }
		# else {	
		#	$dbUpgfile .= "-- *************** $dbFile *************** \n\n";
		# }
		foreach my $dbfldt (@dbfileData) {
			$dbUpgfile .= $dbfldt;
		}
		if ($DBUpgMode eq "ORA") {
			$dbUpgfile .= "\ngo\n";
			$dbUpgfile .= "/*  -------- End of $dbFile -------- */\n\n\n";
		}
		else {
			$dbUpgfile .= "/\n";
			$dbUpgfile .= "/*  -------- End of $dbFile -------- */\n\n\n";
		}
	
		close(DBFILE);
	}
	return $dbUpgfile;
}

exit;


$test = "iVos42CB1";
if ($test =~ m/cb/i) {
	my $cbVer =$test;
	$cbVer =~ s/\.//g;
	
	print $cbVer . "\n";
	# @nums = $cbVer =~ m/(\d)([\w]+)/g;
	@nums = $cbVer =~ m/(\d+)\w/g;
	foreach (@nums) {
		print $_ . "";
	}
}
else {
	@nums = $test =~ m/\d/g;
	foreach (@nums) {
		print $_ . " ";
	}

}



exit;

my $DBWIID = "\\\\cbuild1\\scm_view_dbstore\\dbstore\\dev42/ora_db/cq35346_ora.txt";
$DBWIID =~ tr/\//\\/;
print $DBWIID;
exit;


use File::Find;

use File::Basename;
#yyyy-mm-dd hh:mm:ss.ffffff'


$tst = "test.sql\"";
$tst =~ s/"//g;
print $tst;
exit;

$baseFile = "DefaultServlet.class";
$fl = "DefaultServletvar1.class";
$baseFile =~ s/\.(.*)//;
print "$baseFile\n";
if ($fl =~ m/$baseFile/) {
	print "yes";
}
else {print "no";}


exit;


$stream = "REL4.2x";
# 42-dbchange-FL R3 EDI WC FROI/SROI Implementation

(my @nums) = $stream =~ m/\d/g;
my $ptrn1 = "";
my $ptn2 = "";
foreach (@nums){
	$ptrn1 .= $_;
	$ptn2 .= $_ . ".";
}
(my $ptrn2) = $ptn2 =~ m/(.*)\.$/;
my $ptrn3 = $ptrn2 . "x";
if ($stream =~ m/CB/) {
	$ptrn1 .= "CB";
	$ptrn2 .= "CB";
	$ptrn3 .= "CB";
}
$str = "42101-dbchange-FL R3 EDI WC FROI/SROI Implementation";                                  

if ($str =~ /$ptrn1-|$ptrn2-|$ptrn3-/) {
	print "Yes\n";
}
elsif ($str =~ /CB/) {
}
else {
	print "No\n";
}

exit;


$str = "18-Sep-08.03:30:26";
(my @arrdt) = $str =~ m/(\d\d)-(.*)-(\d\d)\.(\d\d)\:(\d\d):(\d\d)/;
$frmDt = "20".$arrdt[2] . "-" . $arrdt[1] . "-" . $arrdt[0] . " " . $arrdt[3] . ":" .   $arrdt[4];
print $frmDt;
foreach (@arrdt) {
#	print $_ . "\n";
}

exit;

$frmDt = "12-12-08.12:12:12";
$frmDt =~ s/\./ /;
print $frmDt;
exit;


$str = "xcopy failed on : xcopy ivos\\etc\\licenses\\UC\\license.xml sbhongal_4.2x_7_29_2008_0247PM.1802_to_REL4.2.1.0.1x_2008-09-12_20.00.03_Upg\\ivos\\etc\\licenses\\UC\\ /Q /Y /I";
$str =~ s/xcopy failed on : xcopy//;
@tmparr = split(/\s/,$str);
($restr) = $tmparr[1] =~ m/.*\\(.*[.].*)$/;
print $restr;
exit;



$ln = "18-Sep-08.12:13:26";
# 	my @date1 = (2008,9,21,22,00,00);
$ln =~ m/(.*)\-(.*)\-(.*)\.(.*)\:(.*)\:(.*)/;
print $6 . "\n";
exit;


$str = "cleartool lsbl baseline:iVos4.2.x_172_2008-09-18_03.30.06@\\ucm_pvob";
$str = `$str`;
my @tmpArr = split(/\s+/,$str);
print $tmpArr[0] . "\n"; # - datetime
print $tmpArr[1] . "\n"; # - baseline
print $tmpArr[5] . "\n"; # - stream



exit;
if ($str =~ m/.*\..*\@\@/) {
	print "found";
}
else {
	print "not found";	
}
# print $str;
exit;

$fullFile = "ivos/src/com/valleyoak/db/io/SroiExportSpec.class";
$fullFile =~ s/\/src\//\/WEB-INF\/classes\//;
print $fullFile;
exit;

$fls = 'test\testweb\testlibb\file.-finaltestfla.jar';

my $filename = basename($fls);
print "$filename\n";

$destDir = dirname($fls);
print "$destDir\n";

exit;

$fls = 'test\testweb\testlibb\file.-finaltestfla.jar';
my ($tst) =  $fls =~ m/\\(.*)$/; 
print "$tst\n";
exit;


my $srcUpgFl = $fls;
my ($destFl) = $fls =~ m/\\([\w.]*)$/;
$destFl ="";
$fls =~ s/$destFl//;
print $fls;

exit;

$fm = 'test@\ucm_pvob';
$fm =~ s/\@\\.*//;
print $fm;


exit;

$fls = 'C:/Dani/Scripts/ivos/reports/State_and_Federal_Regulatory/OSHA/OSHA_301.xml@@/main/MAIN_INT/asheibani_AON_4.2.1.0.1x/1';
my $base = `cd`;
chomp($base);
$fls =~ s/\@\@.*//s;
$fls =~ s/^\Q$base\E//;
$fls =~ tr/\//\\/;
$srcUpgFl = $fls;

($destFl) = $fls =~ m/([\w.\w]*)$/;
$fls =~ s/$destFl//;
my $destUpgFldr = $fls;

$CmdStr = "xcopy $srcUpgFl $destUpgFldr /Q /Y /I";
print "running $CmdStr\n";
my $CmdRtn = `$CmdStr  2>&1`;


exit;




@arr = ("test", "test","dani","Shob");

@neaarray = ("test1f");
foreach (@arr) {
	if ( grep { ($_) eq 'test'} @neaarray ) {
	      print "create new defect from multiple defects\n";
	}
}
exit;

$upgFileLst = 'C:/ccstg_c/dvarghese_SCMUtils\ucm_ivos\ivos\reports\State_and_Federal_Regulatory\OSHA\OSHA_301.xml@@\main\MAIN_INT\asheibani_AON_4.2.1.0.1x\1';

 ( $Chfile ) = $upgFileLst=~ m{\/\/\/([\w.\w]*)\@\@};
print "The file is : $Chfile";

exit;

$dest = "ivos\\WEB-INF\\classes\\com\\valleyoak\\db\\io\\BillReviewExportInterface.class";
my ($fnlDest) = $dest =~ m/([\w]*)\\/;
print $fnlDest;
exit;


exit;

# $Chfile = "test.java";
#$Chfile =~ s/.java/.class/;
#print $Chfile;

exit;

find( sub { /^Defect_Graph.pl$/}, 'Other');
$tmp = $File::Find::name;
print "Before : " . $tmp . "\n";
$tmp =~ s/ivos/replace/g;
print "After : " . $tmp ."\n";
# $tmp =~ m{[\w]*([\w]*)};
exit;


# $string = '(None | No Qualifier | @@NO HELP@@ | @@NO SORT INDEX@@)';
# $string =~ m/\|\s+([^|]*)\s+\|/;
# print $1;
# exit;

$upgFileLst = 'C:\ccstg_c\dvarghese_SCMUtils\ucm_ivos\ivos\reports\State_and_Federal_Regulatory\OSHA\OSHA_301.xml@@\main\MAIN_INT\asheibani_AON_4.2.1.0.1x\1';

my ( $Chfile ) = $upgFileLst =~ 
	m{
		
		(
			[\w]*
		)
		\@\@

	};

print "The file is : $Chfile";

exit;



# my ( $second_word ) = $string =~
#  m{
#       \|        # "|" escaped because it's special inside a regexp
#       (         # start capturing
#           [^|]* # some not |'s
#       )         # end capture
#       \|        # another "|"
#  }x;


$val = "Pegisys";
if ($val =~ m/^(Pegisys)|(Seadragon)$/i) {
	print "matches";
}
else {
	print "NO matche";
}

exit;

# in SeaDragon
my @arrSDGenHLs = ("Data Item - Missing|DataItem - Missing","Data Item - Incorrect|DataItem - Incorrect","DTC|DTC","Special Test|Special Test",	
				"Repair Information Incorrect|Repair Information","System functionality issue|System","Text Error|Text Error", 
				"No/Intermittent communication|No Communication","Lockup/Application crash|Lock up","Major Coverage Gap|Coverage Gap",
				"Enhancement Request|Enhancement Request","Damage/Injury|Damage/Injury","Other|Other","Hardware|Hardware","AST/DTC Quick Scan info incorrect|Automated System Test",
				"OBDII|OBDII","Inaccurate Scope Measurement|Other","Minor Coverage Gap|Coverage Gap","Repair Information Missing|Repair Information","Cosmetic Issue|Other");

my $SDMapHDs = "";
my @arrTmp = ();				
foreach my $tmpVar (@arrSDGenHLs) {
	@arrTmp = split(/\|/, $tmpVar);
		$arrTmp[0] =~ s/^\s*//;
		$arrTmp[0] =~ s/\s*$//;
		$arrTmp[1] =~ s/^\s*//;
		$arrTmp[1] =~ s/\s*$//;
		if ($arrTmp[0] eq "Other") {
 			$arrTmp[0] =~ s/$arrTmp[0]/$arrTmp[1]/;
		}
}

print $arrTmp[0]. "\n";

exit;


$diTestRes = "121~test~1~8~495";
if ($diTestRes =~ m/^DGMiss/) {
	print "DGMiss";
}
elsif  ($diTestRes =~ m/^DIMiss/) {
		print "DIMiss";
}
else {
	print "DI Incorrect";
}
exit;


my $test = "PGTST00002674 , PGTST00002674 , PGTST00002674 , 		 ";
print $test . "\n";
$test =~ s/\s*,?\s*$//;
$test = $test . "Dani\n";

print $test;

exit;


$test = "PGTST00002674		 PGTST00002674		 PGTST00002674		 ";
print $test . "\n";
#$test =~ s/\s*$//;
$test .= "\tDani-1";
$test =~ m/\s*(PGTST)$/;
print $test . " : " . $1 . "\n";
$test =~ s/\s*$//;
$test = $test . "Dani-2\n";

print $test;


exit;

my ($sec,$min,$hour,$day,$month,$yr19,@rest) =   localtime(time);
my $dt = ++$month . "-$day-".($yr19+1900);
print $dt;

exit;

$str = "sdfasdfasdf";
$str =~ s/^\s*$/-/;
print $str;

exit;


$str = "tdest'test'eee'";
$str =~ s/'/''/g;
print $str;

exit;

# $str = "Submitted";
# $str = "ReSubmitted";
$str = "Submitted";

if ($str =~ /(Submitted$)|(Reviewed)/i) {
	print "found!";
}
else
{
	print "not found!";
}


exit;

$str = "
==== State: Opened by: chakida on 11 April 2008 16:36:05 ====

test
";



# $_ =  "The : food is under the bar in the barn.";
$str =~ s/\n\n+/\n/g; 
print "$str";


exit;

$string = '(None | No Qualifier | @@NO HELP@@ | @@NO SORT INDEX@@)';
$string =~ m/\|\s+([^|]*)\s+\|/;
print $1;
exit;

my ( $second_word );
my $string = '(None | No Qualifier | @@NO HELP@@ | @@NO SORT INDEX@@)';
($second_word) = $string =~ m/\|\s+([^|]*)\s+\|/;
print $second_word;
exit;

#$string = '(None | No Qualifier | @@NO HELP@@ | @@NO SORT INDEX@@)';
#my $secondWord = ( split m{\s*\|\s*}, $string )[1];
#print $secondWord;
#exit;




# Or, in more detail:

# my ( $second_word ) = $string =~
#  m{
#       \|        # "|" escaped because it's special inside a regexp
#       (         # start capturing
#           [^|]* # some not |'s
#       )         # end capture
#       \|        # another "|"
#  }x;

exit;


$string = '(None | No Qualifier | @@NO HELP@@ | @@NO SORT INDEX@@)';

my @foo = split(/\|/, $string);
$foo[1] =~ s/\s+//;
$foo[1] =~ s/\s+$//;
# print $foo[1];


# $string =~ s/\|//;
# print $string;
# substr($string,index($string,"|"));



# $ctres =~ s/^\s+//;
# $ctres =~ s/\s+$//;

exit;

$str = '(None | No Qualifier | @@NO HELP@@ | @@NO SORT INDEX@@)';

my $res = substr $str, 8, 12;
print $res;


exit;

$str = "Last Action History    : 

==== State: Opened by: chakida on 09 April 2008 16:18:04 ====



test



==== State: Assigned by: cquser on 09 April 2008 10:15:07 ====



Defect state has been moved to 'Assigned', since the Defect prefix is alread
y assigned to this defect



==== State: Submitted by: cquser on 07 April 2008 09:45:04 ====



New 'Genisys' defect 'GNTST00000135' has been created in the database 'GNTST'";

if ($str =~ /^\S*$/) {
	print "blank lines";
}
else {
	print "no blank lines";
}

exit;


my $bldnum = "112";
$result =  "1";
if ($bldnum =~ /^\d*$/) {
	if ($bldnum >= 1000) {
		print "$bldnum can not exceed more thatn 1000";
		$result =  "false";
	}
	else {
		$result =  "";
	}
}
else
{
	print "not a number : $bldnum";
	$result =  "false";
}

exit;

$affectedPrj = "Genisys AND test";

my $createDefFlg = 0;
if ($affectedPrj =~ /&|,|and|AND/)
{
	$affectedPrj =~ s/and|&|,|AND/,/;
	print $affectedPrj . "\n";
	my @prjs = split(",",$affectedPrj);


	if ( grep { Trim(convToLowerCase($_)) eq 'genisys'} @prjs ) {
	      print "create new defect from multiple defects\n";
	      $createDefFlg = 1;
    	}
}
else {
	if ($affectedPrj eq "Genisys") {
	     $createDefFlg = 1;
	}
}

if ($createDefFlg eq 1) {
	print "Create Genisys Defect";
}
else {
	print "No defect Genisys Defect creation is required";
}


sub Trim($)
{
   my $string = shift;
    if ($string) {
        $string =~ s/^\s+//;
        $string =~ s/\s+$//;
    }
	return $string;
}

sub convToLowerCase($)
{
	my $string = shift;
	$string =~ tr/A-Z/a-z/;
	return $string;
}


exit;

$str = "33561922        Mar 11 2008  9:06AM     chakida Submit  no_value        Submitted";
# if ($str =~ /Submit/i && ) {
if (grep(/Submit/, $str))
{
	my($garb, $month, $day, $year, $time, $laOwner, $action) = split(/\s+/, $str);
	if ($laOwner =~ /^simon|jordah|gravedi|engbarda|kilanoad|obrien|ulrichji|wiemanca$/) {
#		print "yup";
	}
	
}
else {
#	print "oops";
}




# $str = "1";
# if ($str =~ /^[\d]*$/) {
#	print "found digits";	
# }


# if ($str =~ /\d/) {
#    print "only digits";

#}

