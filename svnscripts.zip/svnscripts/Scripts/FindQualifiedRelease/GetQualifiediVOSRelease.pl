#!/usr/bin/perl -w

# ********************************************************************************
# Written by Dani
# Date : March 19 2012
#
# get fully qualified list here
#    svn ls http://svn.int.aonesolutions.us/ivos/java/branches

# just get the full log only on the input stream (input parameter)
#    svn log -v http://svn.int.aonesolutions.us/ivos/java/branches/44101

# Get stop-on-copy logs of all the other streams
#    svn log --stop-on-copy -v http://svn.int.aonesolutions.us/ivos/java/branches/44005

# Extract Stories for each stream and create a hash
	# Remove VOSDF and V - we need just the numbers
	# Consider Merged stories as well when do the extraction (from new storydbtool automation)

	# Eg:
#      	    432205 = 123,123,12323,12312,123123
#           44102 = 232,1232,12312,12312,12312
	
# Compare stories with the input stream and decide the qualifying release.

# Print the result in a good format.

# Expose this functionaly to the web (for Kelly)
#
# Explore the possibilities of verbose and debug mode. Give as much information as possible during these modes
# May be write to a file with DATTIME stamp
# *********************************************************************************
 
use Getopt::Std;
use warnings;
use strict;
use Switch;

my $CmdStr ="";
my $CmdRtn = "";
my $RtnVal = "";
my $result = "";
my @branches = ();
my @relBranches = ();
my @formatRelBranches = ();


my ($sec,$min,$hour,$day,$month,$yr19,@rest) =   localtime(time);
my $dttm = ++$month . "-$day-".($yr19+1900) . " $hour:$min:$sec ";


my %opts = ();
getopts("r:hvx",\%opts) or die "ERROR : Invalid  options \n";

if ($opts{h}) { 
	PrintHelp();
	exit;
}

if (!$opts{r}) { 
 	if ($opts{v}) { verbosePrint($dttm, "HELP option called");};
	PrintHelp();
	exit;
}

my $release = $opts{r};
if ($opts{v}) { verbosePrint($dttm, "Input paramter 'release' is  : $release");};

$CmdStr = "svn ls http://svn.int.aonesolutions.us/ivos/java/branches";
if ($opts{v}) { verbosePrint($dttm, $CmdStr);}
$CmdRtn = `$CmdStr  2>&1`;
if ($opts{x}) { verbosePrint($dttm, $CmdRtn);}
@branches = split("/",$CmdRtn);
foreach (@branches) {
	if ($_ !~ m/[a-z]/i) {
		$_ = trim($_);
		if (($_) && (length($_) >= 5)) {
			if ($_ !~ m/^(43221|43222|432110|43250801)$/) {
				push(@relBranches, $_);
				if ($opts{v}) { verbosePrint($dttm, $_);}
			}
		}
	}
}

my $max = (sort { $b <=> $a } @relBranches)[0];
if ($opts{x}) { verbosePrint($dttm, "$max is the max value");}


@relBranches = sort(@relBranches);
my @QlRelCandidates = ();
foreach (@relBranches) {
	if ($_ =~ m/$release/) {
		last;
	}
	else {
		push (@QlRelCandidates,$_);
	}
}
if ($opts{x}) { 
	if ($opts{v}) { verbosePrint($dttm, "\n\n\nQUALIFYING RELEASE CANDIDATES ARE :\n");}
	foreach (@QlRelCandidates) {
		if ($opts{v}) { verbosePrint($dttm, "$_");}
	}
}



# Get log of requested release
my @relfulllog = ();
my @relstids = ();
$CmdStr = "svn log -v http://svn.int.aonesolutions.us/ivos/java/branches/$release";
if ($opts{v}) { verbosePrint($dttm, $CmdStr);}
$CmdRtn = `$CmdStr  2>&1`;
if ($opts{x}) { verbosePrint($dttm, $CmdRtn);}
@relfulllog = split(/\n/,$CmdRtn);
foreach my $lg (@relfulllog) {
	my $stid = "";

	($stid) = trim($lg) =~ m/^\s*Story\s+ID\s*:\s*(VOSDF\d{8}|V\d{6}).*/i;
	if ($stid) {
		push(@relstids,$stid);
	}

	($stid) = trim($lg) =~ m/^\s*SID\s*:\s*(VOSDF\d{8}|V\d{6}).*/i;
	if ($stid) {
		push(@relstids,$stid);
	}

	($stid) = trim($lg) =~ m/^\s*SCM\s+Merge\s*:\s*SID\s*:\s*(VOSDF\d{8}|V\d{6}).*/i;
	if ($stid) {
		push(@relstids,$stid);
	}

	($stid) = trim($lg) =~ m/^\s*SCM\s+Merge\s*:\s*Story\s*ID\s*:\s*(VOSDF\d{8}|V\d{6}).*/i;
	if ($stid) {
		push(@relstids,$stid);
	}
}

my %hash   = map { $_ => 1 } @relstids;
@relstids = keys %hash;
@relstids = sort(@relstids);
foreach (@relstids){
	if ($opts{v}) { verbosePrint($dttm, "All stories for the requested release are : \n$_");}
}


# retrieve the story IDs and put into the array or comma seperated string
my %RelCands = ();
my $key = "";
my $value = "";
my @QualRellog = ();
my @arrQlReleases = ();
my @nonQualReleases = ();
my $nonQrel = "";
my $n_stids = "";
foreach my $qrel (@QlRelCandidates) {
	
	my $iDgqrel = "";
	if (length($qrel) == 6) {
		($iDgqrel) = $qrel =~ m/^(\d{4}).*/;
	}
	elsif (length($qrel) == 5) {
		($iDgqrel) = $qrel =~ m/^(\d{3}).*/;
	}
	else {
		($iDgqrel) = $qrel =~ m/^(\d{2}).*/;
	}
	if (($nonQrel) && (length($nonQrel) == length($qrel)) && ($nonQrel =~ m/^$iDgqrel/) && ($qrel gt $nonQrel)) {
		$n_stids = "";
		next;
	}

	my @QualRelstids = ();
	if ($qrel) {
		$CmdStr = "svn log --stop-on-copy -v http://svn.int.aonesolutions.us/ivos/java/branches/$qrel";
		# $CmdStr = "svn log -v http://svn.int.aonesolutions.us/ivos/java/branches/$qrel";
		if ($opts{v}) { verbosePrint($dttm, $CmdStr);}
		$CmdRtn = `$CmdStr  2>&1`;
		

		@QualRellog = split(/\n/,$CmdRtn);
		foreach my $lg (@QualRellog) {
			my $stid = "";

			($stid) = trim($lg) =~ m/^\s*Story\s+ID\s*:\s*(VOSDF\d{8}|V\d{6}).*/i;
			if ($stid) {
				push(@QualRelstids,$stid);
			}

			($stid) = trim($lg) =~ m/^\s*SID\s*:\s*(VOSDF\d{8}|V\d{6}).*/i;
			if ($stid) {
				push(@QualRelstids,$stid);
			}
		

			($stid) = trim($lg) =~ m/^\s*SCM\s+Merge\s*:\s*SID\s*:\s*(VOSDF\d{8}|V\d{6}).*/i;
			if ($stid) {
				push(@QualRelstids,$stid);
			}

			($stid) = trim($lg) =~ m/^\s*SCM\s+Merge\s*:\s*Story\s*ID\s*:\s*(VOSDF\d{8}|V\d{6}).*/i;
			if ($stid) {
				push(@QualRelstids,$stid);
			}
		}
	}
	my %Qlhash   = map { $_ => 1 } @QualRelstids;
	@QualRelstids = keys %Qlhash;
	@QualRelstids = sort(@QualRelstids);
	my $flg = "";
	foreach my $qlrids (@QualRelstids){
		$flg = "";
		my $tmp_qlrids = $qlrids;
		$tmp_qlrids =~ s/VOSDF//;
		$tmp_qlrids =~ s/V//;
		$tmp_qlrids = $tmp_qlrids + 0;

		foreach my $rids (@relstids) {

			if ($rids =~ m/$tmp_qlrids/) {
				$flg = "T";
				last;
			}

			# handle exceptions
			if ($tmp_qlrids =~ m/124564|124768|124773/) {
				$flg = "T";
				last;
			}
		}
		if (!$flg) {
			$n_stids .= $qlrids . ",";
		}
		
	}
	if (!(@QualRelstids)) {
		$n_stids = "";
	}

	if (!$n_stids) {
		push (@arrQlReleases, $qrel);
	}
	else  {
		(my $nstids) = $n_stids =~ m/(.*),/;
		print "\n\n'$qrel' and above releases are not qualified for the upgrade to '$release' because atleast one or more below IDs are not present in $release:\n$nstids";
		push(@nonQualReleases,$qrel);
		$nonQrel = $qrel;
		push (@arrQlReleases, "\n");
	}
}


print "\n\nQualifying releases for the release '$release' are :\n";
foreach (@arrQlReleases) {
	print "$_\n";
}	






 









# ** User defined functions **
# Print Help
sub PrintHelp
{
   print <<EOF;
   
   usage: $0 -r <enter 5 or 6 digit svn stream/release to find all qualified release>

    $0 -r 44101 -v -x

   -v : Verbose mode
   -x : Debug Mode
   -h : Help
EOF
}



# Print the verbose message
sub verbosePrint  {
	my $dttm = shift;
	my $Debugmsg = shift;
	print $dttm . $Debugmsg . "\n";
}


sub trim
{
        my $string = shift;
        $string =~ s/^\s+//;
        $string =~ s/\s+$//;
        return $string;
}

