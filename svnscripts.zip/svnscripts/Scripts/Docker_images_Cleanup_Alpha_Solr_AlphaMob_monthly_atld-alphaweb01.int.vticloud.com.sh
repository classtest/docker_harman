#!/bin/bash
#This script is to cleanup docker images older than a month on server atld-alphaweb01.int.vticloud.com. It has been setup in cron tab to run on monthly basis on respective server.
echo "*********Alpha images Cleanup********"
echo ""
docker images | grep docker-registry-dev.int.vticloud.com/alpha | grep develop-[0-9] | grep -P "([5-9] weeks)" > imagecleanup_alpha.log
echo "Docker images qualified for deletion are:"
echo ""
cat ./imagecleanup_alpha.log
old_images=`cat ./imagecleanup_alpha.log | awk '{print $3}'`
echo "**********Deleting image ids are*******"
echo ${old_images[@]}
docker rmi ${old_images[@]}
echo "Cleanup of Alpha images done."

echo "*********Solr images Cleanup********"
echo ""
docker images | grep docker-registry-dev.int.vticloud.com/solr | grep develop-[0-9] | grep -P "([5-9] weeks)" > imagecleanup_solr.log
echo "Docker images qualified for deletion are:"
echo ""
cat ./imagecleanup_solr.log
old_images=`cat ./imagecleanup_solr.log | awk '{print $3}'`
echo "**********Deleting image ids are*******"
echo ${old_images[@]}
docker rmi ${oldi_images[@]}
echo "Cleanup of solr images done."

echo "*********Alpha mobile images Cleanup********"
echo ""
docker images | grep docker-registry-dev.int.vticloud.com/alpha-mobile | grep b[0-9]-* | grep -P "([5-9] weeks)" > imagecleanup_alphamobile.log
echo "Docker images qualified for deletion are:"
echo ""
cat ./imagecleanup_alphamobile.log
old_images=`cat ./imagecleanup_alphamobile.log | awk '{print $3}'`
echo "**********Deleting image ids are*******"
echo ${old_images[@]}
docker rmi ${old_images[@]}
echo "Cleanup of alphamobile images done."
