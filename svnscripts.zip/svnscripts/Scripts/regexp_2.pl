#!/usr/bin/perl -w

use strict; 
use warnings;
use File::Find;

use REST::Client;

my $CmdStr="";
my $CmdRtn="";
my $RtnVal="";
my $dir = "";


my @lockedfiles = ();

@lockedfiles = ("/Product Management/RIS.one/Data Model/Claim/logical/entity/seg_0/54A7F8A7-6BF0-95CC-554B-1AF7A4FD24DB",
"/Product Management/RIS.one/Data Model/Claim/logical/subviews/97F0C6CA-ECDB-6C99-8B6B-9D159384C51C",
"/Product Management/RIS.one/Data Model/Claim/logical/entity/seg_2/0D9C38FC-F857-84D0-71F5-CF9325C8469F",
"/Product Management/RIS.one/Data Model/Claim/logical/entity/seg_1/5FA77DB4-2F1B-3CB8-0A76-74D8FAABE078",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_0/C0C9CB3D-DC7B-C1B0-EC8B-37DCFC51FBB7",
"/Product Management/RIS.one/Data Model/Claim/logical/note/seg_0/50AE6EB5-F5BC-071B-EB5C-1883F6DB4076",
"/Product Management/RIS.one/Data Model/Claim/logical/entity/seg_2/5331A52B-9AEF-86C3-5ED8-8153FCDDB282",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_3/D6DC1FE1-5836-EE65-D919-DB6104179974",
"/Product Management/RIS.one/Data Model/Claim/rel/7D4D6A0F-492BDC61DFB5/foreignkey/seg_3/945B99EB-0CD6-69F4-63D1-D643DED0F325",
"/Product Management/RIS.one/Data Model/Claim/logical/entity/seg_2/3A258B72-DD9E-4075-B6FC-41DD96203AC2",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_1/A2E4381C-AB6D-0DCA-8CC1-FC312C83E924",
"/Product Management/RIS.one/Data Model/Claim/rel/7D4D6A0F-492BDC61DFB5/table/seg_1/FBFD5CE7-F204-E8CC-9C0D-C47D914BCBB4",
"/Product Management/RIS.one/Data Model/Claim/rel/7D4D6A0F-492BDC61DFB5/foreignkey/seg_2/16CD2CFC-5BA7-C8E8-E7CF-60E780B3B706",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_1/0F15FE4C-43B9-5769-D69B-FCAE5491E2A7",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_0/E58405E7-EE3F-A660-8B4A-431E554DDF62",
"/Product Management/RIS.one/Data Model/Claim/logical/note/seg_0/2858EEF3-1612-868B-D62F-0A730B45BDA5",
"/Product Management/RIS.one/Data Model/Claim/logical/note/seg_0/1DE8D215-933F-BFFB-A04A-5BB37D0EFABC",
"/Product Management/RIS.one/Data Model/Claim/logical/entity/seg_1/D0F983E1-3CC5-DDF7-898D-3CFDFE16A865",
"/Product Management/RIS.one/Data Model/Claim/rel/7D4D6A0F-492BDC61DFB5/foreignkey/seg_1/38CAA5F3-FB3D-8F35-F728-F91D407E890A",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_0/ABAA0210-0801-1D35-68A7-7D66F69D8762",
"/Product Management/RIS.one/Data Model/Claim/rel/7D4D6A0F-492BDC61DFB5/foreignkey/seg_3/786809FD-C239-1420-B0D0-CE7B034880FD",
"/Product Management/RIS.one/Data Model/Claim/logical/entity/seg_2/58E80C58-2190-DF07-7C92-2DF8D8A144A4",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_1/3B195BFB-8D82-E413-F38F-1D81A777D55B",
"/Product Management/RIS.one/Data Model/Claim/rel/7D4D6A0F-492BDC61DFB5/table/seg_0/6CB9A8ED-1918-1B23-3A80-3BD24719F39B",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_1/381EACB4-B213-6D51-75AB-82647A8E70E8",
"/Product Management/RIS.one/Data Model/Claim/logical/entity/seg_0/48D14517-7C72-684C-DFA0-80D6CFE9CB1A",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_0/E8AE3AA1-70EA-8B14-BFEC-AE355D163EED",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_3/02B6F2D0-7360-A9B8-609B-C17CF10D6AA8",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_2/88279442-B9F0-F765-62B4-6795CA2AAE7E",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_1/1C755A1D-14E2-ED58-2451-8C201B4D47D9",
"/Product Management/RIS.one/Data Model/Claim/logical/entity/seg_0/B95FC261-DAA6-87C2-6B05-7A0B39331B50",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_1/7A3D6EB4-C803-CB4B-F732-DFE827CE4055",
"/Product Management/RIS.one/Data Model/Claim/rel/7D4D6A0F-492BDC61DFB5/table/seg_0/71A1DF4C-F517-6BBD-0741-63FF247A20EC",
"/Product Management/RIS.one/Data Model/Claim/logical/entity/seg_0/0D1B72E1-1809-4E30-7266-6B1F6367E7B8",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_1/53F0939C-DAF7-E5E0-EE24-E16420F5BC7E",
"/Product Management/RIS.one/Data Model/Claim/logical/subviews/C4B560A5-507A-554E-31EC-366888E57327",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_1/AFABE1E5-0CC4-23A1-ADE6-A083C3D33D57",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_1/19B51EA1-82A2-1B60-A9B9-D53A4CA1765A",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_3/4835950F-C5F2-80A7-72A3-C574D29DCFFB",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_3/3E24D537-81E4-5628-3995-31A41042404D",
"/Product Management/RIS.one/Data Model/Claim/logical/entity/seg_2/94AEA446-9CAB-06E0-AF1F-E5007141B738",
"/Product Management/RIS.one/Data Model/Claim/logical/note/seg_0/C677F73D-0A52-477D-1689-D0E9A2564BBE",
"/Product Management/RIS.one/Data Model/Claim/logical/note/seg_0/2B252A40-067E-9A32-69ED-E99A67A0871A",
"/Product Management/RIS.one/Data Model/Claim/rel/7D4D6A0F-492BDC61DFB5/foreignkey/seg_0/68B58D93-904A-5A87-5370-1B6A6D389C53",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_0/AE1438AF-BF02-47D6-121C-DB4E3C8F880F",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_3/3375A4C2-A22F-BD01-BE16-59411565C99E",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_0/707661B7-AE4A-0083-A6A8-1E2327D78249",
"/Product Management/RIS.one/Data Model/Claim/logical/note/seg_0/A3C94821-BC6D-E509-B291-C9D5DF96CCD4",
"/Product Management/RIS.one/Data Model/Claim/rel/7D4D6A0F-492BDC61DFB5/foreignkey/seg_0/4D77AA07-741B-4FA9-6A51-60908613FA5A",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_0/698841B0-4A69-B8CC-6D90-517EECA576E7",
"/Product Management/RIS.one/Data Model/Claim/rel/7D4D6A0F-492BDC61DFB5/foreignkey/seg_0/680E7F59-0365-A8AA-162B-B95639ED5A9C",
"/Product Management/RIS.one/Data Model/Claim/logical/note/seg_0/62FABA8B-21D4-8502-1E4D-0D7EB141EE9C",
"/Product Management/RIS.one/Data Model/Claim/rel/7D4D6A0F-492BDC61DFB5/foreignkey/seg_0/EE65F025-A1B2-10EC-7676-EC1A87870966",
"/Product Management/RIS.one/Data Model/Claim/logical/entity/seg_0/A2886A6E-E77E-1881-B7BE-9DF78F464EF4",
"/Product Management/RIS.one/Data Model/Claim/rel/7D4D6A0F-492BDC61DFB5/table/seg_0/CF90C906-60D7-C128-978F-75601FDE0C89",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_0/2F96C642-A860-1A9F-5FB9-2CD2168694E9",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_0/DA3AC3B4-085A-EDC9-5FC3-FFD253205C8B",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_0/5FA10E10-761B-83A3-3C14-79283C43449D",
"/Product Management/RIS.one/Data Model/Claim/logical/entity/seg_1/DEA51023-9A7B-D6C7-DBAB-81FDDB3F1B21",
"/Product Management/RIS.one/Data Model/Claim/rel/7D4D6A0F-492BDC61DFB5/foreignkey/seg_3/D09BAC80-53FE-F0BB-7198-1F93A084E91B",
"/Product Management/RIS.one/Data Model/Claim/rel/7D4D6A0F-492BDC61DFB5/table/seg_2/A709483D-0726-7047-1FCE-CF1B551AF940",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_0/E7B9A148-6E6B-3466-A2ED-63974B28F27B",
"/Product Management/RIS.one/Data Model/Claim/logical/entity/seg_0/DC213394-93BC-90A5-AD59-E91D2B7728AB",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_3/374A70F9-CE3A-EB0A-48A2-F800C08C32B4",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_3/4C3F9039-50AE-EEAC-D13A-A43949CC578D",
"/Product Management/RIS.one/Data Model/Claim/logical/entity/seg_1/ED20AE60-6E62-53BD-7F86-C7E03345D87C",
"/Product Management/RIS.one/Data Model/Claim/logical/entity/seg_2/E99AD698-A41A-46C5-0790-614CB9F87635",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_0/E9362F06-EADD-D99B-2D5B-DFF0483711A9",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_0/B956EBD9-1F2D-741B-7FAB-348FF768884D",
"/Product Management/RIS.one/Data Model/Claim/logical/relation/seg_0/4926EE7A-AFEF-2FC2-85FE-5B684134C43F",
"/Product Management/RIS.one/Data Model/Claim/rel/7D4D6A0F-492BDC61DFB5/table/seg_0/910BB31F-DD5C-8A94-20F1-EB4BAF2351D9");


foreach my $fl (@lockedfiles) {
	my $cmd="svnadmin rmlocks /mnt/u01/svn/repositories/doc/all \"$fl\"";
	print $cmd . "\n";
}


exit;


my $blnkFile = "blankReport.xml";
my $vos_dir = 'D:\temp\ivos';


my $pwdir = `cd`;
my $TmpFile = "TmpFile.txt";
open (TMPFILE, ">$TmpFile") || die "Can't open $TmpFile: $!\n";

# Search blank report files
print "Search blank report file in directory $vos_dir...\n\n";
find( sub { /^$blnkFile$/ && print TMPFILE "$File::Find::name\n" }, $vos_dir);

close(TMPFILE);
open(TMPFILE, $TmpFile) || die("Could not open file!");
my @blankfilepath=<TMPFILE>;
close(TMPFILE);

my %hash   = map { $_ => 1 } @blankfilepath;
@blankfilepath = keys %hash;

@blankfilepath = sort(@blankfilepath);

print "\n\nBlank file List\n";
foreach my $blnFlPt (@blankfilepath) {
	print $blnFlPt;
}

if (scalar(@blankfilepath) > 0) {
	# Delete blank report files
	print "\n\nDeleting blank report files";
foreach my $blnFlPt (@blankfilepath ) {
	$blnFlPt =~ tr/\//\\/;

	$CmdStr = "DEL /F $blnFlPt";
	print "Running $CmdStr \n";
	$CmdRtn = `$CmdStr 2>&1`;
	if ($?)
	{   
		$RtnVal = $CmdStr.' failed : '.$CmdRtn;
		undef($RtnVal);	
	}
}
}
else {
	print "No blank report xml file";
}

#unlink @file_list;


exit;

use Getopt::Std;
my %opts = ();


getopts("d:vxh",\%opts);

if ($opts{h}) {
  	PrintHelp();
  	exit 0;
}

if (!$opts{d})
{
   	print "ERROR:  Invalid Options\n";
   	PrintHelp();
   	exit 0;
}
elsif ($opts{d} !~ m/^\d+$/) {
	print "Please enter a number for the number of days\n";
	PrintHelp();
	exit 0;
}

my $client = REST::Client->new();
$client->setHost('http://atld-rcsvn05:8081/artifactory');
$client->addHeader("Authorization", "Basic c3ZuYWRtaW46QzBkM1M0ZjM=");

$client->GET(
    '/api/build/Alpha'
);

print $client->responseContent() . "\n" if $opts{v};

my @delblds = ();

(my @bldinfo) = $client->responseContent() =~ m/.*(\"uri\"\s*\:\s*\"\/)(\d+)\",\s*(\"started\"\s*\:\s*\")(\d{4}\-\d{2}\-\d{2}).*/;
print "Build number : " .  $bldinfo[1] . " and build date : " . $bldinfo[3] . "\n"  if $opts{v};

my $thirty_days = $opts{d} * 24 * 60 * 60;
my ($old_day, $old_month, $old_year) = (localtime(time - $thirty_days))[3..5];
my $cutoff = sprintf('%04d-%02d-%02d', 
                     $old_year + 1900, $old_month + 1, $old_day);

if ($bldinfo[3] lt $cutoff) {
	push (@delblds,$bldinfo[1]); 
}

print "\n\nArtifactory Builds to be deleted\n************************\n\n";
my $cnt = 1;
foreach my $dbn (@delblds) {
	print "$cnt. $dbn\n";
	$cnt++;
}



# ***************************** Print Help *****************************
sub PrintHelp
{
   print <<EOF;
   
   usage: $0 -d <no of days you need to keep the artifactory builds>

   Eg : perl -w $0 -d 30

   -d : No of days you need to keep the artifactory builds
   	Please enter only a number

   -v : Verbose mode
   -x : Debug Mode
   -h : Help
EOF
}



exit;

print "Deleting build";
$client->DELETE(
    '/api/build/Alpha?buildNumbers=1401822727255&artifacts=1'
);


exit;

#The basic use case
$client = REST::Client->new();
$client->GET('http://atld-rcsvn05:8081/artifactory/api/build/Alpha');
print $client->responseContent();



exit;



 $CmdStr = "svn log http://svn.int.aonesolutions.us/ivos/java/branches/in-progress";
 $CmdRtn = `$CmdStr  2>&1`;


open (MYFILE, '>>data.txt');
print MYFILE "$CmdRtn";
close (MYFILE);

print "$CmdRtn<BR>";
exit;


