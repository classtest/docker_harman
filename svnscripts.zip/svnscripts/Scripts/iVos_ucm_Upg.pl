#!/usr/local/bin/perl -w

# Generate Upgrade
#
# Options : 	
#		-v -> verbose mode
# 		-x -> Debug mode
# 		-f -> Recommend baseline after build
# 		-t -> Build Name
# 		-h -> Help
# 		-d -> DB Upgrade only
#		
# Steps to get through this...	  
# Accept baseline information (from and to baseline)
# Gather the activities have been delivered (diffbl) (we dont do the contributing activities for now)
# For each activity, find the change set associated with it. (name of the files)
# Login to ClearQuest and get the necessary details from ClearQuest like (DB change, State etc).
# Generate report
#	
# Copy the ivos.war file from built location
# Unzip the ivos.var
# search the file in the ivos folder
# copy the file from there and create a new directory named with the patch name and paste there
# once we have all files, using the command line zip, zip the file
# create readme
# email
# Get the WI information from CQ
# Find the dB change list
# Gather DB change list and create DB upgrade file for SQL as well as Oracle

use Getopt::Std;
use warnings;
use strict;
use Time::Local;
# use Data::Dumper;
use File::Find;
use File::Basename;
use Win32::OLE;
#use CQPerlExt;
use Carp qw( carp );


# FetchStatus Constants identify the status of moving the cursor in a request set.
$CQPerlExt::CQ_SUCCESS = 1;  #The next record in the request set was successfully obtained.

my $sqlQuery = "";
my $resultSet = "";
my $CmdStr ="";
my $CmdRtn = "";
my $RtnVal = "";
my $result = "";
my $Paramattrb = "";	
my $ParamattribVal = "";
my $ParamattribObj = "";
my $AttrType = "";
# how to use data::dumper explains below
# use Data::Dumper
# print Dumper($var name);


#my @files = qw(
#  C:\\scm_SCMUtils\\SCMUtils\\Scripts\\parseFile.pl
#  );

#for my $f (@files) {
#	 printf "'%s' has the modified date time : %s : ", $f, (get_mtime($f) || 'n/a');
#};
#exit;



my $CQSession = "";
my $CQUID = "clearquest-svc";
my $PWD = "U#4=1**]163Yq";
my $cqdb = "VOSDF";
my $CQConnection = "AonCQEnterprise";

$CQSession = SetCQSession($CQUID,$PWD,$cqdb,$CQConnection,\$CQSession);
# my $fullname = $CQSession->GetUserFullName();


# ***************************** Full List with complete version information for each activity *****************************
my $logFile = 'ActivityFullversionInfo.txt';
open (FILE, ">$logFile") || die "Can't open $logFile: $!\n";

my $cqRptFile = 'CQRpt.txt';
open (CQRPTFILE, ">$cqRptFile") || die "Can't open $cqRptFile: $!\n";

my $TmpFile = 'TmpFile.txt';
open (TMPFILE, ">$TmpFile") || die "Can't open $TmpFile: $!\n";

my $ORADBUpgFileLnks = 'ORADBUpgFileLinks.txt';
open (ORADBUPGFILE, ">>$ORADBUpgFileLnks") || die "Can't open $ORADBUpgFileLnks: $!\n";

my $SQLDBUpgFileLnks = 'SQLDBUpgFileLinks.txt';
open (SQLDBUPGFILE, ">>$SQLDBUpgFileLnks") || die "Can't open $SQLDBUpgFileLnks: $!\n";

my $iVosUpgFlLst = "iVosUpgFileList.txt";
open(IVOSUPGFILES,">$iVosUpgFlLst") || die "Can't open $iVosUpgFlLst: $!\n";

my %opts = ();
my %BldHash = ();

getopts("f:t:vxhd",\%opts);

if ($opts{h}) {
  	PrintHelp();
  	exit 0;
}

if((!$opts{f}) || (!$opts{t}))
{
   	print "ERROR:  Invalid Options\n";
   	PrintHelp();
   	exit 0;
}

if ($opts{d}) {
	print "Generating DB Upgrade ONLY\n\n\n";
}

$CmdStr = "cleartool pwv";
if ($opts{v}) { print "Running $CmdStr \n"; }
$CmdRtn = `$CmdStr 2>&1`;
my $pwd = "";
if ($?)
{   
	$RtnVal = $CmdStr.' failed : '.$CmdRtn;
	undef($RtnVal);	
}
$CmdRtn =~ s/\n//; 
($pwd) = $CmdRtn =~ m/\:\s+(.*)Set\s+view\:(.*)/; 

#Get hostName
my $hostid = `hostname`;
chomp($hostid);
if ($hostid eq "atld-ivoscm01") {
	$pwd = "C:\\$pwd\\ucm_ivos\\";
}
else {
	$pwd = "C:\\ccstg_c\\$pwd\\ucm_ivos\\";
}

my $pwdir = `cd`;
chomp($pwdir);

my $frmBlName = $opts{f};
my $toBlName = $opts{t};

if (!$opts{d}) {
	# Gather and explod the war file from built location 
	# Added by Dani on 9/12/08
	# find the folder with the baseline name in the build location.
	# Copy to the program area in the ivos folder and explod it to ivos directory.
	if ($opts{v}) { print "\n\nSearching the build directory...Please wait, as this may take some time...\n"; }
	my $vos_bld_dir = "\\\\atli-fs01\\eSolutions_Builds\\iVos";
	my $BldWarBl = $toBlName;
	$BldWarBl =~ s/@\\ucm_pvob//;
	find( sub { /^$BldWarBl$/ && print TMPFILE "$File::Find::name" }, $vos_bld_dir);
	close(TMPFILE);
	open(TMPFILE, $TmpFile) || die("Could not open file!");
	my @upgfileInfo=<TMPFILE>;
	close(TMPFILE);
	if  (!$upgfileInfo[0]) {
		print "Build directory could not found!!!";
		exit;
	}
	$upgfileInfo[0] =~ tr/\//\\/;
	if ($opts{v}) { print "Found uild directory : $upgfileInfo[0]\n"; }
	
	$CmdStr = "rmdir /Q $pwdir\\ivos";
	if ($opts{v}) { print "Running $CmdStr \n"; }
	$CmdRtn = `$CmdStr 2>&1`;

	# Copy the ivos.war file from this location and explode
	$CmdStr = "xcopy $upgfileInfo[0]\\ivos.war $pwdir\\ivos\\* /Q /Y /I";
	if ($opts{v}) { print "Running $CmdStr \n"; }
	$CmdRtn = `$CmdStr 2>&1`;
	if ($?)
	{   
		$RtnVal = $CmdStr.' failed : '.$CmdRtn;
		undef($RtnVal);	
	}
	chdir "$pwdir\\ivos" || die "Cannot cd to $pwdir\\ivos";
	$CmdStr = "jar xvf $pwdir\\ivos\\ivos.war";
	if ($opts{v}) { print "Running $CmdStr \n"; }
	$CmdRtn = `$CmdStr 2>&1`;
	if ($?)
	{
	    $RtnVal = $CmdStr.' failed : '.$CmdRtn;
	    undef($RtnVal);	
	}
}
# Change directory back to the program direcotry
chdir $pwdir || die "Cannot cd to $pwdir";

#$toBlName .= '@\ucm_pvob';
$CmdStr = "cleartool diffbl -activities $frmBlName $toBlName";
if ($opts{v}) { print "Running $CmdStr \n"; }
$CmdRtn = `$CmdStr 2>&1`;
if ($opts{v}) { print "$CmdStr returned \n $CmdRtn \n"; }
if ($?)
{
    $RtnVal = $CmdStr.' failed : '.$CmdRtn;
    undef($RtnVal);	
}
else
{ 
	$BldHash{'deldActs'} = $CmdRtn;		
} # end find project

my @lnSplitActs = split(/\n/,$BldHash{'deldActs'});
my @arrBaseActs = ();
my @arrTmpAct = ();
my @activities = ();
my $acts = "";
foreach my $tmpVar (@lnSplitActs) {
	
	# print "$tmpVar\n";
	
	if ($tmpVar =~ /deliver|rebase/) {
	#	print "contains deliver/rebase\n\n";
			
	}
	else {
		@arrBaseActs = ();
		@arrTmpAct = ();
		@arrBaseActs = split(/@/,$tmpVar);		
		@arrTmpAct = split(/\s/,$arrBaseActs[0]);
		push(@activities,$arrTmpAct[1]);
	}
}


my $cnt = 1;
@arrTmpAct = ();
my @arrTmp = ();
my %actHash = ();
my $str = "";
my $cqQry = "'";
foreach $acts(@activities){
	if ($acts) {
		$cqQry .= "$acts','";
	}
	$cnt++;
	@arrTmpAct = "";	
	$acts = $acts . '@\ucm_pvob';
	$CmdStr = "cleartool lsact -fmt %[versions]p $acts";
	if ($opts{v}) { print "Running $CmdStr \n"; }
	$CmdRtn = `$CmdStr 2>&1`;
	if ($opts{v}) { print "$CmdStr returned \n $CmdRtn \n"; }
	
	if ($?)
	{
	    $RtnVal = $CmdStr.' failed : '.$CmdRtn;
	    undef($RtnVal);	
	}
	else
	{ 
		@arrTmpAct = split(/\s/,$CmdRtn);
	
		foreach (@arrTmpAct) {
			push(@{$actHash{$acts}}, $_);
		}	
	} 
}
(my $TrimCqQry) = $cqQry =~ m/(.*)\,\'$/;


# Added by Dani on 04/15/2009 for retrieving all the WIs delivered
# ---------------------------------------------------
# CQ Report for all non - DB change
$sqlQuery = "select \
			distinct \
			T1.dbid \ 
			,T1.id \
			,T16.id \
			,T22.name \
			,T1.headline_3 \
			,T1.db_change \
			,T3.name \
			,T1.resolve_date  \
			,T16.CoreCustom \
		from  \
			task T1 \
			,statedef T3 \
			,statedef T22 \
			,Defect T16 \
			,parent_child_links T16mm \
		where  \
		    T1.state = T3.id  \
		    and T1.dbid = T16mm.child_dbid  \
		    and T16.State = T22.id  \
		    and 16779475 = T16mm.child_fielddef_id   \
		    and T16mm.parent_dbid = T16.dbid   \
		    and (T1.dbid <> 0 and ((T1.id IN ($TrimCqQry))))  \
		ORDER BY T1.id";
		

if ($opts{v}) {
	print "\n\n$sqlQuery\n\n";
	print "\n---------------------------------------------------------------------------------------------------------------\n";
}
$resultSet = $CQSession->BuildSQLQuery($sqlQuery);
$resultSet->Execute();
$cnt = 1;
print  CQRPTFILE "\n\tAll WIs delivered between '$frmBlName' and '$toBlName' \n";
print  CQRPTFILE "\t*********************************************************************************************************************************\n\n";
		
print(CQRPTFILE pack("A15", "WI ID"));
print(CQRPTFILE pack("A15", "CR ID"));
print(CQRPTFILE pack("A10", "CR State"));
print(CQRPTFILE pack("A12", "Core/Custom"));
print(CQRPTFILE pack("A80", "Headline"));
print(CQRPTFILE pack("A5", "DB?"));
print(CQRPTFILE pack("A10", "WI State"));
print(CQRPTFILE pack("A10", "Resolved Date"));
print  CQRPTFILE "\n-----------------------------------------------------------------------------------------------------------------------------------------------------------\n";

my @dbUpgWIs = ();
my $DBWIID = "";
while($resultSet->MoveNext() == $CQPerlExt::CQ_SUCCESS)
{
	if ($resultSet->GetColumnValue(2)) { 
		print(CQRPTFILE pack("A15", $resultSet->GetColumnValue(2)));
		($DBWIID) = $resultSet->GetColumnValue(2) =~ m/VOSDF(.*)/;
		$DBWIID =~ s/^0*//;
		push(@dbUpgWIs,$DBWIID);
	}

	# if ($resultSet->GetColumnValue(2)) { print(CQRPTFILE pack("A15", $resultSet->GetColumnValue(2)));}
	# else {print(CQRPTFILE pack("A15", ""));}
	
	if ($resultSet->GetColumnValue(3)) { print(CQRPTFILE pack("A15", $resultSet->GetColumnValue(3)));}
	else {print(CQRPTFILE pack("A15", ""));}
	if ($resultSet->GetColumnValue(4)) { print(CQRPTFILE pack("A10", $resultSet->GetColumnValue(4)));}
	else {print(CQRPTFILE pack("A10", ""));}

	# Core/Custom Addition
	if ($resultSet->GetColumnValue(9)) { print(CQRPTFILE pack("A12", $resultSet->GetColumnValue(9)));}
	else {print(CQRPTFILE pack("A12", ""));}	

	if ($resultSet->GetColumnValue(5)) { print(CQRPTFILE pack("A80", $resultSet->GetColumnValue(5)));}
	else {print(CQRPTFILE pack("A80", ""));}
	if ($resultSet->GetColumnValue(6)) { print(CQRPTFILE pack("A5", $resultSet->GetColumnValue(6)));}
	else {print(CQRPTFILE pack("A5", ""));}			
	if ($resultSet->GetColumnValue(7)) { print(CQRPTFILE pack("A10", $resultSet->GetColumnValue(7)));}
	else {print(CQRPTFILE pack("A10", ""));}			
	if ($resultSet->GetColumnValue(8)) { print(CQRPTFILE pack("A10", $resultSet->GetColumnValue(8)));}
	else {print(CQRPTFILE pack("A10", ""));}			
	print(CQRPTFILE "\n");		
}
print  CQRPTFILE "\n-----------------------------------------------------------------------------------------------------------------------------------------------------------\n";
print CQRPTFILE "\n*****************************************************************************************************\n";
print CQRPTFILE "*****************************************************************************************************\n\n";



# ---------------------------------------------------
# CQ Report for all non - DB change
$sqlQuery = "select distinct T1.dbid,T1.id,T16.id,T22.name,T33.Company,T1.headline_3,T1.db_change,T3.name,T1.resolve_date,T16.CoreCustom from \
		task T1,statedef T3, statedef T22, Defect T16,parent_child_links T16mm,Customer T33,parent_child_links T33mm where \
	       	T1.state = T3.id and T1.dbid = T16mm.child_dbid and T16.State = T22.id \
		and 16779475 = T16mm.child_fielddef_id  (+)  and T16mm.parent_dbid = T16.dbid  (+)  and T16.dbid = T33mm.parent_dbid  \
		and 16777880 = T33mm.parent_fielddef_id  (+)  and T33mm.child_dbid = T33.dbid  (+)  and (T1.dbid <> 0 and \
		((T1.id IN ($TrimCqQry)))) ORDER BY T33.Company";

if ($opts{v}) {
	print "\n\n$sqlQuery\n\n";
	print "\n---------------------------------------------------------------------------------------------------------------\n";
}
$resultSet = $CQSession->BuildSQLQuery($sqlQuery);
$resultSet->Execute();
$cnt = 1;
print  CQRPTFILE "\n\t\t\tClearQuest Report  - All WIs by Customer\n";
print  CQRPTFILE "\t\t\t**************************************************************************\n\n";
		
print(CQRPTFILE pack("A15", "WI ID"));
print(CQRPTFILE pack("A15", "CR ID"));
print(CQRPTFILE pack("A10", "CR State"));
print(CQRPTFILE pack("A12", "Core/Custom"));
print(CQRPTFILE pack("A30", "Customer Name"));		
print(CQRPTFILE pack("A80", "Headline"));
print(CQRPTFILE pack("A5", "DB?"));
print(CQRPTFILE pack("A10", "WI State"));
print(CQRPTFILE pack("A10", "Resolved Date"));
print  CQRPTFILE "\n-----------------------------------------------------------------------------------------------------------------------------------------------------------\n";

# my @dbUpgWIs = ();
# my $DBWIID = "";
while($resultSet->MoveNext() == $CQPerlExt::CQ_SUCCESS)
{
	if ($resultSet->GetColumnValue(2)) { 
		print(CQRPTFILE pack("A15", $resultSet->GetColumnValue(2)));
	}

	# if ($resultSet->GetColumnValue(2)) { print(CQRPTFILE pack("A15", $resultSet->GetColumnValue(2)));}
	# else {print(CQRPTFILE pack("A15", ""));}
	
	if ($resultSet->GetColumnValue(3)) { print(CQRPTFILE pack("A15", $resultSet->GetColumnValue(3)));}
	else {print(CQRPTFILE pack("A15", ""));}
	if ($resultSet->GetColumnValue(4)) { print(CQRPTFILE pack("A10", $resultSet->GetColumnValue(4)));}
	else {print(CQRPTFILE pack("A10", ""));}

	# core/Custom
	if ($resultSet->GetColumnValue(10)) { print(CQRPTFILE pack("A12", $resultSet->GetColumnValue(10)));}
	else {print(CQRPTFILE pack("A12", ""));}			

	if ($resultSet->GetColumnValue(5)) { print(CQRPTFILE pack("A30", $resultSet->GetColumnValue(5)));}
	else {print(CQRPTFILE pack("A30", ""));}
	
	if ($resultSet->GetColumnValue(6)) { print(CQRPTFILE pack("A80", $resultSet->GetColumnValue(6)));}
	else {print(CQRPTFILE pack("A80", ""));}			
	if ($resultSet->GetColumnValue(7)) { print(CQRPTFILE pack("A5", $resultSet->GetColumnValue(7)));}
	else {print(CQRPTFILE pack("A5", ""));}			
	if ($resultSet->GetColumnValue(8)) { print(CQRPTFILE pack("A10", $resultSet->GetColumnValue(8)));}
	else {print(CQRPTFILE pack("A10", ""));}			
	if ($resultSet->GetColumnValue(9)) { print(CQRPTFILE pack("A10", $resultSet->GetColumnValue(9)));}
	else {print(CQRPTFILE pack("A10", ""));}			
	print(CQRPTFILE "\n");		
}
print  CQRPTFILE "\n-----------------------------------------------------------------------------------------------------------------------------------------------------------\n";


# Addition on Core/Custom date
print CQRPTFILE "\n*****************************************************************************************************\n\n";
print CQRPTFILE ("CR List : $TrimCqQry");
print CQRPTFILE "\n\n*****************************************************************************************************\n";
print CQRPTFILE "\n*****************************************************************************************************\n\n";

# Addition of new Report:
# FOR QA - List all the CRs (above report) and also shows if any QA WIs not in CANCELLED STATE



my $upgFileLst = "";
my @fileLst = ();
my $fullFile = "";
my @arrDbPrgUpg = "";
my $ChDbfile= "";
my $Chfile = "";
foreach my $group (keys %actHash) {
    print FILE "The change set for the ClearQuest work item '$group' are, \n";
    foreach my $fullFile (@{$actHash{$group}}) {
	    print FILE "\t$fullFile\n";

	    # DB Upgrade
	    if (($fullFile =~ /\\oracle\\/) or (($fullFile =~ /\\mssql\\/)))
	    {
		    	$ChDbfile = "";
		        ($ChDbfile) = $fullFile =~ m{\\([\w.\w]*)\@\@};
			push(@arrDbPrgUpg,$ChDbfile);
	    }
            
	    # iVos Upgrade
	    $Chfile = "";
	    ( $Chfile ) = $fullFile =~ m{\\([\w.\w]*)\@\@};

	    # if we need the full file path name here is it.
	    $fullFile =~ s/\@\@.*//s;
	    $fullFile =~ s/^\Q$pwd\E//;
	    if ($fullFile =~ /\./) {
	           	$fullFile =~ s/.java/.class/;
			$fullFile =~ s/\\src\\/\\WEB-INF\\classes\\/;
			$fullFile =~ s/\\rules\\/\\WEB-INF\\classes\\/;
		        $upgFileLst .= "$fullFile\n";
		        push(@fileLst,$fullFile);
	    }
    }	
}
print FILE"-------------------------------------------------------------------------------------\n\n";

print FILE "DB Program upgrade change set\n";
print FILE "-------------------------------------------------\n";
foreach (@arrDbPrgUpg) {
	print FILE $_ . "\n";
}
# ----------------------------------------------------
my $dbUpgradeFileList = "DB Upgrade - Schema change\n";

# Commented by Dani on 11/13/2008
# $sqlQuery = "select distinct T1.dbid,T1.id,T16.id,T33.Company,T1.headline_3,T1.db_change,T3.name,T1.resolve_date from task T1,statedef T3, \
#	Defect T16,parent_child_links T16mm,Customer T33,parent_child_links T33mm where T1.state = T3.id and T1.dbid = T16mm.child_dbid \
#	and 16779475 = T16mm.child_fielddef_id  (+)  and T16mm.parent_dbid = T16.dbid  (+)  and T16.dbid = T33mm.parent_dbid  \
#	and 16777880 = T33mm.parent_fielddef_id  (+)  and T33mm.child_dbid = T33.dbid  (+)  and (T1.dbid <> 0 and \
#	((T1.id IN ($TrimCqQry)))) and T1.db_change = 'Yes' ORDER BY T33.Company";
#
# if ($opts{v}) {
#	print "\n\n$sqlQuery\n\n";
#	print "\n------------------------------------------------------------\n";
# }
# $resultSet = $CQSession->BuildSQLQuery($sqlQuery);
# $resultSet->Execute();
# end of comment - 11/13/2008

$cnt = 1;
print  CQRPTFILE "\n\t\t\tClearQuest Report  - DB Change WIs delivered to ClearCase\n";
print  CQRPTFILE "\t\t\t**************************************************************************\n\n";

print(CQRPTFILE pack("A15", "WI ID"));
print(CQRPTFILE pack("A15", "CR ID"));
print(CQRPTFILE pack("A30", "Customer Name"));		
print(CQRPTFILE pack("A80", "Headline"));
print(CQRPTFILE pack("A5", "DB?"));
print(CQRPTFILE pack("A10", "State"));
$sqlQuery = "select distinct T1.dbid,T1.id,T16.id,T22.name,T33.Company,T1.headline_3,T1.db_change,T3.name,T1.resolve_date from \
	task T1,statedef T3, statedef T22, Defect T16,parent_child_links T16mm,Customer T33,parent_child_links T33mm where \
       	T1.state = T3.id and T1.dbid = T16mm.child_dbid and T16.State = T22.id \
	and 16779475 = T16mm.child_fielddef_id  (+)  and T16mm.parent_dbid = T16.dbid  (+)  and T16.dbid = T33mm.parent_dbid  \
	and 16777880 = T33mm.parent_fielddef_id  (+)  and T33mm.child_dbid = T33.dbid  (+)  and (T1.dbid <> 0 and \
	((T1.id IN ($TrimCqQry)))) and T1.db_change = 'Yes' ORDER BY T33.Company";
		
if ($opts{v}) {
	print "\n\n$sqlQuery\n\n";
	print "\n------------------------------------------------------------\n";
}
$resultSet = $CQSession->BuildSQLQuery($sqlQuery);
$resultSet->Execute();
$cnt = 1;
print  CQRPTFILE "\n\t\t\tClearQuest Report  - DB Change WIs delivered to ClearCase\n";
print  CQRPTFILE "\t\t\t**************************************************************************\n\n";
	
print(CQRPTFILE pack("A15", "WI ID"));
print(CQRPTFILE pack("A15", "CR ID"));
print(CQRPTFILE pack("A10", "CR State"));
print(CQRPTFILE pack("A30", "Customer Name"));		
print(CQRPTFILE pack("A80", "Headline"));
print(CQRPTFILE pack("A5", "DB?"));
print(CQRPTFILE pack("A10", "WI State"));
print(CQRPTFILE pack("A10", "Resolved Date"));		
print  CQRPTFILE "\n-----------------------------------------------------------------------------------------------------------------------------------------------------------\n";

# commented on 11/13 by Dani
# my @dbUpgWIs = ();
# my $DBWIID = "";
while($resultSet->MoveNext() == $CQPerlExt::CQ_SUCCESS)
{

	if ($resultSet->GetColumnValue(2)) { print(CQRPTFILE pack("A15", $resultSet->GetColumnValue(2)));}
	else {print(CQRPTFILE pack("A15", ""));}
	if ($resultSet->GetColumnValue(3)) { print(CQRPTFILE pack("A15", $resultSet->GetColumnValue(3)));}
	else {print(CQRPTFILE pack("A15", ""));}
	if ($resultSet->GetColumnValue(4)) { print(CQRPTFILE pack("A10", $resultSet->GetColumnValue(4)));}
	else {print(CQRPTFILE pack("A10", ""));}
	if ($resultSet->GetColumnValue(5)) { print(CQRPTFILE pack("A30", $resultSet->GetColumnValue(5)));}
	else {print(CQRPTFILE pack("A30", ""));}
	if ($resultSet->GetColumnValue(6)) { print(CQRPTFILE pack("A80", $resultSet->GetColumnValue(6)));}
	else {print(CQRPTFILE pack("A80", ""));}			
	if ($resultSet->GetColumnValue(7)) { print(CQRPTFILE pack("A5", $resultSet->GetColumnValue(7)));}
	else {print(CQRPTFILE pack("A5", ""));}			
	if ($resultSet->GetColumnValue(8)) { print(CQRPTFILE pack("A10", $resultSet->GetColumnValue(8)));}
	else {print(CQRPTFILE pack("A10", ""));}
	if ($resultSet->GetColumnValue(9)) { print(CQRPTFILE pack("A10", $resultSet->GetColumnValue(9)));}
	else {print(CQRPTFILE pack("A10", ""));}
	
	print(CQRPTFILE "\n");		
}
print  CQRPTFILE "\n-----------------------------------------------------------------------------------------------------------------------------------------------------------\n";
print CQRPTFILE "\n\n*****************************************************************************************************\n";
print CQRPTFILE "\n*****************************************************************************************************\n\n";




	# Generate iVos upgrade - accurate path - added by Dani on 9/20
	# Method:
	#  lsh since the from baseline on integration view, scan through the result and generate upgrade element list
	#  	- Create an temporary integration dynamic view
	#  	- do an lsh from the from baseline
	#  	- Generate the change list (GCList)
	#  	- Remove temporary view

	# Get the info of two baseline - 9/22/08
	my %months = (	Jan => '1',
		       	Feb => '2',
		       	Mar => '3',
		       	Apr => '4',
		       	May => '5',
			Jun => '6',
			Jul => '7',
			Aug => '8',
			Sep => '9',
			Oct => '10',
			Nov => '11',
			Dec => '12'
		);
	

	
	my @newArr = ();
	my $flname ="";
	$CmdStr = "cleartool lsbl baseline:$frmBlName";
	if ($opts{v}) { print "Running $CmdStr \n"; }
	$CmdRtn = `$CmdStr 2>&1`;
	if ($?)
	{   
		$RtnVal = $CmdStr.' failed : '.$CmdRtn;
		undef($RtnVal);	
	}
	my @tmpArr = split(/\s+/,$CmdRtn);

	if ($opts{v}) {
		print "Baseline creation date time : " . $tmpArr[0] . "\n"; # - datetime
		print "Baseline Name" . $tmpArr[1] . "\n"; # - baseline
		print "Baseline stream name" . $tmpArr[5] . "\n"; # - stream
	}
	my $frmBlDtTime = $tmpArr[0];
	$frmBlDtTime =~ m/(.*)\-(.*)\-(.*)T(.*)\:(.*)\:(.*)/;
	# my $frmBlyr = "20".$3;
	# $frmBlDtTime = "$frmBlyr $months{$2} $1 $4 $5 $6";
	$frmBlDtTime = "$1 $2 $3 $4 $5 $6";





# $vos_dbbld_view - can create this temp if the following directory is not shared
my $vos_dbbld_view = "\\\\atld-ivosbuild\\dbstore\\dev42";


open (TMPFILE, ">$TmpFile") || die "Can't open $TmpFile: $!\n";
$DBWIID = "";
foreach $DBWIID (@dbUpgWIs) {
	find( sub { /$DBWIID/ && print TMPFILE "$File::Find::name\n" }, $vos_dbbld_view)
}
close(TMPFILE);
my @upgfileInfo = ();
open(TMPFILE, $TmpFile) || die("Could not open file!");
@upgfileInfo=<TMPFILE>;

close(TMPFILE);
my @prgDBUpgIDs = ();
my $dbUpgFrm = $frmBlName;
$dbUpgFrm =~ s/@\\ucm_pvob//;
my $dbUpgTo = $toBlName;
$dbUpgTo =~ s/@\\ucm_pvob//;

my $flModDttm = "";
my $frMddtmyr = "";

foreach $DBWIID (@upgfileInfo) {
	if  (!$DBWIID) {
		print "Schema DB upgrade script could not found for WI - $DBWIID.\nPossible program DB upgrade script";
		$DBWIID = $DBWIID . "@\\ucm_pvob";
		push(@prgDBUpgIDs,$DBWIID);
	}
	else {
		chomp($DBWIID);
		$DBWIID =~ tr/\//\\/;
	
		# Added by Dani on Oct 3rd.
		# verify the source file's modified date time is greater than or equal to source baseline's date time
		my $flModDttm = get_mtime($DBWIID);
		$flModDttm =~ m/(.*)\-(.*)\-(.*)T(.*)\.(.*)\.(.*)/;
		$flModDttm = "$3 $1 $2 $4 $5 $6";

		# print "Baseline date : $frmBlDtTime and file modified date time of file ($DBWIID) is : $flModDttm\n";
		# $result = compareDate($frmBlDtTime,$flModDttm);
		# if ($result eq  "1") {
			# print 	"DB Upgrade candidate ($frmBlDtTime > $flModDttm) \n";
			
			$dbUpgradeFileList .= $DBWIID . "\n";

			if ($DBWIID =~ m/_sql/) {
				$CmdStr = "xcopy $DBWIID $pwdir\\DBUpg_" . $dbUpgFrm . "_to_" . $dbUpgTo . "\\SQL\\Schema\\* /Q /Y /I";
				$DBWIID =~ tr/\//\\/;
				print SQLDBUPGFILE "$DBWIID\n";
			}	
			elsif ($DBWIID =~ m/_ora/) {
				$CmdStr = "xcopy $DBWIID $pwdir\\DBUpg_" . $dbUpgFrm . "_to_" . $dbUpgTo . "\\ORA\\Schema\\* /Q /Y /I";
				$DBWIID =~ tr/\//\\/;
				print ORADBUPGFILE "$DBWIID\n";
			}
			if ($opts{v}) { print "Running $CmdStr \n"; }
			$CmdRtn = `$CmdStr 2>&1`;
			if ($?)
			{   
				$RtnVal = $CmdStr.' failed : '.$CmdRtn;
				undef($RtnVal);	
			}
		# }
		# else {
		#		print 	"Skip - old db change....($frmBlDtTime < $flModDttm)\n";
		# }

	}	
}

 		


	$tmpArr[0] =~ s/:/_/g;

	my $tmpviewName = $tmpArr[0] . "_" . $tmpArr[2] . "_tmp_view";
	my $viewPath = "\\\\atld-ivoscc01\\clearcase\\views\\$tmpviewName";
	my $StreamName = $tmpviewName . "_Int";
	$CmdStr  = "cleartool mkview -tag $tmpviewName -stream $tmpArr[5] $viewPath 2>&1";
	if ($opts{v}) { print "Running $CmdStr \n"; }
	$CmdRtn = `$CmdStr 2>&1`;
	if ($?)
	{   
		$RtnVal = $CmdStr.' failed : '.$CmdRtn;
		undef($RtnVal);	
	}


	
	
	$CmdStr = "cleartool lsbl baseline:$toBlName";
	if ($opts{v}) { print "Running $CmdStr \n"; }
	$CmdRtn = `$CmdStr 2>&1`;
	if ($?)
	{   
		$RtnVal = $CmdStr.' failed : '.$CmdRtn;
		undef($RtnVal);	
	}
	my @totmpArr = split(/\s+/,$CmdRtn);
	my $toDtTime = $totmpArr[0];
	$toDtTime =~ m/(.*)\-(.*)\-(.*)T(.*)\:(.*)\:(.*)/;
	# my $ToBlyr = "20".$3;
	# my $strToDt = "$ToBlyr $months{$2} $1 $4 $5 $6";
	my $strToDt = "$1 $2 $3 $4 $5 $6";
	if ($opts{v}) {
		print "Baseline creation date time : " . $totmpArr[0] . "\n"; # - datetime
	}
	$tmpArr[0] =~ s/_/:/g;
	$totmpArr[5] =~ s/@\\ucm_pvob//;



# Copy any of DB script that are not attached to a stream but had a DB change for this stream
# Added by Dani on 9/23
my @arrdt = ();
my $frmDte = "";
(@arrdt) = $tmpArr[0] =~ m/(\d\d)-(.*)-(\d\d)\.(\d\d)\:(\d\d):(\d\d)/;
$arrdt[1] = sprintf("%02d", $months{$arrdt[1]});
$frmDte = "20".$arrdt[2] . "-" . $arrdt[1] . "-" . $arrdt[0] . " " . $arrdt[3] . ":" .   $arrdt[4] . ":00:0000";
@arrdt = ();

my $toDte = "";
(@arrdt) = $totmpArr[0] =~ m/(\d\d)-(.*)-(\d\d)\.(\d\d)\:(\d\d):(\d\d)/;
$arrdt[1] = sprintf("%02d", $months{$arrdt[1]});
$toDte = "20".$arrdt[2] . "-" . $arrdt[1] . "-" . $arrdt[0] . " " . $arrdt[3] . ":" .   $arrdt[4] . ":00:0000";
@arrdt = ();

$sqlQuery = "select distinct T1.dbid,T1.id,T1.headline_3 from task T1,enttable T2 where T1.fldcolumn_1 = T2.dbid \
		and (T1.dbid <> 0 and ((T2.functionname = '1-Development' and T1.db_change = 'Yes' \
		and T1.resolve_date between {ts '$frmDte'} and  {ts '$toDte'} and T1.ucm_stream is NULL)))";

if ($opts{v}) {
	print "\n\n$sqlQuery\n\n";
	print "\n------------------------------------------------------------\n";
}
$resultSet = $CQSession->BuildSQLQuery($sqlQuery);
$resultSet->Execute();
$cnt = 1;

# Added by Dani on 4/1/2009
# print(CQRPTFILE pack("A17", "ID"));
#print(CQRPTFILE pack("A80", "Headline"));		
#print  CQRPTFILE "\n-----------------------------------------------------------------------------------------------------------------------------------------------------------\n";
#End of comment 4/1/2009


# print "$totmpArr[5] \n";
# (my @nums) = $totmpArr[5] =~ m/\d/g;

# added by Dani on 11/14
my @nums = ();
my $cbVer = "";

if ($totmpArr[5] =~ m/cb/i) {
	$cbVer =$totmpArr[5];
	$cbVer =~ s/\.//g;
	@nums = $cbVer =~ m/(\d)([\w]+)/g;
}
else {
	@nums = $totmpArr[5] =~ m/\d/g;
}
# end of addition 11/14


my $ptrn1 = "";
my $ptn2 = "";
foreach (@nums){
	$ptrn1 .= $_;
	$ptn2 .= $_ . ".";
}

# Added by Dani on 4/1/2009
if ($ptrn1 =~ m/0$/) {
	$ptrn1 =~ m/(.*)0$/;
	$ptrn1 = $1;
}
if ($ptn2 =~ m/0\.$/) {
	$ptn2 =~ m/(.*)0\.$/;
	if ($1) {
		$ptn2 = $1;
	}
}
# end of addition 4/1/2009

(my $ptrn2) = $ptn2 =~ m/(.*)\.$/;

# Added by Dani on 4/1/2009 - commented the below part
# if ($totmpArr[5] =~ m/CB/) {
#	$ptrn1 .= "CB";
#	$ptrn2 .= "CB";
# }
# # end of addition 4/1/2009

my $ptrn3 = $ptrn2 . "x";

# Added by Dani on 4/1/2009
my $ptrn4 = $ptrn2 . ".x";
# end of addition 4/1/2009

my $ptrn5 = $ptrn1 . "x";

# Added by Dani on 4/1/2009
my $ptrn6 = "Dev - " . $ptrn1;
my $ptrn7 = "Dev - " . $ptrn2;
my $ptrn8 = "Dev - " . $ptrn3;
my $ptrn9 = "Dev- " . $ptrn1;
my $ptrn10 = "Dev- " . $ptrn2;
my $ptrn11 = "Dev- " . $ptrn3;
my $ptrn12 = "Dev -" . $ptrn1;
my $ptrn13 = "Dev -" . $ptrn2;
my $ptrn14 = "Dev -" . $ptrn3;
# end of addition 4/1/2009

@dbUpgWIs = ();
$DBWIID = "";

# Added on 4/1/2009 by Dani
my $dbnonstreamWIs = "'";

while($resultSet->MoveNext() == $CQPerlExt::CQ_SUCCESS)
{
	if ($resultSet->GetColumnValue(2)) { 
		if ($opts{v}) { print(pack("A17", $resultSet->GetColumnValue(2))); }
	}
	else {
		if ($opts{v}) { 
				print(pack("A17", ""));
		}
	}

	if ($resultSet->GetColumnValue(3)) { 
		if ($opts{v}) { print( pack("A80", $resultSet->GetColumnValue(3))); }

		# Added by Dani on 4/1/2009	
		if ($resultSet->GetColumnValue(3) =~ m/$ptrn1-|$ptrn2-|$ptrn3-|$ptrn4-|$ptrn5-|$ptrn1 -|$ptrn2 -|$ptrn3 -|$ptrn4 -|$ptrn5 -|$ptrn1- |$ptrn2- |$ptrn3- |$ptrn4- |$ptrn5- |$ptrn1 - |$ptrn2 - |$ptrn3 - |$ptrn4 - |$ptrn5 - |$ptrn6|$ptrn7|$ptrn8|$ptrn9|$ptrn10|$ptrn11|$ptrn12|$ptrn13|$ptrn14/i){
			if ($opts{v}) { 
				print "   (Pattern matched! - $ptrn1-|$ptrn2-|$ptrn3-|$ptrn4-|$ptrn5-|$ptrn1 -|$ptrn2 -|$ptrn3 -|$ptrn4 -|$ptrn5 -|$ptrn1- |$ptrn2- |$ptrn3- |$ptrn4- |$ptrn5- |$ptrn1 - |$ptrn2 - |$ptrn3 - |$ptrn4 - |$ptrn5 - |$ptrn6|$ptrn7|$ptrn8|$ptrn9|$ptrn10|$ptrn11|$ptrn12|$ptrn13|$ptrn14  - not a db upgrade candidate !)";
			}
			$dbnonstreamWIs .= $resultSet->GetColumnValue(2) . "','";

			($DBWIID) = $resultSet->GetColumnValue(2) =~ m/VOSDF(.*)/;
			$DBWIID =~ s/^0*//;
			push(@dbUpgWIs,$DBWIID);
		}
		else {
			if ($opts{v}) { 
				print  "   (! Not matched with any pattern - $ptrn1-|$ptrn2-|$ptrn3-|$ptrn4-|$ptrn5-|$ptrn1 -|$ptrn2 -|$ptrn3 -|$ptrn4 -|$ptrn5 -|$ptrn1- |$ptrn2- |$ptrn3- |$ptrn4- |$ptrn5- |$ptrn1 - |$ptrn2 - |$ptrn3 - |$ptrn4 - |$ptrn5 - |$ptrn6|$ptrn7|$ptrn8|$ptrn9|$ptrn10|$ptrn11|$ptrn12|$ptrn13|$ptrn14  - not a db upgrade candidate !)";
			}
		}
		# end of addition 4/1/2009
	}
}

if ($opts{v}) {print "\n" . $dbnonstreamWIs . "\n";}

$TrimCqQry = "";
($TrimCqQry) = $dbnonstreamWIs =~ m/(.*)\,\'$/;

if ($TrimCqQry) {
	
	print  CQRPTFILE "\n\n\n\t\t\tClearQuest Report  - DB Change WIs and no ClearCase stream attached\n";
	print  CQRPTFILE "\t\t\t**************************************************************************\n\n";


	$sqlQuery = "select distinct T1.dbid,T1.id,T16.id,T22.name,T33.Company,T1.headline_3,T1.db_change,T3.name,T1.resolve_date from \
		task T1,statedef T3, statedef T22, Defect T16,parent_child_links T16mm,Customer T33,parent_child_links T33mm where \
	       	T1.state = T3.id and T1.dbid = T16mm.child_dbid and T16.State = T22.id \
		and 16779475 = T16mm.child_fielddef_id  (+)  and T16mm.parent_dbid = T16.dbid  (+)  and T16.dbid = T33mm.parent_dbid  \
		and 16777880 = T33mm.parent_fielddef_id  (+)  and T33mm.child_dbid = T33.dbid  (+)  and (T1.dbid <> 0 and \
		((T1.id IN ($TrimCqQry)))) and T1.db_change = 'Yes' ORDER BY T33.Company";
		
	if ($opts{v}) {
		print "\nDB Change WIs and no ClearCase stream attached\n\n$sqlQuery\n\n";
		print "\n------------------------------------------------------------\n";
	}
	$resultSet = $CQSession->BuildSQLQuery($sqlQuery);
	$resultSet->Execute();
	$cnt = 1;
	print  CQRPTFILE "\n\t\t\tClearQuest Report  - DB Change WIs delivered to ClearCase\n";
	print  CQRPTFILE "\t\t\t**************************************************************************\n\n";
	
	print(CQRPTFILE pack("A15", "WI ID"));
	print(CQRPTFILE pack("A15", "CR ID"));
	print(CQRPTFILE pack("A10", "CR State"));
	print(CQRPTFILE pack("A30", "Customer Name"));		
	print(CQRPTFILE pack("A80", "Headline"));
	print(CQRPTFILE pack("A5", "DB?"));
	print(CQRPTFILE pack("A10", "WI State"));
	print(CQRPTFILE pack("A10", "Resolved Date"));		
	print  CQRPTFILE "\n-----------------------------------------------------------------------------------------------------------------------------------------------------------\n";

	# commented on 11/13 by Dani
	# my @dbUpgWIs = ();
	# my $DBWIID = "";
	while($resultSet->MoveNext() == $CQPerlExt::CQ_SUCCESS)
	{
		
		if ($resultSet->GetColumnValue(2)) { print(CQRPTFILE pack("A15", $resultSet->GetColumnValue(2)));}
		else {print(CQRPTFILE pack("A15", ""));}
		if ($resultSet->GetColumnValue(3)) { print(CQRPTFILE pack("A15", $resultSet->GetColumnValue(3)));}
		else {print(CQRPTFILE pack("A15", ""));}
		if ($resultSet->GetColumnValue(4)) { print(CQRPTFILE pack("A10", $resultSet->GetColumnValue(4)));}
		else {print(CQRPTFILE pack("A10", ""));}
		if ($resultSet->GetColumnValue(5)) { print(CQRPTFILE pack("A30", $resultSet->GetColumnValue(5)));}
		else {print(CQRPTFILE pack("A30", ""));}
		if ($resultSet->GetColumnValue(6)) { print(CQRPTFILE pack("A80", $resultSet->GetColumnValue(6)));}
		else {print(CQRPTFILE pack("A80", ""));}			
		if ($resultSet->GetColumnValue(7)) { print(CQRPTFILE pack("A5", $resultSet->GetColumnValue(7)));}
		else {print(CQRPTFILE pack("A5", ""));}			
		if ($resultSet->GetColumnValue(8)) { print(CQRPTFILE pack("A10", $resultSet->GetColumnValue(8)));}
		else {print(CQRPTFILE pack("A10", ""));}
		if ($resultSet->GetColumnValue(9)) { print(CQRPTFILE pack("A10", $resultSet->GetColumnValue(9)));}
		else {print(CQRPTFILE pack("A10", ""));}
	
		print(CQRPTFILE "\n");		
	}
	print  CQRPTFILE "\n-----------------------------------------------------------------------------------------------------------------------------------------------------------\n";
	print CQRPTFILE "\n\n*****************************************************************************************************\n";
	print CQRPTFILE "\n*****************************************************************************************************\n\n";
}


# $vos_dbbld_view - can create this temp if the following directory is not shared
# $vos_dbbld_view = "\\\\cbuild1\\scm_view_dbstore\\dbstore\\dev42";
$vos_dbbld_view = "\\\\atld-ivosbuild\\dbstore\\dev42";

open (TMPFILE, ">$TmpFile") || die "Can't open $TmpFile: $!\n";
$DBWIID = "";
foreach $DBWIID (@dbUpgWIs) {
	find( sub { /$DBWIID/ && print TMPFILE "$File::Find::name\n" }, $vos_dbbld_view);
}
close(TMPFILE);
@upgfileInfo = ();
open(TMPFILE, $TmpFile) || die("Could not open file!");
@upgfileInfo=<TMPFILE>;
close(TMPFILE);

@prgDBUpgIDs = ();
$dbUpgFrm = $frmBlName;
$dbUpgFrm =~ s/@\\ucm_pvob//;
$dbUpgTo = $toBlName;
$dbUpgTo =~ s/@\\ucm_pvob//;



foreach $DBWIID (@upgfileInfo) {
	if  (!$DBWIID) {
		print "Schema DB upgrade script could not found for WI - $DBWIID.\nPossible program DB upgrade script";
		$DBWIID = $DBWIID . "@\\ucm_pvob";
		push(@prgDBUpgIDs,$DBWIID);
	}
	else {
		chomp($DBWIID);
		$DBWIID =~ tr/\//\\/;
		
		# Added by Dani on Oct 3rd.
		# verify the source file's modified date time is greater than or equal to source baseline's date time
		my $flModDttm = get_mtime($DBWIID);
		$flModDttm =~ m/(.*)\-(.*)\-(.*)\.(.*)\.(.*)\.(.*)/;
		$flModDttm = "$3 $1 $2 $4 $5 $6";

		# print "Baseline date : $frmBlDtTime and file modified date time of file ($DBWIID) is : $flModDttm\n";
		# $result = compareDate($frmBlDtTime,$flModDttm);
		# if ($result eq  "1") {
		# 	print 	"DB Upgrade candidate ($frmBlDtTime > $flModDttm) \n";

			$dbUpgradeFileList .= $DBWIID . "\n";

			# if ($opts{v}) { print "Found DB directory : $DBWIID\n"; }
			# Copy the ivos.war file from this location and explode
			if ($DBWIID =~ m/_sql/) {
				$CmdStr = "xcopy $DBWIID $pwdir\\DBUpg_" . $dbUpgFrm . "_to_" . $dbUpgTo . "\\SQL\\Schema\\* /Q /Y /I";
				$DBWIID =~ tr/\//\\/;
				print SQLDBUPGFILE "$DBWIID\n";
			}
			elsif ($DBWIID =~ m/_ora/) {
				$CmdStr = "xcopy $DBWIID $pwdir\\DBUpg_" . $dbUpgFrm . "_to_" . $dbUpgTo . "\\ORA\\Schema\\* /Q /Y /I";
				$DBWIID =~ tr/\//\\/;
				print ORADBUPGFILE "$DBWIID\n";
			}
			if ($opts{v}) { print "Running $CmdStr \n"; }
			$CmdRtn = `$CmdStr 2>&1`;
			if ($?)	
			{   
				$RtnVal = $CmdStr.' failed : '.$CmdRtn;
				undef($RtnVal);	
			}
		# }
		# else {
		#		print 	"Skip - old db change....($frmBlDtTime < $flModDttm)\n";
		#}
	}	
}
# Addition Over - 9/23/2008




# if (!$opts{d}) {

	


	
	# CD to view directory
	chdir "M:\\$tmpviewName\\ucm_ivos" || die "Cannot cd to M:\\$tmpviewName\\ucm_ivos";
	
	# Retrieve the date time created info from the source baseline
	$CmdStr = "cleartool lsh -r -branch $totmpArr[5] -fmt \"%d %n %u \\n\" -since $tmpArr[0]";
	if ($opts{v}) { print "Running $CmdStr \n"; }
	$CmdRtn = `$CmdStr 2>&1`;
	if ($?)
	{   
		$RtnVal = $CmdStr.' failed : '.$CmdRtn;
		undef($RtnVal);	
	}
	
	if ($opts{v}) {
		print "\t\tGC List for stream $tmpArr[5] from  $tmpArr[0]\n";
		print "=================================================================================================\n";
			print "\n\n\n\n$CmdRtn\n\n\n\n";
		print "=================================================================================================\n";
	}
	my @arrGCLst = split(/\n/,$CmdRtn);
	
	@totmpArr = ();
	my $frmCompDtTime = "";
	my $strFrmDt = "";
	# Get the info of two baseline - 9/22/08


	


	foreach my $ln (@arrGCLst) {
		# 9/22		
		# 18-Sep-08.12:13:26 - GC List
		# 22-Sep-08.03:31:07 - Baseline
		#my @date1 = (2008,9,21,22,00,00);-  Function format
		
		@totmpArr = split(/\s+/,$ln);
		
		$frmCompDtTime = $totmpArr[0];
		$frmCompDtTime =~ m/(.*)\-(.*)\-(.*)\.(.*)\:(.*)\:(.*)/;

		my $frmyr = "20".$3;
		$strFrmDt = "$frmyr $months{$2} $1 $4 $5 $6";
		# Compare date
		# If Compare Date = 1, then from date is less than to baseline date, so, get the change list (upgrade)
		# else, skip
		
		$result = compareDate($strFrmDt,$strToDt);
		if ($result eq  "1") {
			#print 	"then from date is less than to baseline date, so, get the change list (upgrade)\n";
		
			# 9/22

			($fullFile) = $ln =~ m/\s(.*)@@/;
			if ($fullFile) {
				if ($fullFile =~ /\./) {
				
				        $fullFile =~ s/\.java/\.class/;

					$fullFile =~ s/ivos\\src\\java\\/ivos\\WEB-INF\\classes\\/;
					$fullFile =~ s/ivos\\src\\rules\\/ivos\\WEB-INF\\classes\\/;
				
					
					$fullFile =~ s/\\web\\/\\/;
					$fullFile =~ s/\\servletdav\\/\\servlet\\/;
					$fullFile =~ s/\\src\\WEB-INF\\/\\WEB-INF\\/;
					$fullFile =~ s/\\etc\\licenses\\UC\\/\\WEB-INF\\/;
				
	
			        	push (@newArr,$fullFile);
					if ($opts{v}) {
						#print $cnt 	. "." . $fullFile . "\n";
					}
				}
			}
			else {	
				# print "not found\n";
			}
			$cnt++;
		}
		else {
			print "skipped line is : $ln\n";
		}
	}
	

	$upgFileLst .= "ivos\\system\\systemInfo.jsp\n";
	push(@newArr,"ivos\\system\\systemInfo.jsp");
	my %hash   = map { $_ => 1 } @newArr;
	my @unique = keys %hash;
	# upgrade file list generation completed

	
	# Change directory back to the program direcotry
	chdir $pwdir || die "Cannot cd to $pwdir";

	my $destUpgFldr = "";
	my $srcUpgFl = "";
	my $destDir = "";
	$frmBlName =~ s/\@\\.*//;  
	$toBlName =~ s/\@\\.*//; 

	$CmdStr = "rmdir $frmBlName " . "_" . $toBlName . "_Upg";
	print "running $CmdStr\n";
	$CmdRtn = `$CmdStr  2>&1`;
	if ($?)
	{
		print "failed on : $CmdStr"
	}	

	$cnt = 0;	

	my $baseFile = "";

	open (TMPFILE, ">$TmpFile") || die "Can't open $TmpFile: $!\n";
	my $dbPrg = "";
	$cnt = 1;
	my $srcflDir = "";
	my $flnamne = "";
	foreach my $fls (@unique){
		
		$fls =~ tr/\//\\/;
		$srcUpgFl = $fls;

		if (($fls !~ m/ivosConfig.xml/) || ($fls !~ m/license.xml/) || ($fls !~ m/web.xml/)) {
			$flname .= basename($fls) . "\n";
			$destDir = dirname($fls);

			$destDir = dirname($fls);
			$destUpgFldr = $frmBlName . "_to_" . $toBlName . "_Upg\\$destDir\\";

			$CmdStr = "xcopy \"" . $srcUpgFl . "\" \"" . $destUpgFldr . "\" /Q /Y /I";
			print "running $CmdStr\n";
			$CmdRtn = `$CmdStr  2>&1`;
			my @tmparr = ();
			if ($?)
			{
				print "xcopy failed on : $CmdStr\n";
				# exit;
			}
			else {
				# find out if there are related files with $ sign.
				$baseFile = basename($fls);
				$srcflDir = $destDir;
				opendir DIR, $srcflDir or die "cannot open dir $srcflDir: $!";
				my @files= readdir DIR;
				closedir DIR;
				my $srcDirFl = "";
		
				foreach my $file (@files) {
					my $innClfile = $file;
					if ($file =~ m/\$/) {
						$file =~ s/\$\d//g;
						$baseFile =~ s/\.(.*)//;
						if ($file =~ m/$baseFile/) {
							$srcDirFl = $srcflDir . "\\$innClfile";
							$CmdStr = "xcopy \"" . $srcDirFl . "\" \"" . $destUpgFldr . "\" /Q /Y /I\n";
							print "running $CmdStr\n";
							$CmdRtn = `$CmdStr  2>&1`;
							if ($?)
							{
								print "xcopy failed on : $CmdStr\n";
							}
							else {
								$srcDirFl =~ s/^ivos\\//;	
								$flnamne .= $cnt . "." . $srcDirFl . "\n";
								$cnt++;
							}
						}
					}
				}
				$srcUpgFl =~ s/^ivos\\//;
				$flnamne .= $cnt . "." . $srcUpgFl . "\n";
				$cnt++;
				$srcflDir = "ivos\\" . $srcflDir;

			}
			# DB Upgrade
			if (($CmdStr =~ m/\\oracle\\/) or ($CmdStr =~ m/\\mssql\\/)){
				@tmparr = split(/\s/,$CmdStr);
				($dbPrg) = $tmparr[1] =~ m/.*\\(.*[.].*)$/;
				$dbPrg =~ s/"//;
				print "Searching -$dbPrg-...(M:\\$tmpviewName\\ucm_ivos\\ivos\\src\\db)\n";
				find( sub { /^$dbPrg$/i && print TMPFILE "$File::Find::name\n" }, "M:\\$tmpviewName\\ucm_ivos\\ivos\\src\\db");
			}
		}
	}
	close(TMPFILE);


	print IVOSUPGFILES "\n\n$flnamne\n\n";

	open(TMPFILE, $TmpFile) || die("Could not open file!");
	@upgfileInfo=<TMPFILE>;
	close(TMPFILE);

	$dbUpgradeFileList .= "\n\nDB Upgrade - Program changes\n";

	foreach $dbPrg (@upgfileInfo) {
		chomp($dbPrg);
		$dbPrg =~ tr/\//\\/;
		$dbUpgradeFileList .= $dbPrg . "\n";
		if ($dbPrg =~ m/mssql/) {
			$CmdStr = "xcopy $dbPrg $pwdir\\DBUpg_" . $dbUpgFrm . "_to_" . $dbUpgTo . "\\SQL\\Prgm\\* /Q /Y /I";
			$dbPrg =~ tr/\//\\/;
			print SQLDBUPGFILE "$dbPrg\n";
		}
		elsif ($dbPrg =~ m/oracle/) {
	       		$CmdStr = "xcopy $dbPrg $pwdir\\DBUpg_" . $dbUpgFrm . "_to_" . $dbUpgTo . "\\ORA\\Prgm\\* /Q /Y /I";
			$dbPrg =~ tr/\//\\/;
			print ORADBUPGFILE "$dbPrg\n";
		}
		if ($opts{v}) { print "Running $CmdStr \n"; }
		$CmdRtn = `$CmdStr 2>&1`;
		if ($?)
		{   
			$RtnVal = $CmdStr.' failed : '.$CmdRtn;
			undef($RtnVal);	
		}
	}
	
	$destUpgFldr =  $frmBlName . "_to_" . $toBlName . "_Upg";

	print CQRPTFILE "\n\n\t\tDB Upgrade File List\n\t\t**************************\n" . $dbUpgradeFileList;

	close(ORADBUPGFILE);
	close(SQLDBUPGFILE);
	close(IVOSUPGFILES);


	# print "**********************************************************************************************\n\n";
	# $cnt = 1;
	# $frmBlName =~ s/\@\\.*//;  
	# $toBlName =~ s/\@\\.*//; 
	# my $upgFldr = $frmBlName . "_" . $toBlName  . "_" .  "Upg";
	# foreach my $fls (@unique){
	#	find( sub { /^$fls$/ && print UPGFILE "xcopy $File::Find::name $upgFldr\\$File::Find::dir\\\n" }, 'ivos');
	#	print  "$cnt. ". $fls . "\n";
	#	$cnt++;
	# }

	# close(UPGFILE);
	# open(UPGFILE, $upgFileInfo) || die("Could not open file!");
	# my @upgfileInfo=<UPGFILE>;
	# close(UPGFILE);
	# print "**********************************************************************************************\n\n";
 
	# foreach $CmdStr (@upgfileInfo)
	# {
	#	$CmdStr =~ tr/\//\\/;
	#	$CmdStr .= " /Q /Y /I";
	#	print "running $CmdStr\n";
	#	$CmdRtn = `$CmdStr  2>&1`;
	# }


	$CmdStr = "wzzip -pr $destUpgFldr.zip $destUpgFldr\\ivos\\*.*";
	print "running $CmdStr\n";
	$CmdRtn = `$CmdStr  2>&1`;


	# DB Upgrade
	# Copy the link files to $dbUpgFolder
	my $dbUpgFolder = "DBUpg_" . $frmBlName . "_to_" . $toBlName;
	$CmdStr = "xcopy $ORADBUpgFileLnks $dbUpgFolder\\* /Q /Y /I";
	# $CmdRtn = `$CmdStr 2>&1`;
	if ($?)
	{   
		$RtnVal = $CmdStr.' failed : '.$CmdRtn;
		undef($RtnVal);	
	}
	$CmdStr = "xcopy $SQLDBUpgFileLnks $dbUpgFolder\\* /Q /Y /I";
	#$CmdRtn = `$CmdStr 2>&1`;
	if ($?)
	{   
		$RtnVal = $CmdStr.' failed : '.$CmdRtn;
		undef($RtnVal);	
	}

	# Consolidated ORA and SQL DB Upgrade links to single files.
	# Added on 1/4/2009 by Dani
	my $dbdir = "";
	my $dbUpgMode = "";
	my $cnCDbfl = "";
	
	# Concatenate Oracle DB Upgrade scripts
	$cnCDbfl = "";
	chdir $pwdir || die "Cannot cd to $pwdir";
	$dbdir = "$dbUpgFolder\\ORA\\Schema";
	$dbUpgMode = "ORA";
	$cnCDbfl .= "\n\n/* ******************** DDLs (Schema) ******************** */\n\n";
	$cnCDbfl .= dbFlConcat($dbdir,$dbUpgMode,$pwdir); 

	chdir $pwdir || die "Cannot cd to $pwdir";
	$dbdir = "$dbUpgFolder\\ORA\\Prgm";
	$dbUpgMode = "ORA";
	$cnCDbfl .= "\n\n/* ******************** DMLs (Schema) ******************** */\n\n";
	$cnCDbfl .= dbFlConcat($dbdir,$dbUpgMode,$pwdir); 
	
	chdir $pwdir || die "Cannot cd to $pwdir";
	open DBCONORAFILE, ">", "ORA_" . $dbUpgFolder . ".txt" or die $!;
	if ($cnCDbfl) {
		print DBCONORAFILE $cnCDbfl;
	}
	close DBCONORAFILE;

	# Concatenate SQL DB Upgrade scripts
	$cnCDbfl = "";
	chdir $pwdir || die "Cannot cd to $pwdir";
	$dbdir = "$dbUpgFolder\\SQL\\Schema";
	$dbUpgMode = "SQL";
	$cnCDbfl .= "\n\n/* ******************** DDLs (Schema) ******************** */\n\n";
	$cnCDbfl .= dbFlConcat($dbdir,$dbUpgMode,$pwdir);
	
	chdir $pwdir || die "Cannot cd to $pwdir";
	$dbdir = "$dbUpgFolder\\SQL\\Prgm";
	$dbUpgMode = "SQL";
	$cnCDbfl .= "\n\n/* ******************** DMLs (Schema) ******************** */\n\n";
	$cnCDbfl .= dbFlConcat($dbdir,$dbUpgMode,$pwdir);
	
	chdir $pwdir || die "Cannot cd to $pwdir";
	open DBCONSQLFILE, ">", "SQL_" . $dbUpgFolder . ".txt" or die $!;
	if ($cnCDbfl) {	
		print DBCONSQLFILE $cnCDbfl;
	}
	close DBCONSQLFILE;
	# Addition over - 1/4/2009 - Dani - Concatenation	


	$CmdStr = "wzzip -pr $dbUpgFolder.zip $dbUpgFolder\\*.*";
	print "running $CmdStr\n";
	$CmdRtn = `$CmdStr  2>&1`;

	# Consolidated ORA and SQL DB Upgrade links to single files and delete the same from root
	# Added on 1/4/2009 by Dani
	# Move DB Zip to Misc folder
	$CmdStr = "xcopy $dbUpgFolder.zip Misc\\* /Q /Y /I";
	print "running $CmdStr\n";
	$CmdRtn = `$CmdStr  2>&1`;

	$CmdStr = "del /F $dbUpgFolder.zip";
	print "running $CmdStr\n";
	$CmdRtn = `$CmdStr  2>&1`;
	 
	# Move ActivityFullversionInfo.txt to Misc folder and delete the same from root
	$CmdStr = "xcopy ActivityFullversionInfo.txt Misc\\* /Q /Y /I";
	print "running $CmdStr\n";
	$CmdRtn = `$CmdStr  2>&1`;

	# Move CQRpt.txt to Misc folder and delete the same from root
	$CmdStr = "xcopy CQRpt.txt Misc\\* /Q /Y /I";
	print "running $CmdStr\n";
	$CmdRtn = `$CmdStr  2>&1`;

	# Move iVosUpgFileList.txt to Misc folder and delete the same from root
	$CmdStr = "xcopy iVosUpgFileList.txt Misc\\* /Q /Y /I";
	print "running $CmdStr\n";
	$CmdRtn = `$CmdStr  2>&1`;

	# Move ORADBUpgFileLinks.txt to Misc folder and delete the same from root
	$CmdStr = "xcopy ORADBUpgFileLinks.txt Misc\\* /Q /Y /I";
	print "running $CmdStr\n";
	$CmdRtn = `$CmdStr  2>&1`;

	# Move SQLDBUpgFileLinks.txt to Misc folder and delete the same from root
	$CmdStr = "xcopy SQLDBUpgFileLinks.txt Misc\\* /Q /Y /I";
	print "running $CmdStr\n";
	$CmdRtn = `$CmdStr  2>&1`;

	# Remove the DB Upgrade Folder directories and files after zipping into the file
	$CmdStr = "rmdir /S /Q $dbUpgFolder";
	print "running $CmdStr\n";
	$CmdRtn = `$CmdStr  2>&1`;

	# Remove the iVos Upgrade Folder directories and files after zipping into the file
	$CmdStr = "rmdir /S /Q $destUpgFldr";
	print "running $CmdStr\n";
	$CmdRtn = `$CmdStr  2>&1`;
	# Addition over - 1/4/2009 - Dani - clean-up
	
	$CmdStr = "del /F ActivityFullversionInfo.txt";
	print "running $CmdStr\n";
	$CmdRtn = `$CmdStr  2>&1`;

	$CmdStr = "del /F CQRpt.txt";
	print "running $CmdStr\n";
	$CmdRtn = `$CmdStr  2>&1`;
	
	$CmdStr = "del /F iVosUpgFileList.txt";
	print "running $CmdStr\n";
	$CmdRtn = `$CmdStr  2>&1`;
	
	$CmdStr = "del /F ORADBUpgFileLinks.txt";
	print "running $CmdStr\n";
	$CmdRtn = `$CmdStr  2>&1`;

	$CmdStr = "del /F SQLDBUpgFileLinks.txt";
	print "running $CmdStr\n";
	$CmdRtn = `$CmdStr  2>&1`;
 

	#Remove the created view
	$CmdStr = "cleartool rmview -force -tag $tmpviewName";
	if ($opts{v}) { print "Running $CmdStr \n"; }
	$CmdRtn = `$CmdStr 2>&1`;
	if ($?)
	{   
		$RtnVal = $CmdStr.' failed : '.$CmdRtn;
		undef($RtnVal);	
	}
# }

# 9/22
$CmdRtn = `cd 2>&1`;
chomp($CmdRtn);
$CmdStr = "DEL /Q $CmdRtn\\$TmpFile";
if ($opts{v}) { print "Running $CmdStr \n"; }
$CmdRtn = `$CmdStr 2>&1`;
if ($?)
{   
	$RtnVal = $CmdStr.' failed : '.$CmdRtn;
	undef($RtnVal);	
}
# CQSession::Unbuild($CQSession);
# 9/22



# ***************************** User defined functions *****************************
# ***************************** Print Help *****************************
sub PrintHelp
{
   print <<EOF;
   
   usage: perl -w iVos_ucm_Upg.pl -f <From baseline> -t <Two baseline> [-d] [-v] [-x];

   -f : from Baseline
   -t : To Baseline

   -d : dB Upgrade only
   -v : Verbose mode
   -x : Debug Mode
   -e : Email functionality
   -h : Help
EOF
}


# ***************************** Enable ClearQuest Session *****************************
sub SetCQSession
{
	my ($CQUser,$CQPwd,$CQDB,$CQConn,$CQSessionRef) = @_;
	$$CQSessionRef = Win32::OLE->new("CLEARQUEST.SESSION") or die "Can't create ClearQuest session object via call to Win32::OLE->new(): $!";
	eval
	{
		$$CQSessionRef->UserLogon("$CQUser", "$CQPwd","$CQDB", 2,$CQConn);
	};
	
	my $ufullname = $$CQSessionRef->GetUserFullName();
	if ($ufullname)
        {
		print "ClearQuest Session has established\n"; 
	}
	else {	
		print "Can not establish ClearQuest Session!!!\n"; 	
	}
	return $$CQSessionRef;
}


# ***************************** Compare Date time *****************************
sub compareDate
{
	use Date::Calc qw( Add_Delta_DHMS Date_to_Days );

	my $returnVal = "";

	# my @date1 = (2008,9,21,22,00,00);

	my $frmParams = shift; # from baseline date
	my $toParams = shift; # To Baseline date

	my @date1 = split(/\s/,$frmParams);
	my @date2 = split(/\s/,$toParams);

#	foreach (@date1) {print $_." ";}
#	print "\n";
#	foreach (@date2) {print $_." ";}


	# Omit the next line if you just want to compare the two dates
	# (and change @date3 and @d3 to @date1 and @d1, respectively):

	# my @date3 = Add_Delta_DHMS(@date1, 0,12,0,0); # ==> is the difference within 12 hours?
	my @date3 = Add_Delta_DHMS(@date1, 0,0,0,1); # ==> is the difference within 1 second ?

	my @d2 = ( Date_to_Days(@date2[0..2]), ($date2[3]*60+$date2[4])*60+$date2[5] );
	my @d3 = ( Date_to_Days(@date3[0..2]), ($date3[3]*60+$date3[4])*60+$date3[5] );

	my @diff = ( $d2[0]-$d3[0], $d2[1]-$d3[1] );

	if ($diff[0] > 0 and $diff[1] < 0) { $diff[0]--; $diff[1] += 86400; }
	if ($diff[0] < 0 and $diff[1] > 0) { $diff[0]++; $diff[1] -= 86400; }

	if (($diff[0] || $diff[1]) >= 0) { 
		# print "More than 12 hours.\n"; }
		#print "date 2 greater\n"; 
		$returnVal = 1;
	}
	else { 
		#print "date 1 greater\n"; 
		$returnVal = 0;
	}
	return 	$returnVal;
}




# *****************************find file modified date time *****************************
sub get_mtime {
  	my ($file) = @_;
	if (! -e $file) {
	        carp "There exists no such file as '$file'";
		return undef;
	};
	if (! -f $file) {
		carp "There exists '$file' but it isn't a file.";
		return undef;
	};
	# my $result = scalar localtime((stat($file))[9]);
	# my $result = (stat($file))[9];
	my ($day, $mon, $yr,$hr,$min,$sec)=(localtime((stat($file))[9]))[3,4,5,2,1,0];

	my $result = sprintf("%02d-%02d-%02d.%02d.%02d.%02d", $mon+1, $day, $yr+1900, $hr, $min, $sec);

	# Return the date time format as : 22-Sep-08.03:31:07 - Dani
	# my ($sec, $min, $hr, $day, $mon, $yr) = (localtime)[0,1,2,3,4,5];
	# $BldHash{'BldStartTimeInt'} = timelocal($sec, $min, $hr, $day, $mon, $yr); 
	# $BldHash{'BldStartTime'} = sprintf("%04d-%02d-%02d_%02d.%02d.%02d", $yr+1900,$mon+1, $day, $hr, $min, $sec);
	# $BldHash{'DateStr'} = sprintf("%02d-%02d-%02d", $mon+1, $day, $yr+1900);

	# carp $!
	# if $!;
    	$result;
};




# ***************************** Concatenate the DB upgrade scripts to a single file *****************************
sub dbFlConcat {

	my $db_dir = shift;
	my $DBUpgMode = shift;
	my $pwdir = shift;

	print "DB Directory is : $db_dir\n";
	
	opendir(DBUPGRADEDIR, $db_dir) || print "can't opendir $db_dir: $!";
	my @a = ();
	@a =
	  sort {(stat "$db_dir/$a")[9] <=> (stat "$db_dir/$b")[9]}
	  grep {  -f "$db_dir/$_" }
	  readdir(DBUPGRADEDIR);
	closedir DBUPGRADEDIR;

	my $dbUpgfile = "";

	my $dbFile = "";
	foreach $dbFile(@a) {
		chdir "$pwdir\\$db_dir" || print "Cannot cd to $pwdir\\$db_dir";

		open (DBFILE, "$dbFile") || print "Can't open $dbFile: $!\n";
		my @dbfileData=<DBFILE>;

		$dbUpgfile .= "\n/* *************** $dbFile *************** */\n\n";
		foreach my $dbfldt (@dbfileData) {
			$dbUpgfile .= $dbfldt;
		}
		
		# Commented by Dani on 1/6/09
		# Purpose : The go statement in SQL or '/' in Oracle should be maintained by who ever is creating the script
		# if ($DBUpgMode eq "SQL") {
		#	$dbUpgfile .= "\ngo\n";
		# }
		# else {
		#	$dbUpgfile .= "\n/\n";
		# }

		$dbUpgfile .= "\n/*  -------- End of $dbFile -------- */\n\n\n";
	
		close(DBFILE);
	}
	return $dbUpgfile;
}
