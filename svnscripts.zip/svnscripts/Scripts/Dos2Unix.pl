#!/usr/bin/perl -w

opendir(DIR, ".");
@files = grep(/\.xml$/,readdir(DIR));
closedir(DIR);

foreach $file (@files) {
   print "$file\n";
}

