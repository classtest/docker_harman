#!/bin/sh

# ##########################################################################
# Harman Connected Services Artifactory Cleanup Script
#
# Copyright (C) 2018 Harman Connected Services, Inc. All Rights Reserved.
#
# This software is confidential and proprietary information of
# Harman Connected Services, Inc. ("Confidential Information"). 
# 
# For more information, visit https://services.harman.com
#
# Version	: 1.0
# Last updated	: June 20, 2018
# Authors	: Subhash (sdelhi) & Bhagyaraj (bdesuri)
# Purpose	: Artifactory Cleanup
#
# ###########################################################################

artifactoryUrl="https://artifactory.corp.ventivtech.com/artifactory"
artifactoryStorUrl="https://artifactory.corp.ventivtech.com/artifactory/api/storage"
repoName="docker-registry-dev/ivos"
outputFile="fldrList.log"

curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoName} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' |  grep -P '^(4)|^(5)|^in-progress-[0-9]' > ${outputFile}
chmod a+x ${outputFile}

while read -r arcBuild; do

versn=`echo "$arcBuild" | awk -F- '{print $1}'`

if [[ ${versn} == "in" ]]; then
    echo "in-progress" > fnlinprgs.log
else
   echo "${versn}" >> fnlver.log
fi

   echo "$arcBuild" | grep $versn
   if [ $? == 0 ]; then
	if [[ ${versn} == "in" ]]; then
            echo "${arcBuild}" >> in-progress.log
        else
	   echo "${arcBuild}" >> $versn.log
	fi
   else
    	echo "ERROR: Unable to find version details."
   fi
done < "${outputFile}"

bdLst=`awk '!x[$1]++ { print $1 }' fnlver.log`
echo "${bdLst}" > fnList.log
echo "in-progress" >> fnList.log

while read -r repodir; do
 
repoVal=`echo $repodir | cut -c1`	

if [[ ${repodir} == "in-progress" ]]; then
    	fnlinprsbds=`cat in-progress.log | awk -F- {'print $3'} | sort -n | head -n -10`
    	echo "${fnlinprsbds}" > in-progress.log
else
    	fnlbds=`cat $repodir.log | awk -F- {'print $2'} | sort -n | head -n -10` 
    	echo "${fnlbds}" > $repodir.log
fi

buildCount=`cat $repodir.log | wc -l`
inprgsbuildCount=`cat in-progress.log | wc -l`

if [[ ${repoVal} -eq "4" ]] && [[ ${buildCount} -gt "10" ]]; then
	echo ""
	echo "Expected count is : 10 or above"
	echo "$repodir count is : ${buildCount} GREATER THAN 10."

while read -r arcBuild; do

    noProp=`curl -s -k -u upload:upload "${artifactoryStorUrl}/${repoName}/${repodir}-${arcBuild}?properties" | grep -i "No properties could be found" | awk '{print substr($0,(length($0)-30))}'`
    keepForever=`curl -s -k -u upload:upload "${artifactoryStorUrl}/${repoName}/${repodir}-${arcBuild}?properties" | grep -i "scm.keepForever" | awk {'print $1'}`

    echo ""
    echo "Build Number is : ${repodir}-${arcBuild}"
    echo "noProp=${noProp}"
    echo "keepForever=${keepForever}"

    if [[ ${noProp} == '"No properties could be found."' ]]; then
       echo "DELETING: No property set for build # ${repodir}-${arcBuild}. Hence deleting from artifactory."
       curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoName}/${repodir}-${arcBuild}"
       
    elif [[ ${keepForever} == '"scm.keepForever"' ]]; then
         echo "KEEP FOR EVER: 'scm.keepForever' property set for build # ${repodir}-${arcBuild}. Hence preserving this build forever in artifactory."

    else
         echo "ERROR: Issue in executing. Please check with admin and run again. Quitting the process."
         exit 0
    fi
    done < $repodir.log

elif [[ ${repoVal} -eq "5" ]] && [[ ${buildCount} -gt "10" ]]; then
	echo ""
	echo "Expected count is : 10 or above"
	echo "$repodir count is : ${buildCount} GREATER THAN 10."

while read -r arcBuild; do

    noProp=`curl -s -k -u upload:upload "${artifactoryStorUrl}/${repoName}/${repodir}-${arcBuild}?properties" | grep -i "No properties could be found" | awk '{print substr($0,(length($0)-30))}'`
    keepForever=`curl -s -k -u upload:upload "${artifactoryStorUrl}/${repoName}/${repodir}-${arcBuild}?properties" | grep -i "scm.keepForever" | awk {'print $1'}`

    echo ""
    echo "Build Number is : ${repodir}-${arcBuild}"
    echo "noProp=${noProp}"
    echo "keepForever=${keepForever}"
        
    if [[ ${noProp} == '"No properties could be found."' ]]; then
       echo "DELETING: No property set for build # ${repodir}-${arcBuild}. Hence deleting from artifactory."
       curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoName}/${repodir}-${arcBuild}"
        
    elif [[ ${keepForever} == '"scm.keepForever"' ]]; then
         echo "KEEP FOR EVER: 'scm.keepForever' property set for build # ${repodir}-${arcBuild}. Hence preserving this build forever in artifactory."
        
    else
         echo "ERROR: Issue in executing. Please check with admin and run again. Quitting the process."
         exit 0
    fi
    done < $repodir.log

elif [[ ${repodir} == "in-progress" ]] && [[ ${inprgsbuildCount} -gt "10" ]]; then
	echo ""
	echo "Expected count is : 10 or above"
	echo "$repodir count is : ${inprgsbuildCount} GREATER THAN 10."

while read -r arcBuild; do

    noProp=`curl -s -k -u upload:upload "${artifactoryStorUrl}/${repoName}/${repodir}-${arcBuild}?properties" | grep -i "No properties could be found" | awk '{print substr($0,(length($0)-30))}'`
    keepForever=`curl -s -k -u upload:upload "${artifactoryStorUrl}/${repoName}/${repodir}-${arcBuild}?properties" | grep -i "scm.keepForever" | awk {'print $1'}`

    echo ""
    echo "Build Number is : ${repodir}-${arcBuild}"
    echo "noProp=${noProp}"
    echo "keepForever=${keepForever}"
        
    if [[ ${noProp} == '"No properties could be found."' ]]; then
       echo "DELETING: No property set for build # ${repodir}-${arcBuild}. Hence deleting from artifactory."
       curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoName}/${repodir}-${arcBuild}"
        
    elif [[ ${keepForever} == '"scm.keepForever"' ]]; then
         echo "KEEP FOR EVER: 'scm.keepForever' property set for build # ${repodir}-${arcBuild}. Hence preserving this build forever in artifactory."
        
    else
         echo "ERROR: Issue in executing. Please check with admin and run again. Quitting the process."
         exit 0
    fi
    done < $repodir.log

else
	echo ""
	echo "Expected counts are : 4x , 5x , in-progress (Builds: 10) or above"
	echo "$repodir count is : ${buildCount} LESSER THAN expected. Hence SKIPPING verification process."
    fi

done < "fnList.log"
