#!/usr/bin/perl -w

my $numArgs = $#ARGV + 1;

my $currDir = ``;
my $ivosDir = "ivos";

chomp($currDir);

if($numArgs < 1 || $numArgs > 2) {
    print "USAGE: perl extractChanges.pl <gcList file name> <optional path to ivos folder, default cwd>\n";
    exit;
}

if($numArgs == 2) {
    $ivosDir = $ARGV[1];
}

unless(-e $ARGV[0]) {
    print "gcFile list not found: $ARGV[0]"; ;
    exit 0;
}

unless(-d $ivosDir || -d "$ivosDir/WEB-INF") {
    print "No ivos directory found in '$ivosDir'"; ;
    exit 0;
}


my $classes = "WEB-INF/classes";

@files = `edit $ARGV[0]`;

print "rm -f upgrade.zip;\n";
print "cd $ivosDir;\n";

foreach(@files) {
    
    s/\\/\//g; # replace \ with /

    # extract file name
    @tokens1 = split " ";    
    @tokens2 = split("@@", $tokens1[1]);        
    my $file = $tokens2[0];
    my $original = $file;
   
    
    if($map{$original}) {
       	print "# Duplicate: $_";
    } else {
        if($file =~ /.java$/ && $file =~ s/.java/\*.class/ && $file =~ s/^src\///) {       
		# print "zip upgrade.zip $classes/$file;\n"
		print "$classes/$file;\n"
        } elsif($file =~ /.jsp$/ || $file =~ /.js$/ || $file =~ /.jar$/ || $file =~ /.tld$/ || $file =~ /.jpg$/ || $file =~ /.xml$/) {
		# print "zip upgrade.zip $file;\n"; 
		print "$file;\n"; 
        } elsif($file =~ /.sql$/ || $file =~ /.trg$/) {
		# print "# DB File : $_";
		print "# DB File : $_";
        } elsif($file =~ /(\w)+/) { 
		# print "# Directory : $_";	
		print "# Directory : $_";	
        } else {    
		# print "\n\n\n\n#### ERROR $file - $_\n"; 
		print "# Directory : $_";	
        }
        
        $map{$original} = $original;
     }
}

# print "mv upgrade.zip $currDir;\n";
# print "cd $currDir;\n";
