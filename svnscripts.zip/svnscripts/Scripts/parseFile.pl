#!/usr/bin/perl -w

use Getopt::Std;

my %Opt = ();
getopts("f:", \%Opt) || die "ERROR : Invalid  options \n";


$filename = $Opt{f};
open( FILE, "< $filename" ) or die "Can't open $filename : $!";
while( <FILE> ) {

	@str = split(/\s/,$_);
	@str1 = split(/@@/,$str[1]);
	# print $str1[0] . "\n";
	# $str1 =~ m/(/\$)/
	push(@fileLines,$str1[0]);
}


$filename = "C:\\RelNotes.txt";
open( FILE, "> $filename" ) or die "Can't open $filename : $!";
my $flg = 0;

my @tmparr=@fileLines;
my $incr;
foreach my $line (@fileLines) {
	$flg = 0;
	$cnt = 0;
	foreach $lineTstDup (@tmparr) {
		if ($line eq $lineTstDup) {
			$cnt++;
		}
		if ($cnt eq 2) {
			$flg = 1;
			# print "duplicate : $line \n";
			last;
		}

	}
	if ($flg eq 0) {
		$incr++;
		print FILE "$incr. $line\n";

	}
}


