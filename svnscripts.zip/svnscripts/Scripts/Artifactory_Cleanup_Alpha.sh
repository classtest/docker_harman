#!/bin/sh

# ##########################################################################
# Harman Connected Services Artifactory Cleanup Script
#
# Copyright (C) 2018 Harman Connected Services, Inc. All Rights Reserved.
#
# This software is confidential and proprietary information of
# Harman Connected Services, Inc. ("Confidential Information"). 
# 
# For more information, visit https://services.harman.com
#
# Version	: 1.0
# Last updated	: April 03, 2018
# Authors	: Subhash (sdelhi) & Bhagyaraj (bdesuri)
# Purpose	: Artifactory Cleanup
#
# ###########################################################################

artifactoryUrl="https://artifactory.corp.ventivtech.com/artifactory"
artifactoryStorUrl="https://artifactory.corp.ventivtech.com/artifactory/api/storage"
repoPath="docker-registry-dev"
repoName="alpha"
etlrepoName="alpha-etl"
solrreponame="solr"
outputFile="alpha.out.log"
etloutputFile="alphaEtl.out.log"

# ******************************************************
# Main function
# ******************************************************
function alpharepocleanup() {

curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repoName} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | grep -e AL-* -e develop-[0-9] -e develop_b[0-9] > ${outputFile}

curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${etlrepoName} | grep -i "uri" | sort -n | cut -d ":" -f2 | cut -d "/" -f2 | sed 's/\"//' | sed 's/\,//' | sed 's/\https//g' | sed -e 's/[\t ]//g;/^$/d' | grep -e develop_b[0-9] > ${etloutputFile}

chmod a+x ${outputFile} ${etloutputFile}

while read -r arcBuild
do
    echo ""
    echo "Build Number is : ${arcBuild}"

    strFnd=`echo "${arcBuild}" | grep -e develop`
    if [ $? -eq 0 ]; then
        arcBuildNum=`echo ${arcBuild} | cut -c 9-20 | tr -d 'b'`
        etlBuildNum=`cat ${etloutputFile} | grep -o "b${arcBuildNum}"`
        etlBuild="${etlBuildNum}"
        echo "ETL BUILD NUMBER IS: ${etlBuild}"
    fi



#fromBuild=`curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repoName} | grep -i "uri" | sed "s/[^0-9]//g" | grep -Px '\d{4}' | head -1`
#toBuild=`curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repoName} | grep -i "uri" | sed "s/[^0-9]//g" | grep -Px '\d{4}' | tail -1`

#for (( i=${fromBuild} ; ((i-${toBuild})) ; i=(($i+1)) ))
#do
#    echo ""
#    echo "Build Number is : ${i}"

noProp=`curl -s -k -u upload:upload "${artifactoryStorUrl}/${repoPath}/${repoName}/${arcBuild}?properties" | grep -i "No properties could be found" | awk '{print substr($0,(length($0)-30))}'`
keepForever=`curl -s -k -u upload:upload "${artifactoryStorUrl}/${repoPath}/${repoName}/${arcBuild}?properties" | grep -i "scm.keepForever" | awk {'print $1'}`
prodDeploy=`curl -s -k -u upload:upload "${artifactoryStorUrl}/${repoPath}/${repoName}/${arcBuild}?properties" | grep -i "scm.deployedOn" | grep -i "prod" | awk {'print $1'}`
uatAppDeploy=`curl -s -k -u upload:upload "${artifactoryStorUrl}/${repoPath}/${repoName}/${arcBuild}?properties" | grep -i "scm.approvedToDeployOn" | grep -i "uat" | awk {'print $1'}`
prodAppDeploy=`curl -s -k -u upload:upload "${artifactoryStorUrl}/${repoPath}/${repoName}/${arcBuild}?properties" | grep -i "scm.approvedToDeployOn" | grep -i "prod" | awk {'print $1'}`
uatDeploy=`curl -s -k -u upload:upload "${artifactoryStorUrl}/${repoPath}/${repoName}/${arcBuild}?properties" | grep -i "scm.deployedOn" | grep -i "uat" | awk {'print $1'}`

echo "noProp=${noProp}"
echo "keepForever=${keepForever}"
echo "uatDeploy=${uatDeploy}"
echo "prodDeploy=${prodDeploy}"
echo "uatAppDeploy=${uatAppDeploy}"
echo "prodAppDeploy=${prodAppDeploy}"


if [[ ${noProp} == '"No properties could be found."' ]]; then
	buildPeriod_check
    if [[ "${DAYS}" -ge '31' || "${DAYS}" -eq '31' ]]; then
	echo "DELETING: No property set for build # ${arcBuild} and preserved ${DAYS} days, more than a month. Hence deleting from artifactory."
	curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${repoName}/${arcBuild}"
	curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${etlrepoName}/develop_${etlBuild}"
	curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${solrreponame}/${arcBuild}"
    else
	echo "LESS THAN A MONTH: No property set for build # ${arcBuild} and preserved ${DAYS} days."
    fi

elif [[ ${keepForever} == '"scm.keepForever"' ]]; then
	buildPeriod_check
	echo "KEEP FOR EVER: 'scm.keepForever' property set for build # ${arcBuild}. Hence preserving this build forever in artifactory."

elif [[ ${prodDeploy} == '"scm.deployedOn"' ]]; then
	buildPeriod_check
    if [[ "${DAYS}" -ge '1800' || "${DAYS}" -eq '1800' ]]; then
	echo "DELETING: 'scm.deployedOn: prod' property set for build # ${arcBuild} and preserved ${DAYS} days, more than 5 years. Hence deleting from artifactory."
	curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${repoName}/${arcBuild}"
        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${etlrepoName}/develop_${etlBuild}"
	curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${solrreponame}/${arcBuild}"
    else
	echo "LESS THAN 5 YEARS: 'scm.deployedOn: prod' property set for build # ${arcBuild} and preserved ${DAYS} days, less than 5 years."
    fi	

elif [[ ${uatDeploy} == '"scm.deployedOn"' ]]; then
	buildPeriod_check
    if [[ "${DAYS}" -ge '180' || "${DAYS}" -eq '180' ]]; then
        echo "DELETING: 'scm.deployedOn: uat' property set for build # ${arcBuild} and preserved ${DAYS} days, more than 6 months. Hence deleting from artifactory."
        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${repoName}/${arcBuild}"
        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${etlrepoName}/develop_${etlBuild}"
	curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${solrreponame}/${arcBuild}"
    else
        echo "LESS THAN 6 MONTHS: 'scm.deployedOn: uat' property set for build # ${arcBuild} and preserved ${DAYS} days, less than 6 months."
    fi

elif [[ ${prodAppDeploy} == '"scm.approvedToDeployOn"' ]]; then
	buildPeriod_check
     if [[ "${DAYS}" -ge '180' || "${DAYS}" -eq '180' ]]; then
	echo "DELETING: ''scm.approvedToDeployOn: prod' property set for build # ${arcBuild} and preserved ${DAYS} days, more than 6 months. Hence deleting from artifactory."
        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${repoName}/${arcBuild}"
        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${etlrepoName}/develop_${etlBuild}"
	curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${solrreponame}/${arcBuild}"
     else
       	echo "LESS THAN 6 MONTHS: ''scm.approvedToDeployOn: prod' property set for build # ${arcBuild} and preserved ${DAYS} days, less than 6 months."
     fi			

elif [[ ${uatAppDeploy} == '"scm.approvedToDeployOn"' ]]; then
	buildPeriod_check
      if [[ "${DAYS}" -ge '90' || "${DAYS}" -eq '90' ]]; then
        echo "DELETING: ''scm.approvedToDeployOn: uat' property set for build # ${arcBuild} and preserved ${DAYS} days, more than 3 months. Hence deleting from artifactory."
        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${repoName}/${arcBuild}"
        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${etlrepoName}/develop_${etlBuild}"
	curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${solrreponame}/${arcBuild}"
      else
        echo "LESS THAN 3 MONTHS: ''scm.approvedToDeployOn: uat' property set for build # ${arcBuild} and preserved ${DAYS} days, less than 3 months."
      fi 

elif [[ ${noProp} == " " ]] && [[ ${keepForever} == " " ]] && [[ ${prodDeploy} == " " ]]; then
	buildPeriod_check
      if [[ "${DAYS}" -ge '31' || "${DAYS}" -eq '31' ]]; then
	echo "DELETING: NULL PROPERTIES set for build # ${arcBuild} and preserved ${DAYS} days, more than a month. Hence deleting from artifactory."
        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${repoName}/${arcBuild}"
        curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${etlrepoName}/develop_${etlBuild}"
	curl -v -k -u upload:upload -XDELETE "${artifactoryUrl}/${repoPath}/${solrreponame}/${arcBuild}"
    else
        echo "LESS THAN A MONTH: NULL PROPERTIES set for build # ${arcBuild} and preserved ${DAYS} days, less than a month."
    fi

else
#	rm -rf "${outputFile}"
	echo "ERROR: Issue in executing. Please check with admin and run again. Quitting the process."
	exit 0
fi

done < "${outputFile}"
#	rm -rf "${outputFile}"

}

# ******************************************************
# This function compares the created date
# ******************************************************

function buildPeriod_check() {

BNUM="${arcBuild}"

D0=`date`
D1=`date +%s -d "$D0"`
D2=`curl -s -k -u upload:upload -X GET ${artifactoryStorUrl}/${repoPath}/${repoName}/${BNUM}?created | grep "created" | awk {'print $3'} | head -1 | cut -d ":" -f1 | awk '{print substr($0,(length($0)-12))}' | cut -c 1-10 | tr -d '-'`
D3=`date +%s -d "$D2"`

((diff_sec=D1-D3))
DAYS=`echo - | awk -v SECS=$diff_sec '{printf "%d",SECS/(60*60*24)}'`
echo "Number of days build stored : ${DAYS}"
}

# ======================================================
# calling main function - script execution starts here
# ======================================================
alpharepocleanup

# =================================================*** SCRIPT ENDS HERE ***==================================================
