#!/bin/bash
set -e

chmod a+x build.gradle
chmod a+x build_ivos.sh
chmod a+x build_modules.sh
chmod a+x cleanAll.sh
chmod a+x doBuild.sh
chmod a+x gradlew

# cd web/WEB-INF
# ln -s /mnt/u01/build/teamcity-agent/work/4a2b4c8f0d0e2c7a/reports .
# cd ../../
# copy reports artifacts from reports build
cp -r reports web/WEB-INF

#export JAVA_HOME=/usr/java/jdk1.5.0_22
export JAVA_HOME=/usr/java/jdk1.6.0_45


# /mnt/u01/build/gradle-cache/wrapper/dists/gradle-1.0-milestone-5/bin/gradle wrapper

./gradlew -DXmX=1024M clean.temp jarIvos $1 $2 $3 $4 $5
wait

./build_modules.sh
wait

./gradlew war
wait

./gradlew copybuild $1 $2 $3 $4 $5
wait
