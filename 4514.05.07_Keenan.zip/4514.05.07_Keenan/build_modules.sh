#!/bin/bash
set -e

./gradlew -d -DXmX=1024M -b ./Modules/build.gradle assemble copyLibs :Common-ConfigurationUI:gwtCompile :Common-PageRenderer:gwtCompile :Common-PageBuilder:gwtCompile
