#!/bin/bash

./gradlew -DXmX=1024M jarIvos $1 $2 $3 $4 $5
