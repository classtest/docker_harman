#!/bin/bash

./gradlew clean clean.temp
