#!/bin/bash
set -e
set -x

# Database Properties from AppConfig
if [ -n "${PROPERTIES_ENVIRONMENT}" ]; then
  DATABASE_URL=`curl -H "Accept: text/plain" -s "https://appconfig.corp.ventivtech.com/AppConfig/application/Alpha/environment/${PROPERTIES_ENVIRONMENT}?decrypt=true" | grep data.oracle.url | awk -F"data.oracle.url=" '{print $2}' | sed $'s/\r//'`
  DATABASE_USERNAME=`curl -H "Accept: text/plain" -s "https://appconfig.corp.ventivtech.com/AppConfig/application/Alpha/environment/${PROPERTIES_ENVIRONMENT}?decrypt=true" | grep data.oracle.username | awk -F"data.oracle.username=" '{print $2}' | sed $'s/\r//'`
  DATABASE_PASSWORD=`curl -H "Accept: text/plain" -s "https://appconfig.corp.ventivtech.com/AppConfig/application/Alpha/environment/${PROPERTIES_ENVIRONMENT}?decrypt=true" | grep data.oracle.password | awk -F"data.oracle.password=" '{print $2}' | sed $'s/\r//'`

  cp /assets/context-with-db.xml /usr/local/tomcat/conf/context.xml

  sed 's/{{DATABASE_URL}}/'"${DATABASE_URL}"'/g' -i /usr/local/tomcat/conf/context.xml
  sed 's/{{DATABASE_USERNAME}}/'"${DATABASE_USERNAME}"'/g' -i /usr/local/tomcat/conf/context.xml
  sed 's/{{DATABASE_PASSWORD}}/'"${DATABASE_PASSWORD}"'/g' -i /usr/local/tomcat/conf/context.xml
fi

/usr/local/tomcat/bin/catalina.sh run