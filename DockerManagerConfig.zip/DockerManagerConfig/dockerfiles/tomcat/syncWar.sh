#!/bin/bash

# Check to make sure we have the proper inputs
if [ "$#" -ne 2 ]; then
    echo "Usage: syncWar <tomcatContextName> <downloadUrl>"
    exit 1;
fi

# Assign Variables
LAUNCH_DIRECTORY=`pwd`
TOMCAT_CONTEXT_NAME=$1
DOWNLOAD_URL=$2

# Make the webapp directory, just in case it doesn't exist already
mkdir -p /usr/local/tomcat/webapps/$TOMCAT_CONTEXT_NAME

# Create and cd into a temp directory
mkdir -p /tmp/$TOMCAT_CONTEXT_NAME
cd /tmp/$TOMCAT_CONTEXT_NAME

# Download the war
curl -SLs "$DOWNLOAD_URL" -o $TOMCAT_CONTEXT_NAME.war

# Extract the war using Java's jar command
$JAVA_HOME/bin/jar -xf $TOMCAT_CONTEXT_NAME.war

# Remove the downloaded temporary war
rm -f $TOMCAT_CONTEXT_NAME.war

# RSync the contents (by checksum, while deleting any excess) to the webapps dir
rsync -rlpcgoDv --delete /tmp/$TOMCAT_CONTEXT_NAME /usr/local/tomcat/webapps

# CD back to where we were
cd $LAUNCH_DIRECTORY

# Clean up our temp directory
rm -rf /tmp/$TOMCAT_CONTEXT_NAME