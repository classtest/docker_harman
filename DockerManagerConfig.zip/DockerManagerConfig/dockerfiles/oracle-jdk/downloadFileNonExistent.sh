#!/bin/bash

# Check to make sure we have the proper inputs
if [ "$#" -ne 2 ]; then
    echo "Usage:   $0 <downloadUrl> <destinationDirectory>"
    echo "Example: $0 https://www.apache.org/dist/tomcat/tomcat/tomcat.war /usr/local/tomcat"
    echo "         Downloads tomcat.war and places the file in /usr/local/tomcat, if and only if it doesn't exist"
    exit 1;
fi

# Assign Variables
LAUNCH_DIRECTORY=`pwd`
DOWNLOAD_URL=$1
DESTINATION_DIRECTORY=$2
FILE_NAME=${DOWNLOAD_URL##*/}
DESTINATION_FULL_PATH=${DESTINATION_DIRECTORY}/${FILE_NAME}

if [ ! -f $DESTINATION_FULL_PATH ]; then
    curl -SLs "$DOWNLOAD_URL" -o $DESTINATION_FULL_PATH
fi